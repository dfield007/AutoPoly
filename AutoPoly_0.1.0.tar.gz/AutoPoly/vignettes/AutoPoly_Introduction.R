## ----Import data, echo=F,include=F---------------------------------------
require(AutoPoly)
data(Eremophila)

## ----results = 'example Eremophila',echo=F-------------------------------
rownames(Eremophila) <- NULL
exampleSet <- rbind(Eremophila[1:4,1:9],Eremophila[100:104,1:9],Eremophila[652:656,1:9])
knitr::kable(exampleSet, caption = "Table 1. Microsattelite data set provided with **AutoPoly** for the autohexaploid plant, Eremophila glabra. Consists of phenotypes (allele dosage unknown) for six loci. Here we show an example for one locus for a sample of adults (9 shown) and offspring (5 shown from mother - GA1)",padding=4,row.names = F)

## ----echo=T,eval=F-------------------------------------------------------
#  install.packages('gtools')
#  require(gtools)

## ----installAutoPoly,echo=T,eval=F---------------------------------------
#  install.packages('AutoPoly')
#  require(AutoPoly)

## ----echo=T, eval=F------------------------------------------------------
#  data(Eremophila)
#  write.csv(Eremophila,"Eremophila_mumKnown.csv",quote=F,row.names=F)

## ----echo=T,eval=F-------------------------------------------------------
#  DRRtable_1 <- DRRsetup(numLoci=6,ploidy=6,propDRR=1)

## ----echo=T, eval=F------------------------------------------------------
#  DRRtable_2 <- DRRtable_1
#  DRRtable_2[,1] <- 0.13635

## ----echo=T, eval=F------------------------------------------------------
#  segTable_1 <- makeGameteSegTable(ploidy=6,DRRtable_1)
#  segTable_2 <- makeGameteSegTable(ploidy=6,DRRtable_2)

## ----echo=T, eval=F------------------------------------------------------
#  EremophilaData <- inputData("Eremophila_mumKnown.csv",numLoci=6,lociMin=5,ploidy=6,marker="phenotype",cohorts=T,motherknown=T,DRRtable_1)

## ----alleleFreq Pheno, echo=T,eval=F-------------------------------------
#  alleleFreq <- alleleFreqPheno(EremophilaData,numLoci=6,ploidy=6,replacement=FALSE)

## ----gameteFreqTable1, echo=T, eval=F------------------------------------
#  gameteFreq_1 <- gameteFreq(EremophilaData,alleleFrequencies=alleleFreq,numLoci=6,
#  ploidy=6,DRRtable=DRRtable_1,DRRtype="general")

## ----gameteFreqTable2, echo=T, eval=F------------------------------------
#  gameteFreq_2 <- gameteFreq(EremophilaData,alleleFrequencies=alleleFreq,numLoci=6,
#  ploidy=6,DRRtable=DRRtable_2,DRRtype="general")

## ----echo=T, eval=F------------------------------------------------------
#  simulationEremophila <- simAssignmentMums(inData=EremophilaData, alleleFrequencies=alleleFreq,replacement=T,gameteFreq_actual=gameteFreq_1, gameteFreq_est=gameteFreq_2, ploidy=6,marker="phenotype", numLoci=6,selfing=0.1, DRRtable_actual=DRRtable_1, DRRtable_est=DRRtable_2, segTable_actual=segTable_1,segTable_est=segTable_2,DRRtype="general", simMissLoci=0, lociMin=1, epsilon=0.1,errorRate1=0.01,errorRate2=0.01, output.txt=F,numAdultsSim=50,numMothersSim=10,numOffspringSim=5000,fixMothersSim=F,immRateSim=0.3)

## ----echo=T,eval=F-------------------------------------------------------
#  EremophilaAssignment <- assignmentPheno(inData=EremophilaData,alleleFrequencies=alleleFreq,gameteFrequencies=gameteFreq_2,numLoci=6,ploidy=6,motherknown=T,DRRtable_2,DRRtype="general",segregationRatios=segTable_2)

## ----echo=F,eval=F-------------------------------------------------------
#  summaryEremophilaAssignment <- summaryAssignment(inData=EremophilaData, results=EremophilaAssignment, simulationResults=simulationEremophila, ploidy=6,numLoci=6,
#      marker="phenotype", motherknown=TRUE, epsilon=0.1)

## ----results = 'example Eremophila',echo=F,eval=T------------------------
assignmentSummary<- read.csv('/Users/dfield/Documents/DavidWorkLaptop/PostdocCSIRO/final2017/package/assignmentSummary.csv',header=TRUE)
rownames(assignmentSummary) <- NULL
exampleSet <- assignmentSummary[1:4,]
colnames(exampleSet)[4:5] <- c(1,2)
knitr::kable(exampleSet, caption = "Table 2. Summary of population assignment of Eremophila data with **AutoPoly** (first 4 individuals)",padding=4,row.names = F)

