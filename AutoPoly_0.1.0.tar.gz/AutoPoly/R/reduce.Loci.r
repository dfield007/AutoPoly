#' function to reduce the number of loci in a data set
#'
#' @param inData vector, name of data file to modify
#' @param ploidy numeric, number of homologous chromosomes. Must be 4 or 6 (i.e. tetraploid or hexaploid).
#' @param newLociNum numeric, number of loci to return
#' @author David L. Field
#' @export
reduceLoci <- function(inData,ploidy,newLociNum) {
  newDataFile <- inData[,1:(3+newLociNum*ploidy)]
  return(newDataFile)
}
