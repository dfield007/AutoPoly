#' Setup Double Reduction Rate information
#'
#' Generates a dataframe containing randomly generated Double Reduction Rates (DRR)
#' at individual loci. DRR will be randomly drawn from between theoreticl minimum and maximum
#'
#' @param numLoci numeric, number of loci in the data set.
#' @param ploidy numeric, number of homologous chromosomes. Must be 4 or 6 (i.e. tetraploid or hexaploid).
#' @param propDRR numeric, the proportion of loci which will have non-zero double reduction
#' @details
#' \emph{Testing assumptions regarding double reduction rates (DRR)}
#' \itemize{
#'  \item {For most data sets, the true DRR at each locus is unknown. However, we can test the effect of deviations
#'  from the true value by keeping two sets of DRR. In order to test this, one can generate two alternative DDR and
#'  segregation ratio details for the assignment}
#'  \item {Actual values. Generate DRRtable_1 and associated segTable_1 to designate as the actual 'real'
#'  values which will be used in the simulations.}
#'  \item {Estimated values. Generate another set of tables called DRRtable_2 and associated segTable_2 and
#'  use these as the estimated values. As the actual and estimated values depart more, we can see the effects on the assignment
#'  and confidence in assignment}
#'  \item {In other words, if you know the true DRR and segregation ratios then make table 1 and table 2 the same}
#' }
#' \emph{Output}
#' \itemize{
#'  \item {A list of two: $LScoresMatrix and $seedlingStatus}
#'  \item {$LScoresMatrix. This contains a dataframe where rows are the offspring and columns are the assignment likelihoods
#'  for each candidate population at each locus. Columns identify the population and locus number}
#'  \item {$seedlingStatus. This contains a dataframe where rows are the offspring and columns flag the quality of the data at each locus,
#'  as either "OK" (data present at locus), "S" (data missing at locus), "MS" (parent-offspring mismatch)}
#' }
#' @return procudes a matrix containing DRR at each locus
#' @author David L. Field
#' @examples
#' # access data provided with AutoPoly
#' data(Eremophila)
#' write.csv(Eremophila,"Eremophila_mumKnown.csv",quote=F,row.names=F)
#'
#' DRRtable_1 <- DRRsetup(numLoci=6,ploidy=6,propDRR=1)
#' @export
DRRsetup <- function(numLoci,ploidy,propDRR) {
      DRR <- matrix(0,numLoci,2)
      rownames(DRR) <- 1:numLoci
      colnames(DRR) <- c("DRR","Simple DDR")
      DRR <- as.data.frame(DRR)
      if (ploidy == 6) {
          DRR[,1] <- sample(c(rep(0,numLoci*(1-propDRR)),runif(numLoci*propDRR,0.01,0.2727)),replace=FALSE)
      }
      if (ploidy == 4) {
          DRR[,1] <- sample(c(rep(0,numLoci*(1-propDRR)),runif(numLoci*propDRR,0.01,0.1428)),replace=FALSE)
      }
      for (thisLoc in 1:numLoci) {
          # thisLoc <-2
          if (DRR[thisLoc,1] == 0) {
             DRR[thisLoc,2] <- "min"
          }
          if (DRR[thisLoc,1] != 0) {
             DRR[thisLoc,2] <- "max"
          }
      }
      return(DRR)
    }
