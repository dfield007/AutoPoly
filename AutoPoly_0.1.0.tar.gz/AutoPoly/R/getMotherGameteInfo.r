#' returns probability of gametes from given phenotypes and genotypes
#'
#' @export
# 1. Hexaploid, marker="phenotype", DRR="min" ----
getMotherGameteInfoHexPhenoMin <- function (phenotype) {
  switch(length(phenotype),
         {## Monoallele
           gametes.table <- c("aaa")
           probs.table <- c(1.0)
         },
         {## Bialleles
           gametes.table <- c("aaa", "aab", "bbb", "abb")
           probs.table <- c(0.15, 0.35, 0.15, 0.35)
         },
         {## Trialleles
           gametes.table <- c("aaa", "aab", "aac", "bbb", "abb",
                              "bbc", "ccc", "acc", "bcc", "abc")
           probs.table <- c(0.03, 0.105, 0.105, 0.03, 0.105, 0.105,
                            0.03, 0.105, 0.105, 0.28)
         },
         {## Quadrialleles
           gametes.table <-c("aaa", "aab", "aac", "aad", "bbb", "abb",
                             "bbc", "bbd", "ccc", "acc", "bcc", "ccd",
                             "ddd", "add", "bdd", "cdd", "abc", "abd",
                             "acd", "bcd")
           probs.table <- c(0.005, 0.035, 0.035, 0.035, 0.005, 0.035,
                            0.035, 0.035, 0.005, 0.035, 0.035, 0.035,
                            0.005, 0.035, 0.035, 0.035, 0.14, 0.14,
                            0.14, 0.14)
         },
         {## Pentalleles
           gametes.table <- c("aab", "aac", "aad", "aae", "abb",
                              "bbc", "bbd", "bbe", "acc", "bcc",
                              "ccd", "cce", "add", "bdd", "cdd",
                              "dde", "aee", "bee", "cee", "dee",
                              "abc", "abd", "abe", "acd", "ace",
                              "ade", "bcd", "bce", "bde", "cde")
           probs.table <- c(0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01,
                            0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01,
                            0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.08,
                            0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08,
                            0.08, 0.08)
         },
         {## Hexalleles
           gametes.table <- c("abc", "abd", "abe", "abf", "acd",
                              "ace", "acf", "ade", "adf", "aef",
                              "bcd", "bce", "bcf", "bde", "bdf",
                              "bef", "cde", "cdf", "cef", "def")
           probs.table <- c(0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05,
                            0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05,
                            0.05, 0.05, 0.05, 0.05, 0.05, 0.05)
         }
         )  ##End switch()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,phenotype)  {
                            y <- match(thisVec,c("a","b","c","d","e","f"))
                            return(phenotype[y])
                          },
                          phenotype)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}
#' @export
# 2. Hexaploid, marker="phenotype", DRR="max" ----
getMotherGameteInfoHexPhenoMax <- function (phenotype) {
  switch(length(phenotype),
         {## Monoallele
           gametes.table <- c("aaa")
           probs.table <- c(1.0)},
         {## Bialleles
           gametes.table <- c("aaa", "aab", "bba", "bbb")
           probs.table <- c(0.1818, 0.3182, 0.3182, 0.1818)},
         {## Trialleles
           gametes.table <- c("aaa", "aab", "aac", "abc", "bba",
                              "bbb", "bbc", "cca", "ccb", "ccc")
           probs.table <- c(0.049, 0.108, 0.108, 0.204, 0.108, 0.049,
                            0.108, 0.108, 0.108, 0.049)
         },
         {## Quadrialleles
           gametes.table <- c("aaa", "aab", "aac", "aad", "abc",
                              "abd", "acd", "bba", "bbb", "bbc",
                              "bbd", "bcd", "cca", "ccb", "ccc",
                              "ccd", "dda", "ddb", "ddc", "ddd")
           probs.table <- c(0.015, 0.045, 0.045, 0.045, 0.102, 0.102,
                            0.102, 0.045, 0.015, 0.045, 0.045, 0.102,
                            0.044, 0.045, 0.015, 0.045, 0.045, 0.045,
                            0.045, 0.015)
         },
         {## Pentalleles
           gametes.table <- c("aaa", "aab", "aac", "aad", "aae",
                              "abc", "abd", "abe", "acd", "ace",
                              "ade", "bba", "bbb", "bbc", "bbd",
                              "bbe", "bcd", "bce", "bde", "cca",
                              "ccb", "ccc", "ccd", "cce", "cde",
                              "dda", "ddb", "ddc", "ddd", "dde",
                              "eea", "eeb", "eec", "eed", "eee")
           probs.table <- c(0.004, 0.020, 0.020, 0.020, 0.020, 0.058,
                            0.058, 0.058, 0.058, 0.058, 0.058, 0.020,
                            0.004, 0.020, 0.020, 0.020, 0.058, 0.058,
                            0.058, 0.020, 0.020, 0.004, 0.020, 0.020,
                            0.058, 0.020, 0.020, 0.020, 0.004, 0.020,
                            0.020, 0.020, 0.020, 0.020, 0.004)
         },
         {## Hexalleles
           gametes.table <- c("aab", "aac", "aad", "aae", "aaf",
                              "abc", "abd", "abe", "abf", "acd",
                              "ace", "acf", "ade", "adf", "aef",
                              "bba", "bbc", "bbd", "bbe", "bbf",
                              "bcd", "bce", "bcf", "bde", "bdf",
                              "bef", "cca", "ccb", "ccd", "cce",
                              "ccf", "cde", "cdf", "cef", "dda",
                              "ddb", "ddc", "dde", "ddf", "def",
                              "eea", "eeb", "eec", "eed", "eef",
                              "ffa", "ffb", "ffc", "ffd", "ffe")
           probs.table <- c(0.009090667, 0.009090667, 0.009090667,
                            0.009090667, 0.009090667, 0.036364000,
                            0.036364000, 0.036364000, 0.036364000,
                            0.036364000, 0.036364000, 0.036364000,
                            0.036364000, 0.036364000, 0.036364000,
                            0.009090667, 0.009090667, 0.009090667,
                            0.009090667, 0.009090667, 0.036364000,
                            0.036364000, 0.036364000, 0.036364000,
                            0.036364000, 0.036364000, 0.009090667,
                            0.009090667, 0.009090667, 0.009090667,
                            0.009090667, 0.036364000, 0.036364000,
                            0.036364000, 0.009090667, 0.009090667,
                            0.009090667, 0.009090667, 0.009090667,
                            0.036364000, 0.009090667, 0.009090667,
                            0.009090667, 0.009090667, 0.009090667,
                            0.009090667, 0.009090667, 0.009090667,
                            0.009090667, 0.009090667)
         }
         )  ##End switch()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,phenotype)  {
                            y <- match(thisVec,c("a","b","c","d","e","f"))
                            return(phenotype[y])
                          },
                          phenotype)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}
#' @export
# 3. Hexaploid, marker="genotype", DRR="min" ----
getMotherGameteInfoHexGenoMin <- function (motherGenotype) {
  switch(length(unique(motherGenotype)),
         {## Monoallele
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)
           gametes.table <- c("aaa")
           probs.table <- c(1.0)
         },
         {## Biallele
             #count table of each allele, sorted so most frequent comes first
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             if (max(thisTable)==5) { #Biallele type I, if max no. of allele is 5 must be type I
                gametes.table <- c("aaa", "aab")
                probs.table <- c(0.5, 0.5)
             } else if (max(thisTable)==4) { #Biallele type II, if max no. of allele is 4 must be type II
                gametes.table <- c("aaa", "aab", "abb")
                probs.table <- c(0.2, 0.6, 0.2)
             } else if (max(thisTable)==3) { #Biallele type III, if max no. of allele is 3 must be type III
                gametes.table <- c("aaa", "aab", "bbb", "abb")
                probs.table <- c(0.05, 0.45, 0.05, 0.45)
             }
         }, #end switch
         {## Triallele
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             if (max(thisTable)==4) { #Triallele type I if max no. of allele is 4 must be type I
                gametes.table <- c("aaa", "aab", "aac", "abc")
                probs.table <- c(0.2, 0.3, 0.3, 0.2)
             } else if (max(thisTable)==3) { #Triallele type II, if max no. of allele is 3 must be type II
                gametes.table <- c("aaa", "aab", "aac", "abb","bbc","abc")
                probs.table <- c(0.05, 0.3, 0.15, 0.15, 0.05, 0.3)
             } else if (max(thisTable)==2) { #Triallele type III, if max no. of allele is 2 must be type III
                gametes.table <- c("aab", "aac", "abb", "bbc", "acc", "bcc", "abc")
                probs.table <- c(0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.4)
             }
         },
         {## Quadriallele
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
             if (max(thisTable)==3) { #Quadriallele type I if max no. of allele is 3 must be type I
                  gametes.table <-c("aaa", "aab", "aac", "aad","abc", "abd", "acd", "bcd")
                  probs.table <- c(0.05, 0.15, 0.15, 0.15, 0.15, 0.15, 0.15, 0.05)
             } else if (max(thisTable)==2) { #Quadriallele type II if max no. of allele is 2 must be type II
                  gametes.table <-c("aab", "aac", "aad", "abb", "bbc", "bbd", "abc", "abd", "acd", "bcd")
                  probs.table <- c(0.1, 0.05, 0.05, 0.1, 0.05, 0.05, 0.2, 0.2, 0.1, 0.1)
             }
         },
         {## Pentallele
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
           gametes.table <- c("aab", "aac", "aad", "aae", "abc", "abd", "abe",
                              "acd", "ace", "ade", "bcd", "bce", "bde", "cde")
           probs.table <- c(0.05, 0.05, 0.05, 0.05, 0.1, 0.1, 0.1,
                            0.1, 0.1, 0.1, 0.05, 0.05, 0.05, 0.05)
         },
         {## Hexalleles
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
           gametes.table <- c("abc", "abd", "abe", "abf", "acd",
                              "ace", "acf", "ade", "adf", "aef",
                              "bcd", "bce", "bcf", "bde", "bdf",
                              "bef", "cde", "cdf", "cef", "def")
           probs.table <- c(0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05,
                            0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05,
                            0.05, 0.05, 0.05, 0.05, 0.05, 0.05)
         }
         )  ##End switch()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors

  thisGenoAllelesOrder<-names(thisTable)
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,thisGenoAllelesOrder)  {
                          # gametes.table<-strsplit(gametes.table,"")
                          #thisVec<-gametes.table[[2]]
                            y <- match(thisVec,c("a","b","c","d","e","f"))
                            return(thisGenoAllelesOrder[y])
                          },
                          thisGenoAllelesOrder)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}
#' @export
# 4. Hexaploid, marker="genotype", DRR="max" ----
getMotherGameteInfoHexGenoMax <- function (motherGenotype) {
  switch(length(unique(motherGenotype)),
         {## Monoallele
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)
           gametes.table <- c("aaa")
           probs.table <- c(1.0)
         },
         {## Biallele
             #count table of each allele, sorted so most frequent comes first
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             if (max(thisTable)==5) { #Biallele type I, if max no. of allele is 5 must be type I
                gametes.table <- c("aaa", "aab", "abb")
                probs.table <- c(0.546, 0.409, 0.045)
             } else if (max(thisTable)==4) { #Biallele type II, if max no. of allele is 4 must be type II
                gametes.table <- c("aaa", "aab", "bbb", "abb")
                probs.table <- c(0.255, 0.509, 0.018, 0.218)
             } else if (max(thisTable)==3) { #Biallele type III, if max no. of allele is 3 must be type III
                gametes.table <- c("aaa", "aab", "bbb", "abb")
                probs.table <- c(0.091, 0.409, 0.091, 0.409)
             }
         }, #end switch
         {## Triallele
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             if (max(thisTable)==4) { #Triallele type I if max no. of allele is 4 must be type I
                gametes.table <- c("aaa", "aab", "aac", "abb", "bbc", "acc", "bcc", "abc")
                probs.table <- c(0.255, 0.255, 0.255, 0.036, 0.009, 0.036, 0.009, 0.145)
             } else if (max(thisTable)==3) { #Triallele type II, if max no. of allele is 3 must be type II
                gametes.table <- c("aaa", "aab", "aac", "bbb", "abb", "bbc", "acc", "bcc", "abc")
                probs.table <- c(0.091, 0.273, 0.136, 0.018, 0.164, 0.055, 0.027, 0.018, 0.218)
             } else if (max(thisTable)==2) { #Triallele type III, if max no. of allele is 2 must be type III
                gametes.table <- c("aaa", "aab", "aac", "bbb", "abb", "bbc", "ccc","acc", "bcc", "abc")
                probs.table <- c(0.018, 0.109, 0.109, 0.018, 0.109, 0.109, 0.018, 0.109, 0.109, 0.292)
             }
         },
         {## Quadriallele
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
             if (max(thisTable)==3) { #Quadriallele type I if max no. of allele is 3 must be type I
                  gametes.table <-c("aaa", "aab", "aac", "aad", "abb", "bbc", "bbd", "acc", "bcc",
                                    "ccd", "add", "bdd", "cdd", "abc", "abd", "acd", "bcd")
                  probs.table <- c(0.0909, 0.1364, 0.1364, 0.1364, 0.0273, 0.0091, 0.0091, 0.0273, 0.0091,
                                    0.0091, 0.0273, 0.0091, 0.0091, 0.1091, 0.1091, 0.1091, 0.0364)
             } else if (max(thisTable)==2) { #Quadriallele type II if max no. of allele is 2 must be type II
                  gametes.table <-c("aaa", "aab", "aac", "aad", "bbb", "abb", "bbc", "bbd", "acc",
                                    "bcc", "ccd", "add", "bdd", "cdd", "abc", "abd", "acd", "bcd")
                  probs.table <- c(0.0182, 0.1091, 0.0545, 0.0545, 0.0182, 0.1091, 0.0545, 0.0545, 0.0182,
                                   0.0182, 0.0091, 0.0182, 0.0182, 0.0091, 0.1455, 0.1455, 0.0727, 0.0727)
             }
         },
         {## Pentallele
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
           gametes.table <- c("aaa", "aab", "aac", "aad", "aae", "abb",
                              "bbc", "bbd", "bbe", "acc", "bcc", "ccd",
                              "cce", "add", "bdd", "cdd", "dde", "aee",
                              "bee", "cee", "dee", "abc", "abd", "abe",
                              "acd", "ace", "ade", "bcd", "bce", "bde",
                              "cde")
           probs.table <- c(0.018, 0.055, 0.055, 0.055, 0.055, 0.018, 0.009,
                            0.009, 0.009, 0.018, 0.009, 0.009, 0.009, 0.018,
                            0.009, 0.009, 0.009, 0.018, 0.009, 0.009, 0.009,
                            0.073, 0.073, 0.073, 0.073, 0.073, 0.073, 0.036,
                            0.036, 0.036, 0.036)
         },
         {## Hexalleles
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
           gametes.table <- c("aab", "aac", "aad", "aae", "aaf", "abb", "bbc",
                              "bbd", "bbe", "bbf", "acc", "bcc", "ccd", "cce",
                              "ccf", "add", "bdd", "cdd", "dde", "ddf", "aee",
                              "bee", "cee", "dee", "eef", "aff", "bff", "cff",
                              "dff", "eff", "abc", "abd", "abe", "abf", "acd",
                              "ace", "acf", "ade", "adf", "aef", "bcd", "bce",
                              "bcf", "bde", "bdf", "bef", "cde", "cdf", "cef",
                              "def")
           probs.table <- c(0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009,
                            0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009,
                            0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009, 0.009,
                            0.036, 0.036, 0.036, 0.036, 0.036,0.036, 0.036, 0.036, 0.036, 0.036,
                            0.036, 0.036, 0.036, 0.036, 0.036,0.036, 0.036, 0.036, 0.036, 0.036)
         }
         )  ##End switch()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors

  thisGenoAllelesOrder<-names(thisTable)
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,thisGenoAllelesOrder)  {
                          # gametes.table<-strsplit(gametes.table,"")
                          #thisVec<-gametes.table[[2]]
                            y <- match(thisVec,c("a","b","c","d","e","f"))
                            return(thisGenoAllelesOrder[y])
                          },
                          thisGenoAllelesOrder)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}
#' @export
# 5. Tetraploid, marker="phenotype", DRR="min" ----
getMotherGameteInfoTetrPhenoMin <- function (phenotype) {
  switch(length(phenotype),
         {## Monoallele
           gametes.table <- c("aa")
           probs.table <- c(1.0)
         },
         {## Bialleles
           gametes.table <- c("aa","ab","bb")
           probs.table <- c(0.222,0.556,0.222)
         },
         {## Trialleles
           gametes.table <- c("aa", "ab", "ac", "bb", "bc", "cc")
           probs.table <- c(0.056, 0.222, 0.278, 0.111, 0.278, 0.056)
         },
         {## Quadrialleles
           gametes.table <- c("ab", "ac", "ad", "bc", "bd", "cd")
           probs.table <- c(0.167, 0.167, 0.167, 0.167, 0.167, 0.167)
         }
         )  ##End switch()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,phenotype)  {
                            y <- match(thisVec,c("a","b","c","d"))
                            return(phenotype[y])
                          },
                          phenotype)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}
#' @export
# 6. Tetraploid, marker="phenotype", DRR="max" ----
getMotherGameteInfoTetrPhenoMax <- function (phenotype) {
  switch(length(phenotype),
         {## Monoallele
           gametes.table <- c("aa")
           probs.table <- c(1.0)
         },
         {## Bialleles
           gametes.table <- c("aa","ab","bb")
           probs.table <- c(0.2619,0.4762,0.2619)
         },
         {## Trialleles
           gametes.table <- c("aa", "ab", "ac", "bb", "bc", "cc")
           probs.table <- c(0.095, 0.238, 0.238, 0.095, 0.238, 0.095)
         },
         {## Quadrialleles
           gametes.table <- c("aa", "ab", "ac", "ad", "bb", "bc", "bd", "cc", "cd", "dd")
           probs.table <- c(0.036, 0.143, 0.143, 0.143, 0.036, 0.143, 0.143, 0.036, 0.143, 0.036)
         }
         )  ##End switch()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,phenotype)  {
                            y <- match(thisVec,c("a","b","c","d"))
                            return(phenotype[y])
                          },
                          phenotype)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}
#' @export
# 7. Tetraploid, marker="genotype", DRR="min" ----
getMotherGameteInfoTetrGenoMin <- function (motherGenotype) {
  switch(length(unique(motherGenotype)),
         {## Monoallele
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)
           gametes.table <- c("aa")
           probs.table <- c(1.0)
         },
         {## Bialleles
             #count table of each allele, sorted so most frequent comes first
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             if (max(thisTable)==3) { #Biallele type I (simplex), if max no. of allele is 3
                gametes.table <- c("aa","ab")
                probs.table <- c(0.5,0.5)
             } else if (max(thisTable)==2) { #Biallele type II (duplex), if max no. of allele is 2
                gametes.table <- c("aa","ab","bb")
                probs.table <- c(0.167,0.667,0.167)
             }
         }, #end switch
         {## Trialleles
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             gametes.table <- c("aa", "ab", "ac", "bc")
             probs.table <- c(0.16666, 0.333333, 0.333333, 0.16666)
         },
         {## Quadrialleles
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)
           gametes.table <- c("ab", "ac", "ad", "bc", "bd", "cd")
           probs.table <- c(0.167, 0.167, 0.167, 0.167, 0.167, 0.167)
         }
         )  ##End switch()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors
  thisGenoAllelesOrder<-names(thisTable)
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,thisGenoAllelesOrder)  {
                          # gametes.table<-strsplit(gametes.table,"")
                          #thisVec<-gametes.table[[2]]
                            y <- match(thisVec,c("a","b","c","d"))
                            return(thisGenoAllelesOrder[y])
                          },
                          thisGenoAllelesOrder)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}
#' @export
# 8. Tetraploid, marker="genotype", DRR="max" ----
getMotherGameteInfoTetrGenoMax <- function (motherGenotype) {
  switch(length(unique(motherGenotype)),
         {## Monoallele
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)
           gametes.table <- c("aa")
           probs.table <- c(1.0)
         },
         {## Bialleles
             #count table of each allele, sorted so most frequent comes first
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             if (max(thisTable)==3) { #Biallele type I (simplex), if max no. of allele is 3
                gametes.table <- c("aa","ab","bb")
                probs.table <- c(0.536,0.429,0.035)
             } else if (max(thisTable)==2) { #Biallele type II (duplex), if max no. of allele is 2
                gametes.table <- c("aa","ab","bb")
                probs.table <- c(0.214,0.572,0.214)
             }
         }, #end switch
         {## Trialleles
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             gametes.table <- c("aa", "ab", "ac", "bc", "bb", "cc")
             probs.table <- c(0.214286, 0.285714, 0.285714, 0.142857, 0.03571, 0.03571)
         },
         {## Quadrialleles
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)
           gametes.table <- c("aa", "ab", "ac", "ad", "bc", "bd", "bb", "cc", "cd", "dd")
           probs.table <- c(0.036, 0.143, 0.143, 0.143, 0.143, 0.143, 0.036, 0.036, 0.143, 0.036)
         }
         )  ##End switch()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors
  thisGenoAllelesOrder<-names(thisTable)
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,thisGenoAllelesOrder)  {
                          # gametes.table<-strsplit(gametes.table,"")
                          #thisVec<-gametes.table[[2]]
                            y <- match(thisVec,c("a","b","c","d"))
                            return(thisGenoAllelesOrder[y])
                          },
                          thisGenoAllelesOrder)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}
#' @export
# 9. Diploid, marker="genotype" ----
getMotherGameteInfoDiploidGeno <- function (motherGenotype) {
  switch(length(unique(motherGenotype)),
         {## Monoallele
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)
           gametes.table <- c("a")
           probs.table <- c(1.0)
         },
         {## Bialleles
             #count table of each allele, sorted so most frequent comes first
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             gametes.table <- c("a","b")
             probs.table <- c(0.5,0.5)
         } #end switch
         )  ##End switch()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors
  thisGenoAllelesOrder<-names(thisTable)
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,thisGenoAllelesOrder)  {
                          # gametes.table<-strsplit(gametes.table,"")
                          #thisVec<-gametes.table[[2]]
                            y <- match(thisVec,c("a","b"))
                            return(thisGenoAllelesOrder[y])
                          },
                          thisGenoAllelesOrder)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}

###########################
#  General DRR Equations  #
###########################
#' @export
# 10. Tetraploid, marker="genotype", DRR="general" ----
getMotherGameteInfoTetrGenoGeneral <- function (motherGenotype,DRR) {
 switch(length(unique(motherGenotype)),
         {## Monoallele
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)
           gametes.table <- c("aa")
           probs.table <- c(1.0)
         },
         {## Bialleles
             #count table of each allele, sorted so most frequent comes first
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             if (max(thisTable)==3) { #Biallele type I (simplex), if max no. of allele is 3
                gametes.table <- c("aa","ab","bb")
                probs.table <- c((0.5+(DRR/4)),(0.5-(DRR/2)),(DRR/4))
             } else if (max(thisTable)==2) { #Biallele type II (duplex), if max no. of allele is 2
                gametes.table <- c("aa","ab","bb")
                probs.table <- c(((1/6)+(DRR/3)),((4/6)-((2*DRR)/3)),((1/6)+(DRR/3)))
             }
         },
         {## Trialleles
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             gametes.table <- c("aa", "ab", "ac", "bc", "bb", "cc")
             probs.table <- c(((1/6)+(DRR/3)),((1/3)-((DRR)/3)),((1/3)-((DRR)/3)),((1/6)-(DRR/6)),(DRR/4),(DRR/4))
         },
         {## Quadrialleles
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)
           gametes.table <- c("aa", "ab", "ac", "ad", "bc", "bd", "bb", "cc", "cd", "dd")
           probs.table <- c((DRR/4),((1/6)-(DRR/6)),((1/6)-(DRR/6)),((1/6)-(DRR/6)),((1/6)-(DRR/6)),((1/6)-(DRR/6)),(DRR/4),(DRR/4),
                              ((1/6)-(DRR/6)),(DRR/4))
         }
         )  ##End switch ()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors
  thisGenoAllelesOrder<-names(thisTable)
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,thisGenoAllelesOrder)  {
                          # gametes.table<-strsplit(gametes.table,"")
                          #thisVec<-gametes.table[[2]]
                            y <- match(thisVec,c("a","b","c","d"))
                            return(thisGenoAllelesOrder[y])
                          },
                          thisGenoAllelesOrder)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}
#' @export
# 11. Hexaploid, marker="genotype", DRR="general" ----
getMotherGameteInfoHexGenoGeneral <- function (motherGenotype,DRR) {
  switch(length(unique(motherGenotype)),
         {## Monoallele
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)
           gametes.table <- c("aaa")
           probs.table <- c(1.0)
         },
         {## Biallele
             #count table of each allele, sorted so most frequent comes first
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             if (max(thisTable)==5) { #Biallele type I, if max no. of allele is 5 must be type I
                gametes.table <- c("aaa", "aab", "abb")
                probs.table <- c(((3+DRR)/6),((3-(2*DRR))/6),(DRR/6))
             } else if (max(thisTable)==4) { #Biallele type II, if max no. of allele is 4 must be type II
                gametes.table <- c("aaa", "aab", "bbb", "abb")
                probs.table <- c(((3+(3*DRR))/15),((9-(5*DRR))/15),(DRR/15),((3+DRR)/15))
             } else if (max(thisTable)==3) { #Biallele type III, if max no. of allele is 3 must be type III
                gametes.table <- c("aaa", "aab", "bbb", "abb")
                probs.table <- c(((1+(3*DRR))/20),((9-(3*DRR))/20),((1+(3*DRR))/20),((9-(3*DRR))/20))
             }
         }, #end switch
         {## Triallele
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)
             if (max(thisTable)==4) { #Triallele type I if max no. of allele is 4 must be type I
                gametes.table <- c("aaa", "aab", "aac", "abb", "bbc", "acc", "bcc", "abc")
                probs.table <- c(((6+(6*DRR))/30),((9-(5*DRR))/30),((9-(5*DRR))/30),((4*DRR)/30),(DRR/30),((4*DRR)/30),(DRR/30),((6-(6*DRR))/30))
            } else if (max(thisTable)==3) { #Triallele type II, if max no. of allele is 3 must be type II
                gametes.table <- c("aaa", "aab", "aac", "bbb", "abb", "bbc", "acc", "bcc", "abc")
                probs.table <- c(((3+(9*DRR))/60),((18-(6*DRR))/60),((9-(3*DRR))/60),((4*DRR)/60),((9+(3*DRR))/60),((3+DRR)/60),((6*DRR)/60),
                                   ((4*DRR)/60),((18-(18*DRR))/60))
             } else if (max(thisTable)==2) { #Triallele type III, if max no. of allele is 2 must be type III
                gametes.table <- c("aaa", "aab", "aac", "bbb", "abb", "bbc", "ccc", "acc", "bcc", "abc")
                probs.table <- c(((4*DRR)/60),((6+(2*DRR))/60),((6+(2*DRR))/60),((4*DRR)/60),((6+(2*DRR))/60),((6+(2*DRR))/60),((4*DRR)/60),
                                  ((6+(2*DRR))/60),((6+(2*DRR))/60),((24-(24*DRR))/60))
             }
         },
         {## Quadriallele
             thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
             if (max(thisTable)==3) { #Quadriallele type I if max no. of allele is 3 must be type I
                  gametes.table <-c("aaa", "aab", "aac", "aad", "abb", "bbc", "bbd", "acc", "bcc",
                                    "ccd", "add", "bdd", "cdd", "abc", "abd", "acd", "bcd")
                  probs.table <- c(((3+(9*DRR))/60), ((9-(3*DRR))/60), ((9-(3*DRR))/60), ((9-(3*DRR))/60),
                                    ((6*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((6*DRR)/60), ((2*DRR)/60),
                                    ((2*DRR)/60), ((6*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((9-(9*DRR))/60),
                                    ((9-(9*DRR))/60), ((9-(9*DRR))/60), ((3-(3*DRR))/60))
             } else if (max(thisTable)==2) { #Quadriallele type II if max no. of allele is 2 must be type II
                  gametes.table <- c("aaa", "aab", "aac", "aad", "bbb", "abb", "bbc", "bbd", "acc",
                                    "bcc", "ccd", "add", "bdd", "cdd", "abc", "abd", "acd", "bcd")
                  probs.table <- c(((4*DRR)/60), ((6+(2*DRR))/60), ((3+DRR)/60), ((3+DRR)/60), ((4*DRR)/60), ((6+(2*DRR))/60),
                                     ((3+DRR)/60), ((3+DRR)/60), ((4*DRR)/60), ((4*DRR)/60), ((2*DRR)/60), ((4*DRR)/60), ((4*DRR)/60),
                                      ((2*DRR)/60), ((12-(12*DRR))/60), ((12-(12*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60))
             }
         },
         {## Pentallele
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
           gametes.table <- c("aaa", "aab", "aac", "aad", "aae", "abb",
                              "bbc", "bbd", "bbe", "acc", "bcc", "ccd",
                              "cce", "add", "bdd", "cdd", "dde", "aee",
                              "bee", "cee", "dee", "abc", "abd", "abe",
                              "acd", "ace", "ade", "bcd", "bce", "bde",
                              "cde")
           probs.table <- c(((4*DRR)/60), ((3+DRR)/60), ((3+DRR)/60), ((3+DRR)/60), ((3+DRR)/60), ((4*DRR)/60), ((2*DRR)/60),
                            ((2*DRR)/60), ((2*DRR)/60), ((4*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((4*DRR)/60),
                            ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((4*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
                            ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60),
                            ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60))
         },
         {## Hexalleles
           thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
           gametes.table <- c("aab", "aac", "aad", "aae", "aaf", "abb", "bbc",
                              "bbd", "bbe", "bbf", "acc", "bcc", "ccd", "cce",
                              "ccf", "add", "bdd", "cdd", "dde", "ddf", "aee",
                              "bee", "cee", "dee", "eef", "aff", "bff", "cff",
                              "dff", "eff", "abc", "abd", "abe", "abf", "acd",
                              "ace", "acf", "ade", "adf", "aef", "bcd", "bce",
                              "bcf", "bde", "bdf", "bef", "cde", "cdf", "cef",
                              "def")
           probs.table <- c(((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
                            ((2*DRR)/60), ((2*DRR)/60),((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
                            ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
                            ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),((3-(3*DRR))/60), ((3-(3*DRR))/60),
                            ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60),
                            ((3-(3*DRR))/60), ((3-(3*DRR))/60),((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60),
                            ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60))
         }
         )  ##End switch()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors

  thisGenoAllelesOrder<-names(thisTable)
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,thisGenoAllelesOrder)  {
                          # gametes.table<-strsplit(gametes.table,"")
                          #thisVec<-gametes.table[[2]]
                            y <- match(thisVec,c("a","b","c","d","e","f"))
                            return(thisGenoAllelesOrder[y])
                          },
                          thisGenoAllelesOrder)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}
#' @export
# 12. Tetraploid, marker="phenotype", DRR="general" ----
getMotherGameteInfoTetrPhenoGeneral <- function (motherPhenotype,segregationTable) {
  switch(length(unique(motherPhenotype)),
    {## Monoallele
      thisTable <- sort(table(motherPhenotype),decreasing=TRUE)
      gametes.table <- c("aa")
      probs.table <- probs.table <- as.numeric(segregationTable$Monoallele[,"aaaa"])
    },
    {## Bialleles
      #count table of each allele, sorted so most frequent comes first
      thisTable <- sort(table(motherPhenotype),decreasing=TRUE)
      gametes.table <- c("aa","ab","bb")
      probs.table <- probs.table <- as.numeric(segregationTable$Biallele[,"Pheno"])
    },
    {## Trialleles
      thisTable <- sort(table(motherPhenotype),decreasing=TRUE)
      gametes.table <- c("aa", "ab", "ac", "bc", "bb", "cc")
      probs.table <- as.numeric(segregationTable$Triallele[,"Pheno"])
      #probs.table <- c(((1/6)+(DRR/3)),((1/3)-((DRR)/3)),((1/3)-((DRR)/3)),((1/6)-(DRR/6)),(DRR/4),(DRR/4))
    },
    {## Quadrialleles
      thisTable <- sort(table(motherPhenotype),decreasing=TRUE)
      gametes.table <- c("aa", "ab", "ac", "ad", "bc", "bd", "bb", "cc", "cd", "dd")
      probs.table <- as.numeric(segregationTable$Quadriallele[,"abcd"])
      #probs.table <- c((DRR/4),((1/6)-(DRR/6)),((1/6)-(DRR/6)),((1/6)-(DRR/6)),((1/6)-(DRR/6)),((1/6)-(DRR/6)),(DRR/4),(DRR/4),
      #                 ((1/6)-(DRR/6)),(DRR/4))
    }
  )  ##End switch()
## Convert gametes.table from a vector of abc strings to a list of
## allele vectors
thisGenoAllelesOrder<-names(thisTable)
gametes.table <- lapply(strsplit(gametes.table,""),
                        function (thisVec,thisGenoAllelesOrder)  {
                          # gametes.table<-strsplit(gametes.table,"")
                          #thisVec<-gametes.table[[2]]
                          y <- match(thisVec,c("a","b","c","d"))
                          return(thisGenoAllelesOrder[y])
                        },
                        thisGenoAllelesOrder)
##Form the gamete names and assign these to gametes.table and
##probs.table
nms <- sapply(gametes.table,
              function(thisVec) {
                paste(thisVec,collapse=" ")
              })
names(gametes.table) <- nms
names(probs.table) <- nms
return(list(gametes=gametes.table, prob=probs.table))
##                    stringsAsFactors = FALSE))
}
#' @export
# 13. Hexaploid, marker="phenotype", DRR="general" ----
getMotherGameteInfoHexPhenoGeneral <- function (motherGenotype,segregationTable) {
   switch(length(unique(motherGenotype)),
  {
  ## Monoallele
  thisTable <- sort(table(motherGenotype),decreasing=TRUE)
  gametes.table <- c("aaa")
  probs.table <- c(1.0)
  },
  {## Biallele
    #count table of each allele, sorted so most frequent comes first
    thisTable <- sort(table(motherGenotype),decreasing=TRUE)
   # if (max(thisTable)==5) { #Biallele type I, if max no. of allele is 5 must be type I
    #  gametes.table <- c("aaa", "aab", "abb")
     # probs.table <- c(((3+DRR)/6),((3-(2*DRR))/6),(DRR/6))
    #} else if (max(thisTable)==4) { #Biallele type II, if max no. of allele is 4 must be type II
      gametes.table <- c("aaa", "aab", "bbb", "abb")
      probs.table <- as.numeric(segregationTable$Biallele[,"Pheno"])
    # probs.table <- c(((3+(3*DRR))/15),((9-(5*DRR))/15),(DRR/15),((3+DRR)/15))
    #} else if (max(thisTable)==3) { #Biallele type III, if max no. of allele is 3 must be type III
    #  gametes.table <- c("aaa", "aab", "bbb", "abb")
    #  probs.table <- c(((1+(3*DRR))/20),((9-(3*DRR))/20),((1+(3*DRR))/20),((9-(3*DRR))/20))
    #}
  }, #end switch
  {## Triallele
    thisTable <- sort(table(motherGenotype),decreasing=TRUE)
  #  if (max(thisTable)==4) { #Triallele type I if max no. of allele is 4 must be type I
  #    gametes.table <- c("aaa", "aab", "aac", "abb", "bbc", "acc", "bcc", "abc")
  #    probs.table <- c(((6+(6*DRR))/30),((9-(5*DRR))/30),((9-(5*DRR))/30),((4*DRR)/30),(DRR/30),((4*DRR)/30),(DRR/30),((6-(6*DRR))/30))
  #  } else if (max(thisTable)==3) { #Triallele type II, if max no. of allele is 3 must be type II
  #    gametes.table <- c("aaa", "aab", "aac", "bbb", "abb", "bbc", "acc", "bcc", "abc")
  #    probs.table <- c(((3+(9*DRR))/60),((18-(6*DRR))/60),((9-(3*DRR))/60),((4*DRR)/60),((9+(3*DRR))/60),((3+DRR)/60),((6*DRR)/60),
  #                     ((4*DRR)/60),((18-(18*DRR))/60))
  #  } else if (max(thisTable)==2) { #Triallele type III, if max no. of allele is 2 must be type III
      gametes.table <- c("aaa", "aab", "aac", "bbb", "abb", "bbc", "ccc", "acc", "bcc", "abc")
      probs.table <- as.numeric(segregationTable$Triallele[,"Pheno"])

   # probs.table <- c(((4*DRR)/60),((6+(2*DRR))/60),((6+(2*DRR))/60),((4*DRR)/60),((6+(2*DRR))/60),((6+(2*DRR))/60),((4*DRR)/60),
  #                     ((6+(2*DRR))/60),((6+(2*DRR))/60),((24-(24*DRR))/60))
 #   }
  },
  {## Quadriallele
    thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
  #  if (max(thisTable)==3) { #Quadriallele type I if max no. of allele is 3 must be type I
  #    gametes.table <-c("aaa", "aab", "aac", "aad", "abb", "bbc", "bbd", "acc", "bcc",
  #                      "ccd", "add", "bdd", "cdd", "abc", "abd", "acd", "bcd")
  #    probs.table <- c(((3+(9*DRR))/60), ((9-(3*DRR))/60), ((9-(3*DRR))/60), ((9-(3*DRR))/60),
  ##                     ((6*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((6*DRR)/60), ((2*DRR)/60),
    #                   ((2*DRR)/60), ((6*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((9-(9*DRR))/60),
    #                   ((9-(9*DRR))/60), ((9-(9*DRR))/60), ((3-(3*DRR))/60))
  #  } else if (max(thisTable)==2) { #Quadriallele type II if max no. of allele is 2 must be type II
      gametes.table <- c("aaa", "aab", "aac", "aad", "bbb", "abb", "bbc", "bbd", "acc",
                         "bcc", "ccd", "add", "bdd", "cdd", "abc", "abd", "acd", "bcd")
      probs.table <- as.numeric(segregationTable$Quadriallele[,"Pheno"])

  #  probs.table <- c(((4*DRR)/60), ((6+(2*DRR))/60), ((3+DRR)/60), ((3+DRR)/60), ((4*DRR)/60), ((6+(2*DRR))/60),
  #                     ((3+DRR)/60), ((3+DRR)/60), ((4*DRR)/60), ((4*DRR)/60), ((2*DRR)/60), ((4*DRR)/60), ((4*DRR)/60),
  #                     ((2*DRR)/60), ((12-(12*DRR))/60), ((12-(12*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60))
  #  }
  },
  {## Pentallele
    thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
    gametes.table <- c("aaa", "aab", "aac", "aad", "aae", "abb",
                       "bbc", "bbd", "bbe", "acc", "bcc", "ccd",
                       "cce", "add", "bdd", "cdd", "dde", "aee",
                       "bee", "cee", "dee", "abc", "abd", "abe",
                       "acd", "ace", "ade", "bcd", "bce", "bde",
                       "cde")
    probs.table <- as.numeric(segregationTable$Pentallele[,"Pheno"])

  #  probs.table <- c(((4*DRR)/60), ((3+DRR)/60), ((3+DRR)/60), ((3+DRR)/60), ((3+DRR)/60), ((4*DRR)/60), ((2*DRR)/60),
  #                   ((2*DRR)/60), ((2*DRR)/60), ((4*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((4*DRR)/60),
  #                   ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((4*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
  #                   ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60),
  #                   ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60))
  },
  {## Hexalleles
    thisTable <- sort(table(motherGenotype),decreasing=TRUE)  #count table of each allele
    gametes.table <- c("aab", "aac", "aad", "aae", "aaf", "abb", "bbc",
                       "bbd", "bbe", "bbf", "acc", "bcc", "ccd", "cce",
                       "ccf", "add", "bdd", "cdd", "dde", "ddf", "aee",
                       "bee", "cee", "dee", "eef", "aff", "bff", "cff",
                       "dff", "eff", "abc", "abd", "abe", "abf", "acd",
                       "ace", "acf", "ade", "adf", "aef", "bcd", "bce",
                       "bcf", "bde", "bdf", "bef", "cde", "cdf", "cef",
                       "def")
    probs.table <- as.numeric(segregationTable$Hexallele[,"abcdef"])
    # probs.table <- c(((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
    #                 ((2*DRR)/60), ((2*DRR)/60),((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
    #                 ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
    #                 ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),((3-(3*DRR))/60), ((3-(3*DRR))/60),
    #                 ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60),
    #                 ((3-(3*DRR))/60), ((3-(3*DRR))/60),((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60),
    #                 ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60))
  }
         )  ##End switch()
  ## Convert gametes.table from a vector of abc strings to a list of
  ## allele vectors

  thisGenoAllelesOrder<-names(thisTable)
  gametes.table <- lapply(strsplit(gametes.table,""),
                          function (thisVec,thisGenoAllelesOrder)  {
                            # gametes.table<-strsplit(gametes.table,"")
                            #thisVec<-gametes.table[[2]]
                            y <- match(thisVec,c("a","b","c","d","e","f"))
                            return(thisGenoAllelesOrder[y])
                          },
                          thisGenoAllelesOrder)
  ##Form the gamete names and assign these to gametes.table and
  ##probs.table
  nms <- sapply(gametes.table,
                function(thisVec) {
                  paste(thisVec,collapse=" ")
                })
  names(gametes.table) <- nms
  names(probs.table) <- nms
  return(list(gametes=gametes.table, prob=probs.table))
  ##                    stringsAsFactors = FALSE))
}


