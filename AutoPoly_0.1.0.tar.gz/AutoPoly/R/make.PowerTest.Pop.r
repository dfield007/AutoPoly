#' Function to make simulated progeny array with known parent locations
#' @author David L. Field
#' @export
makePowerTestPop <- function(thisRunData, numLoci, ploidy, DRRtable, subsetSampMatePop,
                              simulations, numMothersSim, immigrantRate, referenceSize, simMissLoci,
                              selfing, errorRate) {
# Initial setup of functions depending on ploidy
#cat("\n ** Beginning Simulations.... **\n")
#flush.console()
  #############################################
  # a) Directing required hexaploid functions #
  #############################################
if (ploidy==6) {
    getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
}
  ################################################
  # b) Directing required tetraploid functions   #
  ################################################

if (ploidy==4) {
    getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
}

#############################
# Initial setup             #
# -population information   #
# -data output structures   #
#############################
strip.NAs <- function(vv) {
   return(vv[!is.na(vv)])
}
if (ploidy == 6) {
  MAXSEEDLINGGENOTYPES <- 10
} else if (ploidy == 4) {
  MAXSEEDLINGGENOTYPES <- 3
}

# Replace population numbers with letters and ID pasted with pop label
thisRunData[,"pop"] <- LETTERS[as.numeric(thisRunData[,"pop"])]
thisRunData[,"ID"] <- paste(thisRunData[,"pop"],thisRunData[,"ID"],sep="_")
thisRunData <- as.data.frame(thisRunData)

#####################
# Mating population #
#####################
# Random Subset of n individuals (currently set at 250) from 1000 at each subpopulation
pops <- unique(as.vector(thisRunData[,"pop"]))
numPopsHere <- length(pops)
numPerPopthisRunData <- nrow(thisRunData)/numPopsHere
matingPopulations <- matrix(0,(subsetSampMatePop*numPopsHere),ncol(thisRunData))
colnames(matingPopulations) <- colnames(thisRunData)
rownames(matingPopulations) <- 1: (subsetSampMatePop*numPopsHere)

for (thisPop in 1:numPopsHere) {
    # thisPop <- 1
    thisPopLabel <- pops[thisPop]
    # new Ids for subset data
    newIds <- (1:subsetSampMatePop) + (subsetSampMatePop*((thisPop)-1))
    # random numbers referring to rows in original data file
    thisPopFullDataSet <- thisRunData[as.vector(thisRunData[,"pop"])==thisPopLabel,]
    randomDraws <- sample(rownames(thisPopFullDataSet),subsetSampMatePop, replace = TRUE)
    # Random samples
    thisRandomSample <- as.matrix(thisPopFullDataSet[randomDraws,])
    rownames(thisRandomSample) <- NULL
    colnames(thisRandomSample) <- NULL
    matingPopulations[newIds,] <- thisRandomSample
}
rownames(matingPopulations) <- 1:nrow(matingPopulations)
colnames(matingPopulations) <- colnames(thisRunData)
inDataMatingPopulations  <- as.data.frame(matingPopulations)

#####################
# Reference Samples #              nrow(referenceSampleRowNum)
#####################
# 1. Randomly select adults to act reference samples amd mothers in each population
# Recording Rownames referring to these individuals
referenceSampleRowNum <- matrix(0,referenceSize,numPopsHere)
colnames(referenceSampleRowNum) <- pops
rownames(referenceSampleRowNum) <- paste("Ref",1:referenceSize,sep="")
for (thisPop in pops) {
    # thisPop <- pops[2]
    thisPopData <- inDataMatingPopulations[inDataMatingPopulations$pop == thisPop,]
    thisPopRowNames <- rownames(thisPopData)
    randomID <- as.vector(sample(thisPopRowNames,referenceSize,replace=FALSE))
    referenceSampleRowNum[,thisPop] <- randomID
}
# 2. Randomly select subset of reference individuals to be mothers
mothersSelectedRowNum <- referenceSampleRowNum[1:numMothersSim,]
rownames(mothersSelectedRowNum) <- paste("Mother",1:numMothersSim,sep="")
# Cut back reference list
referenceSampleRowNum <- referenceSampleRowNum[(numMothersSim+1):referenceSize,]

# 3. find the IDs of the adults selected to be reference samples in each population
referenceSampleNames <- matrix(0,nrow(referenceSampleRowNum),numPopsHere)
colnames(referenceSampleNames) <- colnames(referenceSampleRowNum)
rownames(referenceSampleNames) <- rownames(referenceSampleRowNum)
for (thisPop in pops) {
    # thisPop <- pops[2]
    referenceSampleRows <- as.numeric(referenceSampleRowNum[,thisPop])
    referenceSampleNames[,thisPop] <- as.vector(inDataMatingPopulations[referenceSampleRows,"ID"])
}

# 4. find the IDs of the adults selected to be mothers in each population
mothersSelectedNames <- matrix(0,nrow(mothersSelectedRowNum),numPopsHere)
colnames(mothersSelectedNames) <- colnames(mothersSelectedRowNum)
rownames(mothersSelectedNames) <- rownames(mothersSelectedRowNum)
for (thisPop in pops) {
    # thisPop <- pops[2]
    referenceSampleRows <- as.numeric(mothersSelectedRowNum[,thisPop])
    mothersSelectedNames[,thisPop] <- as.vector(inDataMatingPopulations[referenceSampleRows,"ID"])
}

## Add additional column to inDataAdults which records the actual population of origin
newOne <- matrix(0,nrow(inDataMatingPopulations),2)
colnames(newOne) <- c("ActualCross","CrossType")
inDataAdults <- cbind(inDataMatingPopulations,newOne)

## Matrix for simulated progeny
simCrosses <- matrix(0,simulations,ncol(inDataAdults))
colnames(simCrosses) <- colnames(inDataAdults)

## Number of simulations
numMothersSimTotal <- numMothersSim*numPopsHere
numSimsPerMum <- as.integer(simulations/numMothersSimTotal)
numSimsPerMumOutcrossed <- as.integer(numSimsPerMum*(1-selfing))
numSimsPerMumSelfed <- numSimsPerMum - numSimsPerMumOutcrossed
numSimsPerMumOutcrossed_External <- numSimsPerMumOutcrossed*immigrantRate
numSimsPerMumOutcrossed_Internal <- numSimsPerMumOutcrossed*(1-immigrantRate)

# Sets the start of ID labels for simulated progeny from current mother
flag<-0

##################################
## Begin loop over populations  ##
##################################
#cat("\n Processing Population..")
for (thisPop in 1:numPopsHere) {
    # thisPop <- 1
#    cat("",thisPop,".")
    flush.console()
    # thisPop <- 1
    thisPopLabel <- pops[thisPop]
    thisPopMatingSet <- inDataAdults[as.vector(inDataAdults[,"pop"])==thisPopLabel,]
    otherPopMatingSet <- inDataAdults[as.vector(inDataAdults[,"pop"])!=thisPopLabel,]
    IndividualsThisPop <- as.vector(thisPopMatingSet[,"ID"])
    mothersThisPop <- as.vector(mothersSelectedNames[,thisPop])
    IndividualsOtherPops <- as.vector(otherPopMatingSet[,"ID"])

    ###############################################
    ## Begin loop over mothers in current pop    ##
    ###############################################
    for (thisMother in 1:length(mothersThisPop)) {
        # thisMother <- 1
        ActualCrosses_InternalMatrix <- NULL
        ActualCrosses_ExternalMatrix <- NULL
        ActualInternalCrossList <- NULL
        ActualExternalCrossList <- NULL
        ActualCrossesCombined <- NULL
        thisMotherLabel <- mothersThisPop[thisMother]
        thisMotherInData <- thisPopMatingSet[thisPopMatingSet$ID == thisMotherLabel,]
        if (nrow(thisMotherInData) > 1) {
          thisMotherInData <- thisMotherInData[1,]
        }

        # Selfing
        if (selfing > 0) {
          # no code yet
        }
        # Outcrossing
        SimProgenyTracker <- flag + (1:(numSimsPerMumOutcrossed))
        outcrossParentsInternal <- sample(IndividualsThisPop,numSimsPerMumOutcrossed_Internal,replace=TRUE)
        outcrossParentsExternal <- sample(IndividualsOtherPops,numSimsPerMumOutcrossed_External,replace=TRUE)

        # Matrix to keep track of actual crosses - Internal
        ActualCrosses_InternalMatrix <- matrix(0,numSimsPerMumOutcrossed_Internal,2)
        colnames(ActualCrosses_InternalMatrix) <- c("MotherLocation", "FatherLocation")
        # External
        ActualCrosses_ExternalMatrix <- matrix(0,numSimsPerMumOutcrossed_External,2)
        colnames(ActualCrosses_ExternalMatrix) <- c("MotherLocation", "FatherLocation")
        # Internal crosses
        # Mother from pop
        ActualCrosses_InternalMatrix[,"MotherLocation"] <- thisPopLabel
        # Father from pop (Ineternal crosses)
        ActualCrossesInternalTemp <- strsplit(outcrossParentsInternal,"_")
        for (thisFatherPop in 1:numSimsPerMumOutcrossed_Internal) {
            # thisFatherPop <- 1
            ActualCrosses_InternalMatrix[thisFatherPop,"FatherLocation"] <- ActualCrossesInternalTemp[[thisFatherPop]][1]
        }
        # External crosses
        # Mother from pop
        ActualCrosses_ExternalMatrix[,"MotherLocation"] <- thisPopLabel
        # Father from pop (Ineternal crosses)
        ActualCrossesExternalTemp <- strsplit(outcrossParentsExternal,"_")
        for (thisFatherPop in 1:numSimsPerMumOutcrossed_External) {
            # thisFatherPop <- 1
            ActualCrosses_ExternalMatrix[thisFatherPop,"FatherLocation"] <- ActualCrossesExternalTemp[[thisFatherPop]][1]
        }
        ActualInternalCrossList <- paste(ActualCrosses_InternalMatrix[,1],ActualCrosses_InternalMatrix[,2],sep="_")
        ActualExternalCrossList <- paste(ActualCrosses_ExternalMatrix[,1],ActualCrosses_ExternalMatrix[,2],sep="_")
        ActualCrossesCombined <- c(ActualInternalCrossList,ActualExternalCrossList)
        # send progeny information
        simCrosses[SimProgenyTracker,"pop"] <- thisPopLabel
        simCrosses[SimProgenyTracker,"ID"] <- paste(SimProgenyTracker,"s",sep="_")
        simCrosses[SimProgenyTracker,"mother"] <- thisMotherLabel
        simCrosses[SimProgenyTracker,"ActualCross"] <- ActualCrossesCombined
        simCrosses[SimProgenyTracker,"CrossType"] <- c(rep("W_POP",numSimsPerMumOutcrossed_Internal),
                                                          rep("B_POP",numSimsPerMumOutcrossed_External))

        ##########################
        ## Begin loop over loci ##
        ##########################
        for (thisLocus in 1:numLoci) {
          # thisLocus <- 1
          ##current locus
          locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
          # object to build up vector of gametes from mother and fathers
          theseFatherGametesInternal <- NULL
          theseFatherGametesExternal <- NULL
          # Pull out current DRR
          ###############
          # General DRR #
          ###############
         # if (DRRtype == "general") {
          DRR <- DRRtable[thisLocus,1]
             # Pull out functions for particular DRR at this locus
            if (ploidy==6) {
                if (marker == "genotype") {
                    getMotherGameteInfo <- getMotherGameteInfoHexGenoGeneral # segregation ratios: gametes from individual
                }
                if (marker == "phenotype") {
                        getMotherGameteInfo <- getMotherGameteInfoHexPhenoGeneral # segregation ratios: gametes from individual
                }
              }
            if (ploidy==4) {
                if (marker == "genotype") {
                  # New approach - no dont use it here for genotype data
                  #segTableThisLocus <- segTable[[thisLocus]]
                  # OLD approach
                  getMotherGameteInfo <- getMotherGameteInfoTetrGenoGeneral # segregation ratios: gametes from individual
                }
                if (marker == "phenotype") {
                  getMotherGameteInfo <- getMotherGameteInfoTetrPhenoGeneral # segregation ratios: gametes from individual
                }
              }
        #  }
          ##########################################
          # Sampling gametes from current mother  ##
          ##########################################
          # Possible gametes and frequencies from current mother
          motherGenotype <- as.vector(unlist(thisMotherInData[,locusRange]))
          motherGametes <- getMotherGameteInfo(motherGenotype,DRR)
          thisMother_Gametes <- as.vector(names(motherGametes$prob))
          thisMother_Probs <- as.vector(motherGametes$prob)
          # Gamete samples for internal crosses (within population mating events)
          thisMother_sample1 <- sample(thisMother_Gametes,numSimsPerMumOutcrossed_Internal,replace=TRUE,thisMother_Probs)
          thisMother_sample1 <- t(matrix(unlist(strsplit(thisMother_sample1," ")),ploidy/2,))
          # Gamete samples for internal crosses (between population mating events)
          thisMother_sample2 <- sample(thisMother_Gametes,numSimsPerMumOutcrossed_External,replace=TRUE,thisMother_Probs)
          thisMother_sample2 <- t(matrix(unlist(strsplit(thisMother_sample2," ")),ploidy/2,))

          ###################################
          # Sampling gametes from fathers  ##
          ###################################
          # Sampling of n gametes from internal (local) fathers
          for (thisParentInternal in 1:numSimsPerMumOutcrossed_Internal) {
              # thisParentInternal <- 1
              thisFatherInternalID <- outcrossParentsInternal[thisParentInternal]
              thisFatherInData <- thisPopMatingSet[thisPopMatingSet$ID == thisFatherInternalID,]
              if (nrow(thisFatherInData) > 1) {
                thisFatherInData <- thisFatherInData[1,]
              }
              fatherGenotype <- as.vector(unlist(thisFatherInData[,locusRange]))
              fatherGametes <- getMotherGameteInfo(fatherGenotype,DRR)
              thisFather_Gametes <- as.vector(names(fatherGametes$prob))
              thisFather_Probs <- as.vector(fatherGametes$prob)
              # Sample Father gamete
              thisFather_sample <- as.vector(sample(thisFather_Gametes,1,replace=TRUE,thisFather_Probs))
              theseFatherGametesInternal <- c(theseFatherGametesInternal,thisFather_sample)

          }

          # Sampling of n gametes from external (other population) fathers
          # otherPopMatingSet$ID

          for (thisParentExternal in 1:numSimsPerMumOutcrossed_External) {
              # thisParentExternal <- 1
              thisFatherExternalID <- outcrossParentsExternal[thisParentExternal]
              thisFatherInData <- otherPopMatingSet[otherPopMatingSet$ID == thisFatherExternalID,]
              if (nrow(thisFatherInData) > 1) {
                thisFatherInData <- thisFatherInData[1,]
              }
              fatherGenotype <- as.vector(unlist(thisFatherInData[,locusRange]))
              fatherGametes <- getMotherGameteInfo(fatherGenotype,DRR)
              thisFather_Gametes <- as.vector(names(fatherGametes$prob))
              thisFather_Probs <- as.vector(fatherGametes$prob)
              # Sample Father gamete
              thisFather_sample <- as.vector(sample(thisFather_Gametes,1,replace=TRUE,thisFather_Probs))
              theseFatherGametesExternal <- c(theseFatherGametesExternal,thisFather_sample)
          }
          # combine gametes to form zygotes
          theseFatherGametesInternal <- t(matrix(unlist(strsplit(theseFatherGametesInternal," ")),ploidy/2,))
          theseFatherGametesExternal <- t(matrix(unlist(strsplit(theseFatherGametesExternal," ")),ploidy/2,))
          newProgenyInternal <- cbind(thisMother_sample1,theseFatherGametesInternal)
          newProgenyExternal <- cbind(thisMother_sample2,theseFatherGametesExternal)
          newProgenyTotal <- rbind(newProgenyInternal,newProgenyExternal)
          # send to new dataframe
          simCrosses[SimProgenyTracker,locusRange] <- newProgenyTotal
          # head(simCrosses)
        } # end loop over loci
      # When finished with this mum, increase flag
      flag <- max(SimProgenyTracker)
      # Also empty various progeny collection objects
      newProgenyTotal <- NULL
      newProgenyInternal <- NULL
      newProgenyExternal <- NULL
      outcrossParentsInternal <- NULL
      outcrossParentsExternal <- NULL
    } # end loop over mothers
 } # end loop over populations

# combine simulated progeny with reference sample and mothers
adultReferenceData <- matrix(0,referenceSize*numPopsHere,ncol(thisRunData))
colnames(adultReferenceData) <- colnames(thisRunData)
adultReferenceData <- as.data.frame(adultReferenceData)
for (thisPop in 1:numPopsHere) {
    # thisPop <- 1
    referenceSampleRows <- as.numeric(referenceSampleRowNum[,thisPop])
    motherSampleRows <- as.numeric(mothersSelectedRowNum[,thisPop])
    adultReferenceDataTemp <- as.matrix(rbind(inDataMatingPopulations[motherSampleRows,],inDataMatingPopulations[referenceSampleRows,]))
    #rownames(adultReferenceDataTemp) <- NULL
    rowRange <- (thisPop-1)*referenceSize + 1:referenceSize
    adultReferenceData[rowRange,] <- adultReferenceDataTemp
}

# Add addtional columns to reference data (Actual Cross, Cross Type)
newOne2 <- matrix(0,nrow(adultReferenceData),2)
colnames(newOne2) <- c("ActualCross","CrossType")
adultReferenceData <- cbind(adultReferenceData,newOne2)
# Combine reference data with new progeny
Reference_NewProgeny_inData <- rbind(adultReferenceData,simCrosses)

return(Reference_NewProgeny_inData)


}
