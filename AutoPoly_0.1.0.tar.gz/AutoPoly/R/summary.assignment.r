#' summary statistics for population assignment
#'
#' final posthoc and summary statistics for population assignment.
#' Other fuctions must be run prior to this function to generate required data (see details)
#' @param inData dataframe, genotype/phenotype data.
#' @param results list, output from population assignment using \code{\link{assignmentPheno}} or \code{\link{assignmentGeno}}
#' @param simulationResults matrix, output from simulations of population assignment.
#' @param ploidy numeric, number of homologous chromosomes. Must be 4 or 6 (i.e. tetraploid or hexaploid).
#' @param numLoci numeric, number of loci in the data set.
#' @param marker character, must be either “phenotype” (allele copy number unknown) or “genotype” (allele copy number known).
#' @param motherknown logical, must be either TRUE (i.e. progeny collected from known mothers but father unknown) or FALSE (i.e. progeny from unknown mother or father).
#' @param epsilon numeric, proportion of lowest likelihood to adjust for missing locus data (see details)
#' @details
#' \emph{Required data input}
#' \itemize{
#'  \item {allele frequencies must be provided and can be calculated using: \code{\link{alleleFreqPheno}}}
#'  \item {gamete frequencies must be provided and can be calculated using: \code{\link{gameteFreq}}}
#'  \item {expected segregation ratio must be provided and can be calculated using: \code{\link{makeGameteSegTable}}}
#' }
#' \emph{Output data file}
#' \itemize{
#'  \item {A dataframe sent to file: "assignmentLikelihoods.csv". With the follwing headers}
#'  \item {LogL1. Log likelihood of the highest ranking population of origin}
#'  \item {LogL2. Log likelihood of the 2nd highest ranking population of origin}
#'  \item {Delta1. Difference in log likelihood of the 1st and 2nd highest ranking population of origin}
#'  \item {Critical values. *** = 0.05, ** = 0.1, * = 0.2}
#'  \item {numOKLoci. The number of loci with data}
#'  \item {missing locus. Lists which loci had missing data}
#'  \item {mother-seedling (no. mismatch). The number of mother-offspring locus mismatches.}
#'  \item {mother-seedling (mismatched loci). Which loci exhibited a mother-offspring mismatch.}
#' }
#' @return procudes a dataframe (sent to file) with the final assignment probabilities and confidence intervals.
#' @author David L. Field
#' @examples
#' # access data provided with AutoPoly
#' data(Eremophila)
#' write.csv(Eremophila,"Eremophila_mumKnown.csv",quote=F,row.names=F)
#'
#' # Step 1. Make two tables with the rates of Double Reduction at each locus.
#' # i.e. DRRtable_1 (used for simulations) & DRRtable_2 (assumed DRR used for assignment testing)
#' DRRtable_1 <- DRRsetup(numLoci=6,ploidy=6,propDRR=1)
#' DRRtable_2 <- DRRtable_1
#' DRRtable_2[,1] <- 0.13635
#'
#' # 2. import and process data
#' EremophilaData <- inputData("Eremophila_mumKnown.csv",numLoci=6,lociMin=5,ploidy=6,marker="phenotype",cohorts=T,motherknown=T,DRRtable_1)
#' # 3. Make a new gamete segregation table (this calculates the expected segregation ratios at each locus for all phenotypes)
#' segTable_1 <- makeGameteSegTable(ploidy=6,DRRtable_1)
#' segTable_2 <- makeGameteSegTable(ploidy=6,DRRtable_2)
#'
#' # 4. allele frequencies
#' alleleFreq <- alleleFreqPheno(EremophilaData,numLoci=6,ploidy=6,replacement=T)
#'
#' # 5. Calculate gamete frequencies
#' # Using DRRtable_1 (true DRR for simulations)
#' # Note: Adjust DRRtable_1 and DRRtable_2 to examine the impact of deviations from the true DRR
#' gameteFreq_1 <- gameteFreq(EremophilaData,alleleFreq,numLoci=6,
#' ploidy=6,DRRtable_1,DRRtype="general")
#' # Using DRRtable_2 (assumed DRR for assignment testing and simulations)
#' gameteFreq_2 <- gameteFreq(EremophilaData,alleleFreq,
#' numLoci=6,ploidy=6,DRRtable_2,DRRtype="general")
#'
#' # 6. simulate assignment (to obtain credible intervals)
#' simulationEremophila <- simAssignmentMums(inData=EremophilaData, alleleFrequencies=alleleFreq,
#'   gameteFreq_actual=gameteFreq_1, gameteFreq_est=gameteFreq_2, ploidy=6,marker="phenotype", numLoci=6,
#'   selfing=0.1, DRRtable_actual=DRRtable_1, DRRtable_est=DRRtable_2, segTable_actual=segTable_1,segTable_est=segTable_2,
#'   DRRtype="general", simMissLoci=0, lociMin=1, epsilon=0.1,
#'   errorRate=0.01, output.txt=F,numAdultsSim=50,numMothersSim=10,
#'   numOffspringSim=5000,fixMothersSim=F,immRateSim=0.3)
#'
#' # 7. Run assignment
#' EremophilaAssignment <- assignmentPheno(inData=EremophilaData,alleleFrequencies=alleleFreq,gameteFrequencies=gameteFreq_2,
#'   numLoci=6,ploidy=6,motherknown=T,DRRtable_2,DRRtype="general",segregationRatios=segTable_2)
#'
#' # 8. Summary
#'  summaryEremophilaAssignment <- summaryAssignment(EremophilaData, EremophilaAssignment, simulationEremophila, ploidy=6,numLoci=6,
#'     marker="phenotype", motherknown=TRUE, epsilon=0.1)
#' @export
summaryAssignment <- function (inData, results, simulationResults, ploidy, numLoci, marker, motherknown, epsilon)  {
  # inData <- EremophilaData
  # results <- EremophilaAssignment


    cat("\n ** Assignment Summary Statistics.... **\n")
    # Run posthoc tests on REAL individuals   #
    # running posthoc
    realPostHoc <- postHocTests(inData,motherknown,numLoci,results,epsilon)
    # Mismatched loci for rank1 & rank2
    mismatchTable <- matrix(0,nrow(realPostHoc),7)
    colnames(mismatchTable) <- c("missing locus","mother-seedling (no. mismatch)","mother-seedling (mismatched loci)",
                                 "seedling-population (no. mismatched1)","seedling-population (loci mismatch1)",
                                 "seedling-population (no. mismatched2)","seedling-population (loci mismatch2)")
    # multilocus scores of rank1 & 2
    likelihoodTable<-matrix(0,nrow(realPostHoc),2)
    colnames(likelihoodTable)<-c("LogL1", "LogL2")
    allPopnsAllCombos<-NULL
    allPopns <- unique(inData$pop)
    allPopnsAllCombos<-allPopns
    numPopns<-length(allPopns)
    numComboandPops<-length(allPopnsAllCombos)
    if (motherknown==TRUE) {
        combinedScoresFull <- matrix(0,nrow(realPostHoc),ncol=numPopns)
        rownames(combinedScoresFull)<-rownames(realPostHoc)
        colnames(combinedScoresFull)<-allPopns

    } else if (motherknown==FALSE) {
        # possible F1 combinations
        # Required later in assignment test for part c) #
        allPopns <- unique(inData$pop)
        numPopns <- length(allPopns)
        noPopCombinations<-(numPopns*(numPopns-1))/2
        popCombos<-combinations(numPopns,2,allPopns,repeats=FALSE)
        popComboMatrix<-matrix(0,1,noPopCombinations)
        for (thisCombo in 1:nrow(popCombos)) {
            #test thisCombo<-1
            Combo<- popCombos[thisCombo,]
            popComboMatrix[1,thisCombo]<-paste(Combo,collapse=" ")
            #unlist(strsplit(Combo," "))
        }
        allPopnsAllCombos<-c(allPopns,popComboMatrix[1,])
        numComboandPops<-length(allPopnsAllCombos)

    }

    # Begin loop over seedlings
    for (thisSeedling in 1:nrow(realPostHoc)) {
        # test thisSeedling <- 13
        # realPostHoc[1:10,1:10]
        thisSeedlingName <- as.vector(realPostHoc[thisSeedling,"seedling"])
        rank1 <- as.vector(realPostHoc[thisSeedling,"1"])
        rank2 <- as.vector(realPostHoc[thisSeedling,"2"])
        likelihoodTable[thisSeedling,1] <- realPostHoc[thisSeedling,rank1]
        likelihoodTable[thisSeedling,2] <- realPostHoc[thisSeedling,rank2]
        for (thisLocus in 1:numLoci) {
            #test thisLocus <- 1
            colRange <- ((thisLocus-1)*numComboandPops) + (1:numComboandPops)
            locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
            likelihoods <- results$LScores[thisSeedlingName,colRange]
            MotherSeedlingMisMatch <- results$seedlingStatus[thisSeedling,thisLocus]
            thisSeedlingData <- inData[thisSeedlingName,locusRange]
            # Seedling missing locus data
            if (all(is.na(thisSeedlingData))) {
                mismatchTable[thisSeedling,"missing locus"]<-paste(as.vector(mismatchTable[thisSeedling,"missing locus"]),
                                                                   paste("locus",thisLocus,sep="."),collapse=",")
            }
            # Seedlings with data
            if (any(!is.na(thisSeedlingData))) {
                # Seedlings with data but not likelihoods at any populations (mismatched with all pops(results in NaN))
                if (all(likelihoods=="NaN")) {
                    mismatchTable[thisSeedling,1]<-as.numeric(mismatchTable[thisSeedling,1])+1
                    mismatchTable[thisSeedling,3]<-paste(as.vector(mismatchTable[thisSeedling,3]),paste("locus",thisLocus,sep="."),collapse=",")
                    mismatchTable[thisSeedling,2]<-as.numeric(mismatchTable[thisSeedling,2])+1
                    mismatchTable[thisSeedling,4]<-paste(as.vector(mismatchTable[thisSeedling,4]),paste("locus",thisLocus,sep="."),collapse=",")
                }
                # Seedlings with likelihoods, but for some populations this value is missing (mismatched)
                if (any(likelihoods=="NaN")) {
                    if (is.null(likelihoods[rank1])) {
                        mismatchTable[thisSeedling,1]<-as.numeric(mismatchTable[thisSeedling,1])+1
                        mismatchTable[thisSeedling,3]<-paste(as.vector(mismatchTable[thisSeedling,3]),paste("locus",thisLocus,sep="."),collapse=",")
                    }
                    if (is.null(likelihoods[rank2])) {
                        mismatchTable[thisSeedling,2]<-as.numeric(mismatchTable[thisSeedling,2])+1
                        mismatchTable[thisSeedling,4]<-paste(as.vector(mismatchTable[thisSeedling,4]),paste("locus",thisLocus,sep="."),collapse=",")
                    }
                    likeRank1 <- as.vector(likelihoods[paste(rank1,paste("L.",thisLocus,sep=""))])

                    if (likeRank1==0) {
                        mismatchTable[thisSeedling,1]<-as.numeric(mismatchTable[thisSeedling,1])+1
                        mismatchTable[thisSeedling,3]<-paste(as.vector(mismatchTable[thisSeedling,3]),paste("locus",thisLocus,sep="."),collapse=",")
                    }
                    if (is.na(likeRank1)) {
                      mismatchTable[thisSeedling,1] <- as.numeric(mismatchTable[thisSeedling,1])+1
                      mismatchTable[thisSeedling,3] <- paste(as.vector(mismatchTable[thisSeedling,3]),paste("locus",thisLocus,sep="."),collapse=",")
                    }

                    likeRank2 <-as.vector(likelihoods[paste(rank2,paste("L.",thisLocus,sep=""))])

                    if (likeRank2==0) {
                        mismatchTable[thisSeedling,2]<-as.numeric(mismatchTable[thisSeedling,2])+1
                        mismatchTable[thisSeedling,4]<-paste(as.vector(mismatchTable[thisSeedling,4]),paste("locus",thisLocus,sep="."),collapse=",")
                    }
                    if (is.na(likeRank2)) {
                      mismatchTable[thisSeedling,2]<-as.numeric(mismatchTable[thisSeedling,2])+1
                      mismatchTable[thisSeedling,4]<-paste(as.vector(mismatchTable[thisSeedling,4]),paste("locus",thisLocus,sep="."),collapse=",")
                    }
               }
               if (MotherSeedlingMisMatch == "MS") {
                 mismatchTable[thisSeedling,"mother-seedling (no. mismatch)"] <- as.numeric(mismatchTable[thisSeedling,"mother-seedling (no. mismatch)"])+1
                 mismatchTable[thisSeedling,"mother-seedling (mismatched loci)"] <- paste(as.vector(mismatchTable[thisSeedling,"mother-seedling (mismatched loci)"]),
                                                        paste("locus",thisLocus,sep="."),collapse=",")
               }
               if (MotherSeedlingMisMatch == "S") {
                  mismatchTable[thisSeedling,"seedling-population (no. mismatched1)"] <- as.numeric(mismatchTable[thisSeedling,"seedling-population (no. mismatched1)"])+1
                  mismatchTable[thisSeedling,"seedling-population (loci mismatch1)"] <- paste(as.vector(mismatchTable[thisSeedling,"seedling-population (loci mismatch1)"]),
                                                         paste("locus",thisLocus,sep="."),collapse=",")
                }
            }
        } # end locus loop

        # mismatchTable[thisSeedling,]
        # picking out which loci mismatched
        values1<-unlist(strsplit(as.character(mismatchTable[thisSeedling,1])," "))
        values2<-unlist(strsplit(as.character(mismatchTable[thisSeedling,2])," "))
        values3<-unlist(strsplit(as.character(mismatchTable[thisSeedling,3])," "))
        values4<-unlist(strsplit(as.character(mismatchTable[thisSeedling,4])," "))
        values5<-unlist(strsplit(as.character(mismatchTable[thisSeedling,5])," "))
        values6<-unlist(strsplit(as.character(mismatchTable[thisSeedling,6])," "))

        # Remove "0" from mismatch table
        if (all(values1=="0")) {
            mismatchTable[thisSeedling,1]<-0
        }
        if (any(values1!="0")) {
            mismatchTable[thisSeedling,1]<-paste(as.vector(values1[values1!="0"]),collapse=", ")
        }
        if (all(values2=="0")) {
            mismatchTable[thisSeedling,2]<-0
        }
        if (any(values2!="0")) {
            mismatchTable[thisSeedling,2]<-paste(as.vector(values2[values2!="0"]),collapse=", ")
        }
        if (all(values3=="0")) {
            mismatchTable[thisSeedling,3]<-0
        }
        if (any(values3!="0")) {
            mismatchTable[thisSeedling,3]<-paste(as.vector(values3[values3!="0"]),collapse=", ")
        }
        if (all(values4=="0")) {
          mismatchTable[thisSeedling,4]<-0
        }
        if (any(values4!="0")) {
          mismatchTable[thisSeedling,4]<-paste(as.vector(values4[values4!="0"]),collapse=", ")
        }
        if (all(values5=="0")) {
          mismatchTable[thisSeedling,5]<-0
        }
        if (any(values5!="0")) {
          mismatchTable[thisSeedling,5]<-paste(as.vector(values5[values5!="0"]),collapse=", ")
        }
        if (all(values6=="0")) {
          mismatchTable[thisSeedling,6]<-0
        }
        if (any(values6!="0")) {
          mismatchTable[thisSeedling,6]<-paste(as.vector(values6[values6!="0"]),collapse=", ")
        }
    } # end seedling loop

    # Critical values
    criticalValues<-matrix(0,nrow(realPostHoc),1)
    for (thisProgeny in 1:nrow(realPostHoc)) {
        #test   thisProgeny<-1
        if (realPostHoc[thisProgeny,"Delta1"] < as.numeric(as.vector(simulationResults[3,3]))) {     # fix this up
            criticalValues[thisProgeny,1] <- "-"
        }
        if (realPostHoc[thisProgeny,"Delta1"] > as.numeric(as.vector(simulationResults[3,3])) & realPostHoc[thisProgeny,"Delta1"] < as.numeric(as.vector(simulationResults[2,3]))) {
            criticalValues[thisProgeny,1] <- "*"
        }
        if (realPostHoc[thisProgeny,"Delta1"] > as.numeric(as.vector(simulationResults[2,3])) & realPostHoc[thisProgeny,"Delta1"] < as.numeric(as.vector(simulationResults[1,3]))) {
            criticalValues[thisProgeny,1] <- "**"
        }
        if (realPostHoc[thisProgeny,"Delta1"] > as.numeric(as.vector(simulationResults[1,3]))) {
            criticalValues[thisProgeny,1] <- "***"
        }
    }

     colnames(realPostHoc)
# Attach mismatch data & critical values to output
realPostHoc<- cbind(realPostHoc,mismatchTable)
realPostHoc<- cbind(realPostHoc,criticalValues)
realPostHoc<- cbind(realPostHoc,likelihoodTable)
summaryRealPostHoc <- cbind(realPostHoc[,1:3,drop=FALSE],realPostHoc[,"1",drop=FALSE],
                        realPostHoc[,"2",drop=FALSE],realPostHoc[,"LogL1",drop=FALSE],
                        realPostHoc[,"LogL2",drop=FALSE],
                        realPostHoc[,"Delta1",drop=FALSE],realPostHoc[,"criticalValues",drop=FALSE],
                        realPostHoc[,"numOKLoci",drop=FALSE], realPostHoc[,"missing locus",drop=FALSE],
                        realPostHoc[,"mother-seedling (no. mismatch)",drop=FALSE],
                        realPostHoc[,"mother-seedling (mismatched loci)",drop=FALSE])
# modify column names
colnames(summaryRealPostHoc)[1] <- "offspring"
colnames(summaryRealPostHoc)[4:5] <- c("pop1","pop2")
colnames(summaryRealPostHoc)[9] <- c("critical")
colnames(summaryRealPostHoc)[10] <- c("OKloci")
colnames(summaryRealPostHoc)[11:13] <- c("missLoci","M_O mismatch","M_O mismatch loci")

# Send to output file
write.csv(realPostHoc,"assignmentLikelihoods.csv",row.names=FALSE)
write.csv(summaryRealPostHoc,"assignmentSummary.csv",row.names=FALSE)
flush.console()
cat("Assignment Summary Statistics..... COMPLETE \n\n")
cat("Assignment likelihoods sent to: 'assignmentLikelihoods.csv' \n")
cat("Assignment summary sent to: 'assignmentSummary.csv' \n\n")

}
