#' performs population assignment on genotype data
#'
#' for genotype data of a set of adults and offspring (progeny), the procedure
#' assigns the most likely source population when maternal parent is known or unknown
#' Other fuctions must be run prior to this function to generate required data (see details)
#' @param inData character, name of data file to import (see Details)
#' @param alleleFrequencies numeric, number of loci in data file
#' @param gameteFrequencies numeric, minimum number of loci (with data) required for importing an individual. Those individuals < minimum are removed from dataset
#' @param numLoci numeric, number of loci in the data set
#' @param ploidy numeric, number of homologous chromosomes. Must be 4 or 6 (i.e. tetraploid or hexaploid).
#' @param motherknown logical, must be either TRUE (i.e. progeny collected from known mothers but father unknown) or FALSE (i.e. progeny from unknown mother or father).
#' @param DRRtable dataframe, generated from function: \code{\link{DRRsetup}},
#' @param DRRtype character, method uses either "general" or "fixed" formulas for genotype probabilities at RME (See details)
#' @param segregationRatios dataframe, generated from function: \code{\link{makeGameteSegTable}},
#' @details
#' \emph{Required data}
#' \itemize{
#'  \item {must be a tab-delimited excel file (*.csv)}
#'  \item {first three headers must include (ID, pop, mother), case sensitive]
#'  See example data file \code{data(Eremophila)}}
#'  \item {following headers must provide information regarding locus identity,
#'  with two columns per locus (e.g. locus1a, locus1b, locus2a, locus2b)}
#'  }
#' \emph{Adults, known parents and progeny (offspring)}
#' \itemize{
#'  \item {Adults in the data set that are not mothers are identified by having no values
#' in the ‘mother’ column. Not all adults have to be mothers}
#'  \item {Progeny from known mothers are identified by having values in the ‘mother’
#'  column. These values refer to the ID of the known mother and must correspond
#'  to an ID present among the adults. Note: a progeny array can all have the
#'  same mother ID}
#'  \item {Progeny from unknown mothers are identified with ‘u’ qualifier in the
#'  ‘mother’ column. Note: function cannot handle a mix of known and unknown
#'  mothers}
#'  \item {Mothers in the data set are only identified by having their
#'  ID present in the ‘mother’ column for one of the seedlings. All remaining
#'  individuals are classified as adults}
#'  \item {Only adults (mothers and non mothers) are used in population
#'  genetic analyses (e.g. allele frequency, expected and observed
#'  heterozygosity, Fst)}
#' }
#' @return procudes a dataframe with same dimensions as excel file
#' @author David L. Field
#' @examples
#' # 7 steps to reaching assignment
#' # access data provided with AutoPoly
#' # Simulated genotypes, ploidy=4, numLoci=24,mother known
#' data(x4_Fst0_13_Sim)
#' write.csv(x4_Fst0_13_Sim,"x4_Fst0_13_Sim.csv",quote=F,row.names=F)
#'
#' # Step 1. Make table for Double Reduction Rates (DRR) at each locus.
#' DRRtable_1 <- DRRsetup(numLoci=24,ploidy=4,propDRR=1)
#'
#' # 2. import and process data
#' x4GenoData <- inputData("x4_Fst0_13_Sim.csv",numLoci=24,lociMin=5,ploidy=4,marker="genotype",cohorts=T,motherknown=T,DRRtable_1)
#'
#' # 3. set the segregation ratios
#' segTable_1 <- makeGameteSegTable(ploidy=4,DRRtable_1)
#'
#' # 4. allele frequencies
#' alleleFreq <- alleleFreqGeno(inData=x4GenoData,numLoci=24,ploidy=4,replacement=TRUE)
#'
#' # 5. Calculate gamete frequencies
#' # Using DRRtable_1 (true DRR for simulations)
#' # Note: Adjust DRRtable_1 and DRRtable_2 to examine the impact of deviations from the true DRR
#' gameteFreq_1 <- gameteFreq(x4GenoData,alleleFreq,numLoci=24,ploidy=4,DRRtable_1,DRRtype)
#' # Using DRRtable_2 (assumed DRR for assignment testing and simulations)
#' gameteFreq_2 <- gameteFreq(x4GenoData,alleleFreq,numLoci=24,ploidy=4,DRRtable_2,DRRtype)
#'
#' # 6. simulate assignment (to obtain credible intervals)
#' x4DataSims <- simAssignmentMums(EremophilaData, alleleFreqTable, gameteFreqTable_1, gameteFreqTable_2, ploidy,
#' marker="genotype", selfing, DRRtable_1, DRRtable_2, segTable_1,
#' segTable_2, DRRtype, simMissLoci, lociMin, epsilon, errorRate, output.txt,
#' numAdultsSim,numMothersSim,numOffspringSim,fixMothersSim,immRateSim=0.5)
#'
#' # 7. Run assignment
#' EremophilaAssignment <- assignmentGeno(EremophilaData,alleleFreqTable,gameteFreqTable_2,
#' numLoci,ploidy,motherknown,DRRtable_2,DRRtype,segTable_2)
#' @export
assignmentGeno <- function(inData,alleleFrequencies,gameteFrequencies,
                           numLoci,ploidy,motherknown,DRRtable,DRRtype,segregationRatios) {

                       strip.NAs <- function(vv) {
                        return(vv[!is.na(vv)])
                        }
        ###########################################
        #   Directing main assignment functions   #
        ###########################################

      if (motherknown==TRUE) {
          assign.popMain <- function (inData,alleleFrequencies,gameteFrequencies,
                                      numLoci,ploidy,motherknown,DRRtable,DRRtype,segregationRatios) {
            # mother known function

            # Initial setup of functions depending on ploidy
            #marker<-"genotype"
            #epsilon3 <-0.0
            cat("\n       Mother = UNKNOWN ")

            #############################################
            # a) Directing required hexaploid functions #
            #############################################

            if (ploidy==6){
              getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
              mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
              getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
              gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
            }
            ################################################
            # b) Directing required tetraploid functions   #
            ################################################

            if (ploidy==4) {
              getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
              mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
              getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
              gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
            }
            #############################
            # Initial setup             #
            # -population information   #
            # -data output structures   #
            #############################
            strip.NAs <- function(vv) {
              return(vv[!is.na(vv)])
            }
            #if (ploidy == 6) {
            #    MAXSEEDLINGGENOTYPES <- 10
            #} else if (ploidy == 4) {
            #    MAXSEEDLINGGENOTYPES <- 3
            #}
            # Obtaining IDs of seedlings
            seedlingID <- with(inData,ID[!is.na(mother=="u")])
            whichAreSeedlings <- with(inData,!is.na(mother))
            seedlings <- inData[whichAreSeedlings,]
            popnsWithSeedlings <- unique(seedlings$pop)
            cat("\n\n",length(popnsWithSeedlings),"population(s) with a total of",
                #length(allMothers),"mother(s) and",
                nrow(seedlings),"progeny...\n")
            flush.console()
            #fatherInPopnProbs <- rep.int(0,numPopns)  ## Needed later
            #names(fatherInPopnProbs) <- allPopns

            ##################################
            #  Setup objects to receive data #
            ##################################

            # possible F1 combinations
            # Required later in assignment test for part c) #
            allPopns <- unique(inData$pop)
            numPopns <- length(allPopns)
            noPopCombinations<-(numPopns*(numPopns-1))/2
            popCombos<-combinations(numPopns,2,allPopns,repeats=FALSE)
            popComboMatrix<-matrix(0,1,noPopCombinations)
            for (thisCombo in 1:nrow(popCombos)) {
              #test thisCombo<-1
              Combo<- popCombos[thisCombo,]
              popComboMatrix[1,thisCombo]<-paste(Combo,collapse=" ")
              #unlist(strsplit(Combo," "))
            }

            ##################################
            #  Setup objects to receive data #
            ##################################

            # a) Seedling scores
            # Main data output for assignment probabilities to each population for a locus
            # seedlingScores <- matrix(0,1,(numPopns+(ncol(popComboMatrix))+1))
            # rownames(seedlingScores)<-(1)
            # colnames(seedlingScores)<-c("seedlingID",allPopns,popComboMatrix[1,])

            # New version
            seedlingScores <- matrix(0,1,(numPopns+(ncol(popComboMatrix))))
            rownames(seedlingScores)<-(1)
            colnames(seedlingScores)<-c(allPopns,popComboMatrix[1,])


            # Error in here with difference number of columns between matrices

            ## b) The L scores will be stored in a list, built up as the loops progress...
            ## Main data storage for assignment probabilities across loci
            ##LScores <- list()
            # colnames(LScoresMatrix)
            # Creating normal R matrix       # NOTE will have to alter this for when motherknown=TRUE
            # LScoresMatrix <- matrix(0,nrow(seedlings),((ncol(seedlingScores)-1)*numLoci))
            # lociInfo <- paste("L",sort(rep(1:numLoci,((ncol(seedlingScores))-1))),sep="_")
            # popCombosandPops <-c(allPopns,popComboMatrix[1,])
            # numComboandPops <- length(popCombosandPops)
            # columnNames <- paste(rep(popCombosandPops,numLoci),lociInfo)
            # colnames(LScoresMatrix) <- columnNames
            # seedlingIDTemp <- matrix(0,length(seedlingID),1)
            # LScoresMatrix <- cbind(seedlingIDTemp,LScoresMatrix)
            # colnames(LScoresMatrix) <- c("seedlingID",columnNames)
            # rownames(LScoresMatrix) <- rownames(seedlings)
            # LScoresMatrix[,1] <- seedlingID

            # New version
            LScoresMatrix <- matrix(0,nrow(seedlings),((ncol(seedlingScores))*numLoci))
            lociInfo <- paste("L.",sort(rep(1:numLoci,((ncol(seedlingScores))))),sep="")
            popCombosandPops <-c(allPopns,popComboMatrix[1,])
            numComboandPops <- length(popCombosandPops)
            columnNames <- paste(rep(popCombosandPops,numLoci),lociInfo)
            colnames(LScoresMatrix) <- columnNames
            #seedlingIDTemp <- matrix(0,length(seedlingID),1)
            #LScoresMatrix <- cbind(seedlingIDTemp,LScoresMatrix)
            colnames(LScoresMatrix) <- columnNames
            rownames(LScoresMatrix) <- seedlingID

            # head(LScoresMatrix)
            ## c) seedlingStatus records status information about each seedling at
            ##    each locus:
            ## - seedling alleles present in population
            ## - Seedling alleles missing in population
            ## - No data at locus
            ## These conditions will be abbreviated to "OK", "S", "NoData" respectively
            seedlingStatus <- matrix("",nrow(seedlings),numLoci,
                                     dimnames=list(seedlingID,1:numLoci))

            ##########################
            ## Begin loop over loci ##
            ##########################
            cat("\n Processing locus")
            for (thisLocus in 1:numLoci) {
              #testing zone thisLocus<-1
              cat(".",thisLocus,"...")
              flush.console()
              #LScores[[thisLocus]] <- list() ## Add a component for the current locus
              ##Define the inData column range containing the alleles for the
              ##current locus:
              locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
              # nominate what columns the current seedlings data goes to in LScoresMatrix
              #colRange <- 1 + ((thisLocus-1)*numComboandPops) + (1:numComboandPops)
              colRange <- ((thisLocus-1)*numComboandPops) + (1:numComboandPops)
              # Pull out functions for particular DRR at this locus
              if (DRRtype == "fixed") {
                DRR <- as.vector(DRRtable[thisLocus,2])

                if (ploidy==6) {
                  if (marker == "genotype") {
                    if (DRR == "min") {
                      getMotherGameteInfo <- getMotherGameteInfoHexGenoMin # segregation ratios: gametes from individual
                    } else if (DRR == "max") {
                      getMotherGameteInfo <- getMotherGameteInfoHexGenoMax # segregation ratios: gametes from individual
                    }
                  }
                  if (marker == "phenotype") {
                    if (DRR == "min") {
                      getMotherGameteInfo <- getMotherGameteInfoHexPhenoMin # segregation ratios: gametes from individual
                    } else if (DRR == "max") {
                      getMotherGameteInfo <- getMotherGameteInfoHexPhenoMax # segregation ratios: gametes from individual
                    }
                  }
                }

                if (ploidy==4) {
                  if (marker == "genotype") {
                    if (DRR == "min") {
                      getMotherGameteInfo <- getMotherGameteInfoTetrGenoMin # segregation ratios: gametes from individual
                    } else if (DRR == "max") {
                      getMotherGameteInfo <- getMotherGameteInfoTetrGenoMax # segregation ratios: gametes from individual
                    }
                  }
                  if (marker == "phenotype") {
                    if (DRR == "min") {
                      getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMin # segregation ratios: gametes from individual
                    } else if (DRR == "max") {
                      getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMax # segregation ratios: gametes from individual
                    }
                  }
                }

              }
              # Pull out functions for particular DRR at this locus - general formulas
              if (DRRtype == "general") {
                DRR <- as.vector(DRRtable[thisLocus,1])
                if (ploidy==6) {
                  #    if (marker == "genotype") {
                  getMotherGameteInfoGeno <- getMotherGameteInfoHexGenoGeneral # segregation ratios: gametes from individual
                  getMotherGameteInfoPheno <- getMotherGameteInfoHexPhenoGeneral # segregation ratios: gametes from individual
                  #    }
                  # if (marker == "phenotype") {
                  #      getMotherGameteInfo <- getMotherGameteInfoHexPhenoGeneral # segregation ratios: gametes from individual
                  #  }
                }
                if (ploidy==4) {
                  #     if (marker == "genotype") {
                  getMotherGameteInfoGeno <- getMotherGameteInfoTetrGenoGeneral # segregation ratios: gametes from individual
                  getMotherGameteInfoPheno <- getMotherGameteInfoTetrPhenoGeneral # segregation ratios: gametes from individual

                  #    }
                  #    if (marker == "phenotype") {
                  #      getMotherGameteInfo <- getMotherGameteInfoTetrPhenoGeneral # segregation ratios: gametes from individual
                  #    }
                }
              }
              #####################################################
              ## Begin loop over populations that have seedlings ##
              #####################################################
              for (thisPopn in popnsWithSeedlings) {
                #test zone thisPopn<-"A"
                #cat("   Processing progeny in population",thisPopn,"\n")
                #flush.console()
                otherPopns <- allPopns[thisPopn!=allPopns]
                thisPopnsSeedlings <- seedlings[seedlings$pop==thisPopn,]
                thisPopnsSeedlingIDs <- seedlings[seedlings$pop==thisPopn,"ID"]

                #####################################################################
                # Begin loop over seedlings in current population (with seedlings) ##
                #####################################################################
                for (thisSeedling in thisPopnsSeedlingIDs) {
                  #test thisSeedling<-"1_s"
                  seedlingGenotype <- strip.NAs(thisPopnsSeedlings[thisPopnsSeedlings$ID==thisSeedling,locusRange])
                  # If no data at this locus, skips the current seedling
                  if (length(seedlingGenotype) < 1) {
                    seedlingStatus[thisSeedling,thisLocus] <- "NoData"
                    next  ## Skip to next seedling
                  } else {
                    seedlingStatus[thisSeedling,thisLocus] <- "OK"
                    # Get all the alternative genotypes for a give phenotype
                    #possibleSeedlingGenos <- getSeedlingGenotypes(seedlingPhenotype)
                    #length(seedlingGenotypes)
                    #seedlingGenotypeCount <- 0

                    ############################################################
                    # Begin loop over seedling genotypes for a given phenotype #
                    ############################################################
                    #for (thisGeno in 1:length(possibleSeedlingGenos)) {
                    # test  thisGeno<-10
                    # test  thisSeedlingGeno<-possibleSeedlingGenos[thisGeno]

                    ###############################################################################
                    # a) calculate frequeny of a given genotype at equilibrium in home population #
                    ###############################################################################
                    seedlingScores[1,thisPopn] <- getProbGenotypeGivenPopn(seedlingGenotype,
                                                                           gameteFrequencies[[thisPopn]][[thisLocus]],
                                                                           alleleFrequencies[[thisPopn]][[thisLocus]],
                                                                           0,epsilon3)
                    ######################################################################################
                    # b) calculate frequeny of a given genotype at equilibrium in all other populations  #
                    ######################################################################################
                    for (thatPopn in otherPopns){
                      #test thatPopn<-"B"
                      seedlingScores[1,thatPopn] <- getProbGenotypeGivenPopn(seedlingGenotype,
                                                                             gameteFrequencies[[thatPopn]][[thisLocus]],
                                                                             alleleFrequencies[[thatPopn]][[thisLocus]],
                                                                             0,epsilon3)
                    }
                    ######################################################################################
                    # c) calculate frequeny of a F1 mixed genotype between all population pairs          #
                    ######################################################################################
                    #seedlingAlleles<-unique(seedlingGenotypes[[thisSeedlingGeno]])
                    #thisCurrentSeedlingGeno<-seedlingGenotypes[[thisSeedlingGeno]]
                    # possible F1 combinations

                    for (thisCombo in 1:noPopCombinations) {
                      # test thisCombo<-1
                      #thisGenotype<- possibleSeedlingGenos[[thisGeno]]
                      thisPopninCombo <- popCombos[thisCombo,1]
                      thatPopninCombo <- popCombos[thisCombo,2]
                      twoPops <- paste(thisPopninCombo,thatPopninCombo, collapse=" ")
                      seedlingScores[1,twoPops] <- mixedGenotypeFreqGivenPopns(seedlingGenotype,thisLocus,thisPopninCombo,
                                                                               thatPopninCombo,gameteFrequencies,DRR,epsilon3)
                    }
                  }
                  #seedlingScores[seedlingGenotypeCount+1,] <- seedlingScores[seedlingGenotypeCount+1,] + motherGameteProb*fatherInPopnProbs  # Main assignment equation (sum over mother gamete and father gamete combinations)
                  #} ## End loop over possible seedling genotypes
                  meanScores <- as.vector(apply(seedlingScores,2,mean))
                  # meanScores <- meanScores[2:length(meanScores)]
                  LScoresMatrix[thisSeedling,colRange] <- meanScores
                  # LScoresMatrix[LScoresMatrix[,"seedlingID"]== thisSeedling,colRange] <- meanScores
                  # LScores[[thisLocus]][[thisSeedling]] <- apply(seedlingScores,2,mean)
                  seedlingScores[,] <- 0  ##Clear this out before the seedling...
                } ## End loop over seedlings
              } ##End loop over populations with seedlings
            } ##End loop over loci
            #LScoresMatrix <- as.data.frame(LScoresMatrix)
            cat("\n ** Assignment testing...... COMPLETE **\n\n")
            #LScoresMatrix <- LScoresMatrix[,2:ncol(LScoresMatrix)]

            return(list(LScoresMatrix=LScoresMatrix,seedlingStatus=seedlingStatus))
          }
          }
      if (motherknown==FALSE) {
          assign.popMain <- function (inData,alleleFrequencies,gameteFrequencies,
                                      numLoci,ploidy,motherknown,DRRtable,DRRtype,segregationRatios) {

            # mother unknown version
            # Initial setup of functions depending on ploidy
            #marker<-"genotype"
            #epsilon3 <-0.0
            cat("\n       Mother = UNKNOWN ")

            #############################################
            # a) Directing required hexaploid functions #
            #############################################

            if (ploidy==6){
              getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
              mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
              getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
              gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
            }
            ################################################
            # b) Directing required tetraploid functions   #
            ################################################

            if (ploidy==4) {
              getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
              mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
              getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
              gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
            }
            #############################
            # Initial setup             #
            # -population information   #
            # -data output structures   #
            #############################
            strip.NAs <- function(vv) {
              return(vv[!is.na(vv)])
            }
            #if (ploidy == 6) {
            #    MAXSEEDLINGGENOTYPES <- 10
            #} else if (ploidy == 4) {
            #    MAXSEEDLINGGENOTYPES <- 3
            #}
            # Obtaining IDs of seedlings
            seedlingID <- with(inData,ID[!is.na(mother=="u")])
            whichAreSeedlings <- with(inData,!is.na(mother))
            seedlings <- inData[whichAreSeedlings,]
            popnsWithSeedlings <- unique(seedlings$pop)
            cat("\n\n",length(popnsWithSeedlings),"population(s) with a total of",
                #length(allMothers),"mother(s) and",
                nrow(seedlings),"progeny...\n")
            flush.console()
            #fatherInPopnProbs <- rep.int(0,numPopns)  ## Needed later
            #names(fatherInPopnProbs) <- allPopns

            ##################################
            #  Setup objects to receive data #
            ##################################

            # possible F1 combinations
            # Required later in assignment test for part c) #
            allPopns <- unique(inData$pop)
            numPopns <- length(allPopns)
            noPopCombinations<-(numPopns*(numPopns-1))/2
            popCombos<-combinations(numPopns,2,allPopns,repeats=FALSE)
            popComboMatrix<-matrix(0,1,noPopCombinations)
            for (thisCombo in 1:nrow(popCombos)) {
              #test thisCombo<-1
              Combo<- popCombos[thisCombo,]
              popComboMatrix[1,thisCombo]<-paste(Combo,collapse=" ")
              #unlist(strsplit(Combo," "))
            }

            ##################################
            #  Setup objects to receive data #
            ##################################

            # a) Seedling scores
            # Main data output for assignment probabilities to each population for a locus
            # seedlingScores <- matrix(0,1,(numPopns+(ncol(popComboMatrix))+1))
            # rownames(seedlingScores)<-(1)
            # colnames(seedlingScores)<-c("seedlingID",allPopns,popComboMatrix[1,])

            # New version
            seedlingScores <- matrix(0,1,(numPopns+(ncol(popComboMatrix))))
            rownames(seedlingScores)<-(1)
            colnames(seedlingScores)<-c(allPopns,popComboMatrix[1,])


            # Error in here with difference number of columns between matrices

            ## b) The L scores will be stored in a list, built up as the loops progress...
            ## Main data storage for assignment probabilities across loci
            ##LScores <- list()
            # colnames(LScoresMatrix)
            # Creating normal R matrix       # NOTE will have to alter this for when motherknown=TRUE
            # LScoresMatrix <- matrix(0,nrow(seedlings),((ncol(seedlingScores)-1)*numLoci))
            # lociInfo <- paste("L",sort(rep(1:numLoci,((ncol(seedlingScores))-1))),sep="_")
            # popCombosandPops <-c(allPopns,popComboMatrix[1,])
            # numComboandPops <- length(popCombosandPops)
            # columnNames <- paste(rep(popCombosandPops,numLoci),lociInfo)
            # colnames(LScoresMatrix) <- columnNames
            # seedlingIDTemp <- matrix(0,length(seedlingID),1)
            # LScoresMatrix <- cbind(seedlingIDTemp,LScoresMatrix)
            # colnames(LScoresMatrix) <- c("seedlingID",columnNames)
            # rownames(LScoresMatrix) <- rownames(seedlings)
            # LScoresMatrix[,1] <- seedlingID

            # New version
            LScoresMatrix <- matrix(0,nrow(seedlings),((ncol(seedlingScores))*numLoci))
            lociInfo <- paste("L.",sort(rep(1:numLoci,((ncol(seedlingScores))))),sep="")
            popCombosandPops <-c(allPopns,popComboMatrix[1,])
            numComboandPops <- length(popCombosandPops)
            columnNames <- paste(rep(popCombosandPops,numLoci),lociInfo)
            colnames(LScoresMatrix) <- columnNames
            #seedlingIDTemp <- matrix(0,length(seedlingID),1)
            #LScoresMatrix <- cbind(seedlingIDTemp,LScoresMatrix)
            colnames(LScoresMatrix) <- columnNames
            rownames(LScoresMatrix) <- seedlingID

            # head(LScoresMatrix)
            ## c) seedlingStatus records status information about each seedling at
            ##    each locus:
            ## - seedling alleles present in population
            ## - Seedling alleles missing in population
            ## - No data at locus
            ## These conditions will be abbreviated to "OK", "S", "NoData" respectively
            seedlingStatus <- matrix("",nrow(seedlings),numLoci,
                                     dimnames=list(seedlingID,1:numLoci))

            ##########################
            ## Begin loop over loci ##
            ##########################
            cat("\n Processing locus")
            for (thisLocus in 1:numLoci) {
              #testing zone thisLocus<-1
              cat(".",thisLocus,"...")
              flush.console()
              #LScores[[thisLocus]] <- list() ## Add a component for the current locus
              ##Define the inData column range containing the alleles for the
              ##current locus:
              locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
              # nominate what columns the current seedlings data goes to in LScoresMatrix
              #colRange <- 1 + ((thisLocus-1)*numComboandPops) + (1:numComboandPops)
              colRange <- ((thisLocus-1)*numComboandPops) + (1:numComboandPops)
              # Pull out functions for particular DRR at this locus
              if (DRRtype == "fixed") {
                DRR <- as.vector(DRRtable[thisLocus,2])

                if (ploidy==6) {
                  if (marker == "genotype") {
                    if (DRR == "min") {
                      getMotherGameteInfo <- getMotherGameteInfoHexGenoMin # segregation ratios: gametes from individual
                    } else if (DRR == "max") {
                      getMotherGameteInfo <- getMotherGameteInfoHexGenoMax # segregation ratios: gametes from individual
                    }
                  }
                  if (marker == "phenotype") {
                    if (DRR == "min") {
                      getMotherGameteInfo <- getMotherGameteInfoHexPhenoMin # segregation ratios: gametes from individual
                    } else if (DRR == "max") {
                      getMotherGameteInfo <- getMotherGameteInfoHexPhenoMax # segregation ratios: gametes from individual
                    }
                  }
                }

                if (ploidy==4) {
                  if (marker == "genotype") {
                    if (DRR == "min") {
                      getMotherGameteInfo <- getMotherGameteInfoTetrGenoMin # segregation ratios: gametes from individual
                    } else if (DRR == "max") {
                      getMotherGameteInfo <- getMotherGameteInfoTetrGenoMax # segregation ratios: gametes from individual
                    }
                  }
                  if (marker == "phenotype") {
                    if (DRR == "min") {
                      getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMin # segregation ratios: gametes from individual
                    } else if (DRR == "max") {
                      getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMax # segregation ratios: gametes from individual
                    }
                  }
                }

              }
              # Pull out functions for particular DRR at this locus - general formulas
              if (DRRtype == "general") {
                DRR <- as.vector(DRRtable[thisLocus,1])
                if (ploidy==6) {
                  #    if (marker == "genotype") {
                  getMotherGameteInfoGeno <- getMotherGameteInfoHexGenoGeneral # segregation ratios: gametes from individual
                  getMotherGameteInfoPheno <- getMotherGameteInfoHexPhenoGeneral # segregation ratios: gametes from individual
                  #    }
                  # if (marker == "phenotype") {
                  #      getMotherGameteInfo <- getMotherGameteInfoHexPhenoGeneral # segregation ratios: gametes from individual
                  #  }
                }
                if (ploidy==4) {
                  #     if (marker == "genotype") {
                  getMotherGameteInfoGeno <- getMotherGameteInfoTetrGenoGeneral # segregation ratios: gametes from individual
                  getMotherGameteInfoPheno <- getMotherGameteInfoTetrPhenoGeneral # segregation ratios: gametes from individual

                  #    }
                  #    if (marker == "phenotype") {
                  #      getMotherGameteInfo <- getMotherGameteInfoTetrPhenoGeneral # segregation ratios: gametes from individual
                  #    }
                }
              }
              #####################################################
              ## Begin loop over populations that have seedlings ##
              #####################################################
              for (thisPopn in popnsWithSeedlings) {
                #test zone thisPopn<-"A"
                #cat("   Processing progeny in population",thisPopn,"\n")
                #flush.console()
                otherPopns <- allPopns[thisPopn!=allPopns]
                thisPopnsSeedlings <- seedlings[seedlings$pop==thisPopn,]
                thisPopnsSeedlingIDs <- seedlings[seedlings$pop==thisPopn,"ID"]

                #####################################################################
                # Begin loop over seedlings in current population (with seedlings) ##
                #####################################################################
                for (thisSeedling in thisPopnsSeedlingIDs) {
                  #test thisSeedling<-"1_s"
                  seedlingGenotype <- strip.NAs(thisPopnsSeedlings[thisPopnsSeedlings$ID==thisSeedling,locusRange])
                  # If no data at this locus, skips the current seedling
                  if (length(seedlingGenotype) < 1) {
                    seedlingStatus[thisSeedling,thisLocus] <- "NoData"
                    next  ## Skip to next seedling
                  } else {
                    seedlingStatus[thisSeedling,thisLocus] <- "OK"
                    # Get all the alternative genotypes for a give phenotype
                    #possibleSeedlingGenos <- getSeedlingGenotypes(seedlingPhenotype)
                    #length(seedlingGenotypes)
                    #seedlingGenotypeCount <- 0

                    ############################################################
                    # Begin loop over seedling genotypes for a given phenotype #
                    ############################################################
                    #for (thisGeno in 1:length(possibleSeedlingGenos)) {
                    # test  thisGeno<-10
                    # test  thisSeedlingGeno<-possibleSeedlingGenos[thisGeno]

                    ###############################################################################
                    # a) calculate frequeny of a given genotype at equilibrium in home population #
                    ###############################################################################
                    seedlingScores[1,thisPopn] <- getProbGenotypeGivenPopn(seedlingGenotype,
                                                                           gameteFrequencies[[thisPopn]][[thisLocus]],
                                                                           alleleFrequencies[[thisPopn]][[thisLocus]],
                                                                           0,epsilon3)
                    ######################################################################################
                    # b) calculate frequeny of a given genotype at equilibrium in all other populations  #
                    ######################################################################################
                    for (thatPopn in otherPopns){
                      #test thatPopn<-"B"
                      seedlingScores[1,thatPopn] <- getProbGenotypeGivenPopn(seedlingGenotype,
                                                                             gameteFrequencies[[thatPopn]][[thisLocus]],
                                                                             alleleFrequencies[[thatPopn]][[thisLocus]],
                                                                             0,epsilon3)
                    }
                    ######################################################################################
                    # c) calculate frequeny of a F1 mixed genotype between all population pairs          #
                    ######################################################################################
                    #seedlingAlleles<-unique(seedlingGenotypes[[thisSeedlingGeno]])
                    #thisCurrentSeedlingGeno<-seedlingGenotypes[[thisSeedlingGeno]]
                    # possible F1 combinations

                    for (thisCombo in 1:noPopCombinations) {
                      # test thisCombo<-1
                      #thisGenotype<- possibleSeedlingGenos[[thisGeno]]
                      thisPopninCombo <- popCombos[thisCombo,1]
                      thatPopninCombo <- popCombos[thisCombo,2]
                      twoPops <- paste(thisPopninCombo,thatPopninCombo, collapse=" ")
                      seedlingScores[1,twoPops] <- mixedGenotypeFreqGivenPopns(seedlingGenotype,thisLocus,thisPopninCombo,
                                                                               thatPopninCombo,gameteFrequencies,DRR,epsilon3)
                    }
                  }
                  #seedlingScores[seedlingGenotypeCount+1,] <- seedlingScores[seedlingGenotypeCount+1,] + motherGameteProb*fatherInPopnProbs  # Main assignment equation (sum over mother gamete and father gamete combinations)
                  #} ## End loop over possible seedling genotypes
                  meanScores <- as.vector(apply(seedlingScores,2,mean))
                  # meanScores <- meanScores[2:length(meanScores)]
                  LScoresMatrix[thisSeedling,colRange] <- meanScores
                  # LScoresMatrix[LScoresMatrix[,"seedlingID"]== thisSeedling,colRange] <- meanScores
                  # LScores[[thisLocus]][[thisSeedling]] <- apply(seedlingScores,2,mean)
                  seedlingScores[,] <- 0  ##Clear this out before the seedling...
                } ## End loop over seedlings
              } ##End loop over populations with seedlings
            } ##End loop over loci
            #LScoresMatrix <- as.data.frame(LScoresMatrix)
            cat("\n ** Assignment testing...... COMPLETE **\n\n")
            #LScoresMatrix <- LScoresMatrix[,2:ncol(LScoresMatrix)]

            return(list(LScoresMatrix=LScoresMatrix,seedlingStatus=seedlingStatus))
          }
          }
      ## Actual assignment function runs here:
          cat("\n ** Beginning Assignment test.... **\n")

return(assign.popMain(inData,alleleFrequencies,gameteFrequencies,
                      numLoci,ploidy,motherknown,DRRtable,DRRtype,segregationRatios))
}
