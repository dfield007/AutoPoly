#' converts a genotype/phenotype data set from AutoPoly to Structure data format
#'
#' @param inData dataframe, genotype data to be converted
#' @param numLoci numeric, number of loci in data file
#' @param lociMin numeric, minimum number of loci (with data) required for importing an individual. Those individuals < minimum are removed from dataset
#' @return procudes a dataframe with same dimensions as excel file
#' @author David L. Field
#' @export
convertStructure <- function(thisRunData,ploidy,numLoci,marker,motherknown,convertPop,popinfo,popflag) {
              cat("       Converting to Structure format...")
              flush.console()
               pops <- unique(as.vector(thisRunData[,"pop"]))
               numPopsHere <- length(pops)
               numPerPop <- nrow(thisRunData)/numPopsHere
               totalNumInds <- nrow(thisRunData)
               newStructureMatrix <- matrix(0,totalNumInds*ploidy,(4+numLoci))
               # Begin loop over individuals
               for (thisInd in 1:totalNumInds) {
                  # thisInd <- 1
                  if (thisInd == 1) {
                      rowRange <- ((ploidy*thisInd)-(ploidy-1)):(ploidy*thisInd)
                  }
                  if (thisInd != 1) {
                      rowRange <- ((ploidy*thisInd)-(ploidy-1)):(ploidy*thisInd)
                  }
                  # Put in ID
                  newStructureMatrix[rowRange,1] <- rep(as.vector(unlist(thisRunData[thisInd,1])),ploidy)
                  # Put in Pop
                  # If selected to convert alphabetical pop labels to integers (required for STRUCTURE)
                  if (convertPop ==1) {
                      if (thisRunData[thisInd,2] == "A") {
                          newStructureMatrix[rowRange,2] <- rep(1,ploidy)
                          newStructureMatrix[rowRange,4] <- rep(1,ploidy)
                      }
                      if (thisRunData[thisInd,2] == "B") {
                          newStructureMatrix[rowRange,2] <- rep(2,ploidy)
                          newStructureMatrix[rowRange,4] <- rep(2,ploidy)
                      }
                      if (thisRunData[thisInd,2] == "C") {
                          newStructureMatrix[rowRange,2] <- rep(3,ploidy)
                          newStructureMatrix[rowRange,4] <- rep(3,ploidy)
                      }
                      if (thisRunData[thisInd,2] == "D") {
                          newStructureMatrix[rowRange,2] <- rep(4,ploidy)
                          newStructureMatrix[rowRange,4] <- rep(4,ploidy)
                      }
                      if (thisRunData[thisInd,2] == "E") {
                          newStructureMatrix[rowRange,2] <- rep(5,ploidy)
                          newStructureMatrix[rowRange,4] <- rep(5,ploidy)
                      }
                      if (thisRunData[thisInd,2] == "F") {
                          newStructureMatrix[rowRange,2] <- rep(6,ploidy)
                          newStructureMatrix[rowRange,4] <- rep(6,ploidy)
                      }
                      if (thisRunData[thisInd,2] == "G") {
                          newStructureMatrix[rowRange,2] <- rep(7,ploidy)
                          newStructureMatrix[rowRange,4] <- rep(7,ploidy)
                      }
                      if (thisRunData[thisInd,2] == "H") {
                          newStructureMatrix[rowRange,2] <- rep(8,ploidy)
                          newStructureMatrix[rowRange,4] <- rep(8,ploidy)
                      }
                      if (thisRunData[thisInd,2] == "I") {
                          newStructureMatrix[rowRange,2] <- rep(9,ploidy)
                          newStructureMatrix[rowRange,4] <- rep(9,ploidy)
                      }
                      if (thisRunData[thisInd,2] == "J") {
                          newStructureMatrix[rowRange,2] <- rep(10,ploidy)
                          newStructureMatrix[rowRange,4] <- rep(10,ploidy)
                      }
                  }
                  if (convertPop == 0) {
                      newStructureMatrix[rowRange,2] <- rep(as.vector(unlist(thisRunData[thisInd,2])),ploidy)
                  }
                  # PopInfo
             #          # When 1, all individuals have popinfo=1
             #     if (popinfo ==1) {
             #         if (is.na(thisRunData[thisInd,3])) {
             #             newStructureMatrix[rowRange,3] <- rep(1,ploidy)
             #         }
             #         if (!is.na(thisRunData[thisInd,3])) {
             #             newStructureMatrix[rowRange,3] <- rep(1,ploidy)
             #         }
             #     }
             #        # When 0, only the reference individuals have popinfo=1
             #     if (popinfo ==0) {
             #         if (is.na(thisRunData[thisInd,3])) {
             #             newStructureMatrix[rowRange,3] <- rep(1,ploidy)
             #         }
             #         if (!is.na(thisRunData[thisInd,3])) {
             #             newStructureMatrix[rowRange,3] <- rep(0,ploidy)
             #         }
             #     }

                  # PopFlag
                       # When 1, all individuals have popflag=1
                  if (popflag ==1) {
                      if (is.na(thisRunData[thisInd,3])) {
                          newStructureMatrix[rowRange,3] <- rep(1,ploidy)
                      }
                      if (!is.na(thisRunData[thisInd,3])) {
                          newStructureMatrix[rowRange,3] <- rep(1,ploidy)
                      }
                  }
                     # When 0, only the reference individuals have popflag=1
                  if (popflag ==0) {
                      if (is.na(thisRunData[thisInd,3])) {
                          newStructureMatrix[rowRange,3] <- rep(1,ploidy)
                      }
                      if (!is.na(thisRunData[thisInd,3])) {
                          newStructureMatrix[rowRange,3] <- rep(0,ploidy)
                      }
                  }

                  for (thisLocus in 1:numLoci) {
                      # thisLocus <- 1
                      locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
                      if (marker == "phenotype") {
                          thisPheno <- as.vector(unlist(thisRunData[thisInd,locusRange]))
                          thisPheno[is.na(thisPheno)] <- -9
                          newStructureMatrix[rowRange,thisLocus+4] <- thisPheno
                      }
                      if (marker == "genotype") {
                          newStructureMatrix[rowRange,thisLocus+4] <- as.vector(unlist(thisRunData[thisInd,locusRange]))
                      }
                  }
                } # end loop over individuals

                # Make Header
                SructHeaders <- matrix(0,2,(numLoci+4))
                SructHeaders[1,] <- c(paste("Loc",1:numLoci,sep=""),rep("DeleteMe",4))

                if (marker == "phenotype") {
                   SructHeaders[2,1:numLoci]<- rep(-9,numLoci)
                }
                if (marker == "genotype") {
                   SructHeaders <- SructHeaders[1,,drop=FALSE]
                }
                # Combine header and genotype data
                newStructureMatrix <- rbind(SructHeaders,newStructureMatrix)
                return(newStructureMatrix)
  } # end function
