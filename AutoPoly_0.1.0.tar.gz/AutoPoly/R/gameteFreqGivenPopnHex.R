#' returns probability of a specified gamete from a hexaploid population
#'
#' @export
gameteFrequencyPopHex <- function (gamete,alleleFrequenciesTable,DRR,epsilon) {
  if (!all(gamete %in% names(alleleFrequenciesTable))) {
    ## If father gamete alleles are not present at all in the population:
    return(epsilon)
    ## return some other default value-user specified-"epsilon", say
  }
  if (all(gamete %in% names(alleleFrequenciesTable))) {
    if (DRR == "min") {
      DRR <- 0.0
    }
    if (DRR == "max") {
      DRR <- 0.2727
    }
    if (is.numeric(DRR) == TRUE) {
      switch(length(unique(gamete)),
           {##Case "aaa" - alleles identical, so use gamete[1]...
             a <- alleleFrequenciesTable[gamete[1]]
             aaa1<-(((27*((1-DRR)*(3-DRR))) /
                     ((9+DRR)*(9+(2*DRR))))*(a^3))
             aaa2<-((((45*DRR)*(3-DRR)) /
                     ((9+DRR)*(9+(2*DRR))))*(a^2))
             aaa3<-(((20*(DRR^2)) /
                     ((9+DRR)*(9+(2*DRR))))*(a))
             return(aaa1+aaa2+aaa3)
           },
           {##Case "aab".
             ##Note: "a" must be the allele appearing twice...
             tt <- table(gamete)
             a <- alleleFrequenciesTable[names(tt)[tt==2]]
             b <- alleleFrequenciesTable[names(tt)[tt==1]]
             aab1<-(((27*((1-DRR)*(3-DRR)))/((9+DRR)*(9+(2*DRR))))*((a^2)*b))
             aab2<-((((15*DRR)*(3-DRR))/((9+DRR)*(9+(2*DRR))))*(a*b))
             return(3*(aab1+aab2))
           },
           {##Case "abc"
             a <- alleleFrequenciesTable[gamete[1]]
             b <- alleleFrequenciesTable[gamete[2]]
             c <- alleleFrequenciesTable[gamete[3]]
             abc<-(((27*((1-DRR)*(3-DRR))) /
                    ((9+DRR)*(9+(2*DRR))))*((a*b*c)))
             return(6*(abc))
           }
           )
    }
  }
}
