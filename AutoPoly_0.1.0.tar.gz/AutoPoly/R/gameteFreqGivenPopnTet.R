#' returns probability of a specified gamete from a tetraploid
#'
#' @export
gameteFrequencyPopTetr <- function (gamete,alleleFrequenciesTable,DRR,epsilon) {
   if (!all(gamete %in% names(alleleFrequenciesTable))) {
    ## If father gamete alleles are not present at all in the population:
    return(epsilon)
    ## return some other default value-user specified-"epsilon", say
  }
  if (all(gamete %in% names(alleleFrequenciesTable))) {
    if (DRR == "min") {
      DRR <- 0.0
    }
    if (DRR == "max") {
      DRR <- 0.14286
    }
    if (is.numeric(DRR) == TRUE) {
      switch(length(unique(gamete)),
           {##Case "aa" - alleles identical, so use gamete[1]...
             a <- alleleFrequenciesTable[gamete[1]]
             names(a)<-NULL
             aa1<-(a^2)
             aa2<- ((3*DRR)/(2+DRR))*(a*(1-a))
             return(aa1+aa2)
           },
           {##Case "ab".
             a <- alleleFrequenciesTable[gamete[1]]
             b <- alleleFrequenciesTable[gamete[2]]
             names(a)<-NULL
             names(b)<-NULL
             ab1<-(a*b)
             ab2<-((4-(4*DRR))/(2+DRR))
             return(ab1*ab2)
           },
           )
    }
  }
}
