#' routine for generating simulated genotypes (mother unknown)
#'
#' Called from : \code{\link{simAssignment}}
#' @return procudes a dataframe of simulated multilocus genotypes
#' @author David L. Field
#' @export
simulateGenosMotherUnknown <- function(inData, alleleFrequencies,
                                      gameteFrequencies,ploidy, marker, numLoci, simMissLoci, selfing,
                                      errorRate1,numMothersSim,numOffspringSim,immRateSim) {
  # alleleFrequencies <- alleleFreq
  # gameteFrequencies <- gameteFreq_1
  # inData <- simData
  # selfing=0; errorRate1=0.01; numMothersSim=10; numOffspringSim=1000; immRateSim=0.5
  # colnames(inData)
  cat("\n         Simulating Genotypes....")
  flush.console()
  # Directing required hexaploid functions
  if (ploidy==6) {
    getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
  }
  # Directing required tetraploid functions
  if (ploidy==4) {
    getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
  }

  # Initial setup
  # -population information
  # -data output structures
  strip.NAs <- function(vv) {
    return(vv[!is.na(vv)])
  }
  if (ploidy == 6) {
    MAXSEEDLINGGENOTYPES <- 10
  } else if (ploidy == 4) {
    MAXSEEDLINGGENOTYPES <- 3
  }
  #  Setup objects to receive data #
  # possible F1 combinations
  # Required later in assignment test for part c) #
  allPopns <- unique(inData$pop)
  numPopns <- length(allPopns)
  PopsPaired <- matrix(0,numPopns,2)
  for (thisPair in 1:length(allPopns)) {
    # test thisPair<- 1
    Paired<- unlist(strsplit(rep(allPopns[thisPair],2)," "))
    PopsPaired[thisPair,1]<-Paired[1]
    PopsPaired[thisPair,2]<-Paired[2]
  }

  noPopCombinations<-(numPopns*(numPopns-1))/2
  popCombos<-combinations(numPopns,2,allPopns,repeats=FALSE)
  popComboMatrix<-matrix(0,1,noPopCombinations)
  for (thisCombo in 1:nrow(popCombos)) {
    #test thisCombo<-1
    Combo<- popCombos[thisCombo,]
    popComboMatrix[1,thisCombo]<-paste(Combo,collapse=" ")
    #unlist(strsplit(Combo," "))
  }
  allPopnsAllCombos<-c(allPopns,popComboMatrix[1,])
  allPopnsAllCombosMatrix<-rbind(PopsPaired, popCombos)

  ##Strip out the seedlings, leaving adults and mothers:
  inDataAdults <- subset(inData,subset=is.na(mother))
  numAdults <- nrow(inDataAdults)
  ## Add additional column to inDataAdults
  newOne <- matrix(0,nrow(inDataAdults),1)
  colnames(newOne) <- "ActualCross"
  inDataAdults <- cbind(inDataAdults,newOne)

  # number of simulations per popcombo
  numSimsPerPop <- as.integer(numOffspringSim/numPopns)
  ## Matrix for simulated progeny
  simCrosses <- matrix(0,numOffspringSim,ncol(inDataAdults))
  colnames(simCrosses) <- colnames(inDataAdults)

  ## Number of simulations
  numSimsPerPop <- as.integer(numOffspringSim/length(allPopns))
  numSimsPerPopOutcrossed <- as.integer(numSimsPerPop*(1-selfing))
  numSimsPerPopSelfed <- numSimsPerPop - numSimsPerPopOutcrossed

  # Sets the start of ID labels for simulated progeny from current mother
  SimProgeny <- 0
  flag <- 0

  #####################################################
  ## Begin loop over populations and combinations    ##
  #####################################################
  for (thisPopn in allPopns) {
    # thisPopn <- "GA"

    #################################
    # Sampling of selfed genotypes  #
    #################################
    # simulated progeny ID labels for selfed individuals
    if (numSimsPerPopSelfed > 0 ) {
      SimProgeny <- flag + (1:(numSimsPerPopSelfed))

      ##########################
      ## Begin loop over loci ##
      ##########################
      for (thisLocus in 1:numLoci) {
        #testing zone thisLocus<-1
        # Current locus column range
        locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
        # First gamete from home population
        # Weighted sampling of gametes from thisPopninCombo
        thisPopn.Gametes <- as.vector(colnames(gameteFrequencies[[thisPopn]][[thisLocus]]))
        thisPopn.Probs <- as.vector(gameteFrequencies[[thisPopn]][[thisLocus]])
        thisPopn.sample <- sample(thisPopn.Gametes,numSimsPerPopSelfed,replace=TRUE,thisPopn.Probs)
        thisPopn.sample <- t(matrix(unlist(strsplit(thisPopn.sample," ")),ploidy/2,))
        # Cobine sampled gametes
        # note 2 copies of same gamete for a simple version of selfing
        newProgeny<- cbind(thisPopn.sample,thisPopn.sample)
        # send to dataframe
        simCrosses[SimProgeny,locusRange]<- newProgeny
        simCrosses[SimProgeny,"pop"]<- thisPopn
        simCrosses[SimProgeny,"mother"]<- "u"
        simCrosses[SimProgeny,"ID"]<- paste(SimProgeny,"s",sep="")
        simCrosses[SimProgeny,"ActualCross"]<-thisPopn
      }
      # write.csv(simCrosses,"simCrosses.csv",row.names=FALSE)
    }
    #####################################
    # Sampling of outcrossed genotypes  #
    #####################################
    # Increase flag for outcrossed progeny
    flag <- max(SimProgeny)
    # simulated progeny ID labels for outcrossed progeny
    SimProgeny <- flag + (1:(numSimsPerPopOutcrossed))
    # random locations of father gametes   #
    randomPopns <- sample(allPopns,numSimsPerPopOutcrossed,replace=TRUE)
    thisPopninTotal.sample <- NULL
    # altering some to reflect the immigration rate selected for simulation
    randomNums <- runif(numSimsPerPopOutcrossed,0,1)
    change <- randomNums <= immRateSim
    theseToChange <- which(change)
    for (thisPop in theseToChange) {
      randomPopns[theseToChange] <- as.vector(thisPopn)
    }
    ## Begin loop over loci ##
    for (thisLocus in 1:numLoci) {
      # thisLocus<-1
      locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy

      ##########################################################
      # sampling first lot of outcrossed gametes from homepop ##
      ##########################################################
      thisHomePopn.Gametes <- as.vector(colnames(gameteFrequencies[[thisPopn]][[thisLocus]]))
      thisHomePopn.Probs <- as.vector(gameteFrequencies[[thisPopn]][[thisLocus]])
      thisHomePopn.sample <- sample(thisHomePopn.Gametes,numSimsPerPopOutcrossed,replace=TRUE,thisHomePopn.Probs)
      thisHomePopn.sample <- t(matrix(unlist(strsplit(thisHomePopn.sample," ")),ploidy/2,))

      #######################################
      ## Begin loop over father locations  ##
      #######################################
      # Matrix to store the other population gametes
      thisPopninTotal.sample <- matrix(0,numSimsPerPopOutcrossed,ploidy/2)

      for (thisOne in 1:numSimsPerPopOutcrossed) {
        # thisRandomPop<-"GF"
        thisRandomPop <- randomPopns[thisOne]
        ####################################################
        # Weighted sampling of gametes from thisPopinTotal #
        ####################################################
        thisPopninTotal.Gametes <- as.vector(colnames(gameteFrequencies[[thisRandomPop]][[thisLocus]]))
        thisPopninTotal.Probs <- as.vector(gameteFrequencies[[thisRandomPop]][[thisLocus]])
        sampledGam <- unlist(strsplit(sample(thisPopninTotal.Gametes,1,replace=TRUE,thisPopninTotal.Probs)," "))
        thisPopninTotal.sample[thisOne,] <- sampledGam
      }
      # Cobine sampled gametes
      newProgeny <- cbind(thisHomePopn.sample,thisPopninTotal.sample)
      # send to dataframe
      simCrosses[SimProgeny,locusRange]<- newProgeny
      simCrosses[SimProgeny,"pop"]<- thisPopn
      simCrosses[SimProgeny,"mother"]<- "u"
      simCrosses[SimProgeny,"ID"]<- paste(SimProgeny,"s",sep="")
      simCrosses[SimProgeny,"ActualCross"]<-paste(thisPopn,randomPopns,sep=" ")
      # clear out
      newProgeny <- NULL
      thisMother.sample <- NULL
      thisPopninTotal.sample <- NULL
    } # end locus loop
    # clear out randomly selected populations
    randomPopns <- NULL
    # Increase flag ready for selfed seedlings from next population
    flag <- max(SimProgeny)
  } # end population loop
  # convert end product to data frame
  these <- simCrosses[,1]!=0
  simCrosses <- simCrosses[these,]
  simCrosses <- as.matrix(simCrosses)
  # Introducing errors
  # 1. Altering alleles according to errorRate
  for (thisLocus in 1:numLoci) {
    # thisLocus <- 1
    locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
    randomNums <- runif(nrow(simCrosses),0,1)
    change <- randomNums <= errorRate1
    theseToChange <- which(change)
    for (thisInd in theseToChange) {
      # thisInd <- 60
      thisPop <- simCrosses[thisInd,"pop"]
      alleles <- simCrosses[thisInd,locusRange]
      possAlleles <- names(alleleFrequencies[[thisPop]][[thisLocus]])
      probAlleles_prob <- alleleFrequencies[[thisPop]][[thisLocus]]
      alleleChange <- sample(possAlleles,1,prob=probAlleles_prob)
      positionChange <- sample(1:length(alleles),1)
      alleles[positionChange] <- alleleChange
      simCrosses[thisInd,locusRange] <- alleles
      # simCrosses[thisInd,locusRange] <- as.character(t(t(alleles)[,1]))
    }
  }
  # 2. removing loci according to simMissLoci and replace with NA
  for (thisLocus in 1:numLoci) {
    locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
    randomNums <- runif(nrow(simCrosses),0,1)
    change <- randomNums <= simMissLoci
    simCrosses[change,locusRange] <- rep(NA,ploidy)
  }
  simCrosses <- as.data.frame(simCrosses)
  rownames(simCrosses) <- simCrosses$ID
  # combine simulated individuals with real adults
  inDataSimData <- rbind(inDataAdults, simCrosses)
  inDataSimData[1:numAdults,"ActualCross"] <- NA
  cat("COMPLETE \n")
  return(inDataSimData)
}
