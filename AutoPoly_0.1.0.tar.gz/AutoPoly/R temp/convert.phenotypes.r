##########################################
# Function to convert genotype dataframe #
#         to phenotype                   #
##########################################

convert.phenotypes<- function(simData, numLoci, ploidy) {

   strip.NAs <- function(vv) {  ##used on line 119
    return(vv[!is.na(vv)])
   }
   cat("         Converting Genotypes to Phenotypes.... \n")
   flush.console()
  # First need a matrix of allele counts
  alleleCounts <- matrix(0, nrow=dim(simData)[1],ncol=numLoci,
                         dimnames=list(simData$ID,paste("Locus",1:numLoci)))
  uniqueAlleleCounts<- matrix(0, nrow=dim(simData)[1],ncol=numLoci,
                         dimnames=list(simData$ID,paste("Locus",1:numLoci)))

  ##########################
  ## Begin loop over loci ##
  ##########################
  cat("\n Processing locus..")
  for (thisLocus in 1:numLoci) {
    cat("",thisLocus,"..")
    flush.console()
    #testing zone thisLocus<-1
    #LScores[[thisLocus]] <- list() ## Add a component for the current locus
    ##Define the inData column range containing the alleles for the
    ##current locus:
    locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy

    # sorts alleles
    simData[,locusRange] <- t(apply(simData[,locusRange],1,sort,
                                     na.last = TRUE))
    ## Store the numbers of alleles detected at each locus
    alleleCounts[,thisLocus] <- apply(simData[,locusRange],1,
                                      function (thisAlleleVector) {
                                        sum(!is.na(thisAlleleVector))
                                      })
    ###############################
    # Begin loop over individuals #
    ###############################
    for (thisIndividual in 1:nrow(simData)) {
        #test thisIndividual<-3
        thisIndividualData<-unlist(simData[thisIndividual,locusRange,drop=TRUE])
        names(thisIndividualData)<-NULL
        if (all(is.na(thisIndividualData))) {
            next  # skip to next individual if all NA values
        }
        # if we have duplicates, these need to be replace with NA
        if (any(duplicated(strip.NAs(thisIndividualData)))) {
            phenotype <-unique(thisIndividualData)
            NAsRequired <- ploidy-(length(phenotype))
            simData[thisIndividual,locusRange] <-c(phenotype,rep(NA,NAsRequired))
        }
    }
  }
   cat("COMPLETE")
  return(simData)
}
