#################################
#       Post Hoc tests          #
#        for assignment tests   #
#         of real data or       #
#          simlulated           #
#                               #
#       Author: David Field     #
#       Date: 1/2/2010          #
#################################
         # inData <- simData
         # results <- simResults
         # head(results[[1]])
postHocTests <- function(inData,motherknown,results,epsilon) {
          cat("\n ** Beginning Posthoc Tests.... **\n")

    allPopns <- unique(inData$pop)
    numPopns <- length(allPopns)
    fullSeedlingSet <- as.vector(with(inData,unique(ID[!is.na(mother)])))

    ####################################################
    # Build matrix ready to receive multilocus scores  #
    ####################################################
    if (motherknown==TRUE) {
        combinedScoresFull <- matrix(0,nrow=length(fullSeedlingSet),ncol=numPopns,
                                      dimnames=list(fullSeedlingSet,allPopns))
        allPopnsAllCombos<-NULL
        allPopnsAllCombos<-allPopns
        numComboandPops<- ncol(combinedScoresFull)
    } else if (motherknown==FALSE) {
        # possible F1 combinations
        # Required later in assignment test for part c) #
        allPopns <- unique(inData$pop)
        numPopns <- length(allPopns)
        noPopCombinations <- (numPopns*(numPopns-1))/2
        popCombos <- combinations(numPopns,2,allPopns,repeats=FALSE)
        popComboMatrix <- matrix(0,1,noPopCombinations)
        for (thisCombo in 1:nrow(popCombos)) {
            #test thisCombo<-1
            Combo<- popCombos[thisCombo,]
            popComboMatrix[1,thisCombo]<-paste(Combo,collapse=" ")
            #unlist(strsplit(Combo," "))
        }
        allPopnsAllCombos <- c(allPopns,popComboMatrix[1,])
        numComboandPops <- length(allPopnsAllCombos)
        combinedScoresFull <- matrix(0,nrow=length(fullSeedlingSet),ncol=length(allPopnsAllCombos),
                             dimnames=list(fullSeedlingSet,allPopnsAllCombos))

    }

    ##################################################
    # Calculate replacement value for missing values #
    ##################################################
    # results<-simResults
    replaceValueLoci <- matrix(0,numLoci,)
    for (thisLocus in 1:numLoci) {
        # test thisLocus<-1
        # nominate columns for this locus in new matrix approach
        colRange <- ((thisLocus-1)*numComboandPops) + (1:numComboandPops)
        allValues <- as.vector(unlist(results$LScoresMatrix[,colRange]))
        minValueThisLocus <- min(allValues,na.rm = TRUE)
        minValueThisLocus <- min(allValues[allValues!=0],na.rm = TRUE)
        replaceValueLoci[thisLocus,] <- as.numeric(minValueThisLocus)/(epsilon*100)
    }

    #################################
    # Calculating multilocus scores #
    #################################
         # thisLocus<-7
         # thisSeedling<-"988s"
        #   results$LScores[[thisLocus]][[thisSeedling]]

    cat("       Processing multi-locus scores...")
    flush.console()
    #  rownames(results$LScoresMatrix) <- as.vector(results$LScoresMatrix[,1])
    combinedScoresFull <- as.matrix(combinedScoresFull)

    for (thisSeedlingNum in 1:length(fullSeedlingSet)) {  # loop over each seedling
        # thisSeedlingNum <-1
        # thisSeedling <-1
        # Matrix
        thisSeedling <- fullSeedlingSet[thisSeedlingNum]
        thisSeedlingData<- matrix(0,nrow=numLoci,ncol=length(allPopnsAllCombos),
                             dimnames=list(1:numLoci,allPopnsAllCombos))
        if (motherknown==FALSE) {
          if (thisSeedlingNum==as.integer(length(fullSeedlingSet)*0.1)) {
              cat("10%..") }
          if (thisSeedlingNum==as.integer(length(fullSeedlingSet)*0.2)) {
              cat("20%..") }
          if (thisSeedlingNum==as.integer(length(fullSeedlingSet)*0.3)) {
              cat("30%..") }
          if (thisSeedlingNum==as.integer(length(fullSeedlingSet)*0.4)) {
              cat("40%..") }
          if (thisSeedlingNum==as.integer(length(fullSeedlingSet)*0.5)) {
              cat("50%..") }
          if (thisSeedlingNum==as.integer(length(fullSeedlingSet)*0.6)) {
              cat("60%..") }
          if (thisSeedlingNum==as.integer(length(fullSeedlingSet)*0.7)) {
              cat("70%..") }
          if (thisSeedlingNum==as.integer(length(fullSeedlingSet)*0.8)) {
              cat("80%..") }
          if (thisSeedlingNum==as.integer(length(fullSeedlingSet)*0.9)) {
              cat("90%..") }
          if (thisSeedlingNum==as.integer(length(fullSeedlingSet)*1.0)) {
              cat("Complete") }
          flush.console()
         }

        for (thisLocus in 1:numLoci) {
            # test   thisLocus <- 1
            colRange <- ((thisLocus-1)*numComboandPops) + (1:numComboandPops)
            # below replaces any nulls (data missing in LScores) with the epsilon replacement
            if (is.null(results$LScoresMatrix[thisSeedling,colRange])) {
                thisSeedlingData[thisLocus,] <- replaceValueLoci[thisLocus,]
                # If data is found, below send the information to the multilocus matrix for the individual
            } else if (!is.null(results$LScoresMatrix[thisSeedling,colRange])) {
                    thisSeedlingData[thisLocus,] <- as.numeric(as.vector(unlist((results$LScoresMatrix[thisSeedling,colRange]))))
            }
            ### Any remainder 0 values are replaced with a proportion (epsilon) of the smallest value at the locus
            tt <- sapply(thisSeedlingData[thisLocus,],
                  function (ll,replaceValueLoci,thisLocus) {
                      value <- replaceValueLoci[thisLocus,]
                      if (ll==0) {
                          return(value)
                      } else if (ll>0) {
                      return(ll)
                      }
                  }
                  , replaceValueLoci,thisLocus)
            thisSeedlingData[thisLocus,] <-tt
        } # end Locus loop
        # calculates the product across loci
        combinedScoresFull[thisSeedling,] <- as.vector(apply(thisSeedlingData,2,prod))
    } # end seedlings loop
    ######################################
    # Natural log of multilocus scores   #
    ######################################
    combinedScoresFull <- log(as.data.frame(combinedScoresFull))

    #########################
    ## Ranking populations  #
    #########################
    cat("\n       Ranking Populations \n")
    flush.console()
    combinedScoresFull <- cbind(seedling=rownames(combinedScoresFull),
                            homePopn=inData$pop[match(fullSeedlingSet,inData$ID)],
                            mother=inData$mother[match(fullSeedlingSet,inData$ID)],
                            combinedScoresFull)
    cSRanks <- t(apply(combinedScoresFull[,-(1:3)],1,
                function(vv) {length(allPopnsAllCombos) + 1 - rank(vv,ties.method="max")}))

    numSeedlings<-max(row(combinedScoresFull))
    rankMatrix<-matrix(0,nrow=numSeedlings,ncol=length(allPopnsAllCombos))
    rownames(rankMatrix)<-rownames(cSRanks)

    for(seedling in fullSeedlingSet) {
        vec <- cSRanks[seedling,,drop=FALSE]
        names(vec) <- allPopnsAllCombos
        vec <- rank(vec)
        vec <- sort(vec)
        rankMatrix[seedling,] <- names(vec)
        }
    combinedScoresFull <- cbind(combinedScoresFull,rankMatrix)
    ## below is code to combine above ranked pops with main output
    ## then determines delta1 (1st - 2nd) & delta2 (2nd - 3rd)

    cat("       Processing Delta    \n\n")
    flush.console()
    popLnOrder<-names(combinedScoresFull[4:(3+length(allPopnsAllCombos))])
    LODmatrix<-matrix(0,nrow=numSeedlings,ncol=2)
    rownames(LODmatrix)<-fullSeedlingSet
    colnames(LODmatrix)<-c("Delta1","Delta2")

    matchingTime<-function(seedlingData,popLnOrder,assignOrder) {
            y<-c(3)+(match(assignOrder,popLnOrder))
            return(seedlingData[,y])
                    }

    for(seedling in fullSeedlingSet) {
         #test  seedling<-"1s"
         seedlingData<-combinedScoresFull[seedling,]
         assignOrder<-as.vector(unlist(seedlingData[(4+length(allPopnsAllCombos)):(3+length(allPopnsAllCombos)*2)]))
         thisLnOrder<-matchingTime(seedlingData,popLnOrder,assignOrder)
         LODmatrix[seedling,1]<-as.numeric(thisLnOrder[1]-thisLnOrder[2])
         # Error occuring in here!!!!!!!!!!!!!!!!!!!!!
      #   if (is.null(as.vector(thisLnOrder[3])) {
      #        next }
      #   if (!is.null(as.numeric(thisLnOrder[2]-thisLnOrder[3]))) {
      #      LODmatrix[seedling,2]<-as.numeric(thisLnOrder[2]-thisLnOrder[3])
      #   }
    }
    combinedScoresFull <- cbind(combinedScoresFull,LODmatrix)
    ##Code for adding number of good loci
    combinedScoresFull$numOKLoci <- 0
    for (seedling in rownames(combinedScoresFull)) {
      combinedScoresFull[seedling,"numOKLoci"]<- sum(results$seedlingStatus[seedling,]=="OK")
    }
    return(combinedScoresFull)
}
