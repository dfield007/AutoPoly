addError <- function(dataSet,errorRate) {
  alleleFreqTableNew <- alleleFreqGeno(dataSet[,1:((numLoci*ploidy)+3)],numLoci,ploidy)
  cat("\n Adding Error..")
  # Begin
  for (thisLocus in 1:numLoci) {
  # dataSet <- MasterDataFileErrors
  # thisLocus <- 1
  locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
  randomNums <- runif(nrow(Reference_NewProgeny_inData),0,1)
  change <- randomNums <= errorRate
  theseToChange <- which(change)
  for (thisInd in theseToChange) {
    # thisInd <- 23
    thisPop <- dataSet[thisInd,"pop"]
    alleles <- dataSet[thisInd,locusRange]
    alleles <- as.numeric(alleles)
    possAlleles <- as.numeric(rownames(alleleFreqTableNew[[thisPop]][[thisLocus]]))
    alleleChange <- sample(possAlleles[is.na(match(possAlleles,alleles))],1)
    positionChange <- sample(1:length(alleles),1)
    alleles[positionChange] <- alleleChange
    dataSet[thisInd,locusRange] <- alleles
  }
}
return(dataSet)
}