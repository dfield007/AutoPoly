##################################
#                                #
#  Expected Genotype frequencies #
#      -For a given genotype &   #
#          population            #
#      -Hexaploid & Tetraploid   #
#      Author: David Field       #
#         1/2/2010               #
################################## 

#    gameteFrequenciesTable<-gameteFrequenciesTable[[thisPopn]][[thisLocus]]
#     alleleFrequenciesTable<- alleleFrequenciesTable[[thisPopn]][[thisLocus]]

#    gameteFrequenciesTable<-gameteFrequenciesTable[[thatPopn]][[thisLocus]]
#     alleleFrequenciesTable<- alleleFrequenciesTable[[thatPopn]][[thisLocus]]

#    thisGenotype<-possibleSeedlingGenos[[thisGeno]]
#    getProbGenotypeGivenPopn(seedlingGenotypes[[seedling]]
#                     ,gameteFrequenciesTable[[thatPopn]][[thisLocus]],0,epsilon)  

genotypeFreqPopHex <- function (thisGenotype,gameteFrequenciesTable,alleleFrequenciesTable,DRR,epsilon)  {
  ##########################################################
  # Hexaploid - frequency of given genotype at equilibrium #
  ##########################################################
    # First screening if alleles missing in population
  thisGenotypesAlleles<-unique(thisGenotype)
  popAlleles<-names(alleleFrequenciesTable)
  if (!all(thisGenotypesAlleles %in% popAlleles)) {
  ## If father gamete alleles are not present at all in the population: 
  return(epsilon)
  }   
  ##Returns the probability of a specified genotype, given a
  ##vector of gamete probabilities (popnGameteProbTable).
  ##NOTE: w112, w122, w133...(are actually =3w112, 3w122, 3w133), so must divide by 3. 
  ##NOTE: y123, y124, y125...(are actually =6y123, 6y124, 6y125),so must divide by 6.
    switch(length(unique(thisGenotype)),
           {##Case "aaaaaa" - alleles identical, so use gamete[1]...
             tt <- sort(table(thisGenotype),decreasing=TRUE) 
             gamp111<-paste(rep(names(tt[1]),3),collapse=" ")     
             p111<-gameteFrequenciesTable[[1,gamp111]]
             return (p111^2)

           }, # End switch
           {##Case Biallele "aaaaab, aaaabb, aaabbb".
              #count table of each allele, sorted so most frequent comes first 
             tt <- sort(table(thisGenotype),decreasing=TRUE) 
             if (max(tt)==5) { #Biallele type I, if max no. of allele is 5 must be type I
                   # gamete p111, made from repeating the name of the allele which occured 4 times
                   # alleles pasted and collapsed with a space left in between e.g. "114 114 114"
                   gamp111<-paste(rep(names(tt)[tt==5],3),collapse=" ")
                   gamw112<-paste(sort(c(rep(names(tt)[tt==5],2),names(tt)[tt==1])),collapse=" ")
                   # extract the probability of a gamete from table and send to object
                   p111<-gameteFrequenciesTable[[1,gamp111]]
                   w112<-(gameteFrequenciesTable[[1,gamw112]])/3
                   #expected frequency of genotype at equilibrium
                   return ((6*(p111*w112)))
                                 
             } else if (max(tt)==4) { #Biallele type II, if max no. of allele is 4 must be type II
                   gamp111<-paste(rep(names(tt)[tt==4],3),collapse=" ")     # 
                   gamw112<-paste(sort(c(rep(names(tt)[tt==4],2),names(tt)[tt==2])),collapse=" ")
                   gamw122<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt)[tt==4])),collapse=" ")
                   p111<-gameteFrequenciesTable[[1,gamp111]]
                   w112<-(gameteFrequenciesTable[[1,gamw112]])/3
                   w122<-(gameteFrequenciesTable[[1,gamw122]])/3
                   return ((6*(p111*w122))+((9*((w112)^2))))

             } else if (max(tt)==3) { #Biallele type III, if max no. of allele is 3 must be type III
                   gamp111<-paste(rep(names(tt[1]),3),collapse=" ")
                   gamq222<-paste(rep(names(tt[2]),3),collapse=" ")
                   gamw112<-paste(sort(c(rep(names(tt[1]),2),names(tt[2]))),collapse=" ")
                   gamw122<-paste(sort(c(rep(names(tt[2]),2),names(tt[1]))),collapse=" ")
                   p111<-gameteFrequenciesTable[[1,gamp111]]
                   q222<-gameteFrequenciesTable[[1,gamq222]]
                   w112<-(gameteFrequenciesTable[[1,gamw112]])/3
                   w122<-(gameteFrequenciesTable[[1,gamw122]])/3
                   return ((2*(p111*q222))+(18*(w112*w122)))
             }
           }, # End switch
           {##Case Triallele: "aaaabc, aaabbc, aabbcc"
              tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
              if (max(tt)==4) { #Triallele type I if max no. of allele is 4 must be type I
                   gamp111<-paste(rep(names(tt)[tt==4],3),collapse=" ") # gamete p111 
                   gamw112<-paste(sort(c(rep(names(tt)[tt==4],2),names(tt[2]))),collapse=" ")
                   gamw113<-paste(sort(c(rep(names(tt)[tt==4],2),names(tt[3]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   p111<-gameteFrequenciesTable[[1,gamp111]]
                   w112<-(gameteFrequenciesTable[[1,gamw112]])/3
                   w113<-(gameteFrequenciesTable[[1,gamw113]])/3
                   y123<-(gameteFrequenciesTable[[1,gamy123]])/6
                   return ((12*(p111*y123))+(18*(w112*w113)))
                                
             } else if (max(tt)==3) { #Triallele type II, if max no. of allele is 3 must be type II
                   gamp111<-paste(rep(names(tt)[tt==3],3),collapse=" ")     # gamete p111
                   gamw112<-paste(sort(c(rep(names(tt)[tt==3],2),names(tt)[tt==2])),collapse=" ")
                   gamw113<-paste(sort(c(rep(names(tt)[tt==3],2),names(tt[3]))),collapse=" ")
                   gamw122<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt)[tt==3])),collapse=" ")
                   gamw223<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt[3]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   p111<-gameteFrequenciesTable[[1,gamp111]]
                   w112<-(gameteFrequenciesTable[[1,gamw112]])/3
                   w113<-(gameteFrequenciesTable[[1,gamw113]])/3
                   w122<-(gameteFrequenciesTable[[1,gamw122]])/3
                   w223<-(gameteFrequenciesTable[[1,gamw223]])/3
                   y123<-(gameteFrequenciesTable[[1,gamy123]])/6
                   return ((6*(p111*w223))+(36*w112*y123)+(18*w113*w122))

             } else if (max(tt)==2) { #Triallele type III, if max no. of allele is 2 must be type III
                   gamw112<-paste(sort(c(names(tt[1]),names(tt[1]),names(tt[2]))),collapse=" ")
                   gamw113<-paste(sort(c(names(tt[1]),names(tt[1]),names(tt[3]))),collapse=" ")
                   gamw122<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[2]))),collapse=" ")
                   gamw133<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[3]))),collapse=" ")
                   gamw223<-paste(sort(c(names(tt[2]),names(tt[2]),names(tt[3]))),collapse=" ")
                   gamw233<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[3]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   w112<-(gameteFrequenciesTable[[1,gamw112]])/3
                   w113<-(gameteFrequenciesTable[[1,gamw113]])/3
                   w122<-(gameteFrequenciesTable[[1,gamw122]])/3
                   w133<-(gameteFrequenciesTable[[1,gamw133]])/3
                   w223<-(gameteFrequenciesTable[[1,gamw223]])/3
                   w233<-(gameteFrequenciesTable[[1,gamw233]])/3
                   y123<-(gameteFrequenciesTable[[1,gamy123]])/6
                   return ((18*(w112*w233))+(18*(w133*w122))+(18*(w113*w223))+(36*((y123)^2)))
                   
             }
           }, # End switch
           {##Case Quadriallele: "aaabcd, aabbcd"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
             if (max(tt)==3) { #Quadriallele type I if max no. of allele is 3 must be type I
                   gamp111<-paste(rep(names(tt)[tt==3],3),collapse=" ") # gamete p111 
                   gamw112<-paste(sort(c(rep(names(tt)[tt==3],2),names(tt[2]))),collapse=" ")
                   gamw113<-paste(sort(c(rep(names(tt)[tt==3],2),names(tt[3]))),collapse=" ")
                   gamw114<-paste(sort(c(rep(names(tt)[tt==3],2),names(tt[4]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy124<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy134<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy234<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[4]))),collapse=" ")
                   p111<-gameteFrequenciesTable[[1,gamp111]]
                   w112<-(gameteFrequenciesTable[[1,gamw112]])/3
                   w113<-(gameteFrequenciesTable[[1,gamw113]])/3
                   w114<-(gameteFrequenciesTable[[1,gamw114]])/3
                   y123<-(gameteFrequenciesTable[[1,gamy123]])/6
                   y124<-(gameteFrequenciesTable[[1,gamy124]])/6
                   y134<-(gameteFrequenciesTable[[1,gamy134]])/6
                   y234<-(gameteFrequenciesTable[[1,gamy234]])/6
                   return ((12*(p111*y234))+(36*(w112*y134))+(36*(w113*y124))+(36*(w114*y123)))
                                
             } else if (max(tt)==2) { #Quadriallele type II if max no. of allele is 2 must be type II
                   gamw112<-paste(sort(c(rep(names(tt[1]),2),names(tt[2]))),collapse=" ")
                   gamw113<-paste(sort(c(rep(names(tt[1]),2),names(tt[3]))),collapse=" ")
                   gamw114<-paste(sort(c(rep(names(tt[1]),2),names(tt[4]))),collapse=" ")
                   gamw122<-paste(sort(c(rep(names(tt[2]),2),names(tt[1]))),collapse=" ")
                   gamw223<-paste(sort(c(rep(names(tt[2]),2),names(tt[3]))),collapse=" ")
                   gamw224<-paste(sort(c(rep(names(tt[2]),2),names(tt[4]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy124<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy134<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy234<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[4]))),collapse=" ")
                   w112<-(gameteFrequenciesTable[[1,gamw112]])/3
                   w113<-(gameteFrequenciesTable[[1,gamw113]])/3
                   w114<-(gameteFrequenciesTable[[1,gamw114]])/3
                   w122<-(gameteFrequenciesTable[[1,gamw122]])/3
                   w223<-(gameteFrequenciesTable[[1,gamw223]])/3
                   w224<-(gameteFrequenciesTable[[1,gamw224]])/3
                   y123<-(gameteFrequenciesTable[[1,gamy123]])/6
                   y124<-(gameteFrequenciesTable[[1,gamy124]])/6
                   y134<-(gameteFrequenciesTable[[1,gamy134]])/6
                   y234<-(gameteFrequenciesTable[[1,gamy234]])/6
                   return ((36*(w112*y234))+(18*(w113*w224))+(18*(w114*w223))+(72*(y123*y124))+(36*(y134*w122)))
                                       
             }  # End Quadriallele Type II 
           },  # End Quadriallele switch
           {##Case Pentallele: "aabcde"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   gamw112<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt[2]))),collapse=" ")
                   gamw113<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt[3]))),collapse=" ")
                   gamw114<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt[4]))),collapse=" ")
                   gamw115<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt[5]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy124<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy125<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[5]))),collapse=" ")
                   gamy134<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy135<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[5]))),collapse=" ")
                   gamy145<-paste(sort(c(names(tt[1]),names(tt[4]),names(tt[5]))),collapse=" ")
                   gamy234<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy235<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[5]))),collapse=" ")
                   gamy245<-paste(sort(c(names(tt[2]),names(tt[4]),names(tt[5]))),collapse=" ")
                   gamy345<-paste(sort(c(names(tt[3]),names(tt[4]),names(tt[5]))),collapse=" ")
                   w112<-(gameteFrequenciesTable[[1,gamw112]])/3
                   w113<-(gameteFrequenciesTable[[1,gamw113]])/3
                   w114<-(gameteFrequenciesTable[[1,gamw114]])/3
                   w115<-(gameteFrequenciesTable[[1,gamw115]])/3
                   y123<-(gameteFrequenciesTable[[1,gamy123]])/6
                   y124<-(gameteFrequenciesTable[[1,gamy124]])/6
                   y125<-(gameteFrequenciesTable[[1,gamy125]])/6
                   y134<-(gameteFrequenciesTable[[1,gamy134]])/6
                   y135<-(gameteFrequenciesTable[[1,gamy135]])/6
                   y145<-(gameteFrequenciesTable[[1,gamy145]])/6
                   y234<-(gameteFrequenciesTable[[1,gamy234]])/6
                   y235<-(gameteFrequenciesTable[[1,gamy235]])/6
                   y245<-(gameteFrequenciesTable[[1,gamy245]])/6
                   y345<-(gameteFrequenciesTable[[1,gamy345]])/6
                   return ((36*(w112*y345))+(36*(w113*y245))+(36*(w114*y235))+(36*
                          (w115*y234))+(72*(y123*y145))+(72*(y134*y125))+(72*(y124*y135)))
                                
           },  # End Pentallele switch
           {## Case Hexallele: "abcdef" 
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy124<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy125<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[5]))),collapse=" ")
                   gamy126<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[6]))),collapse=" ")
                   gamy134<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy135<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[5]))),collapse=" ")
                   gamy136<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[6]))),collapse=" ")
                   gamy145<-paste(sort(c(names(tt[1]),names(tt[4]),names(tt[5]))),collapse=" ")
                   gamy146<-paste(sort(c(names(tt[1]),names(tt[4]),names(tt[6]))),collapse=" ")
                   gamy156<-paste(sort(c(names(tt[1]),names(tt[5]),names(tt[6]))),collapse=" ")
                   gamy234<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy235<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[5]))),collapse=" ")
                   gamy236<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[6]))),collapse=" ")
                   gamy245<-paste(sort(c(names(tt[2]),names(tt[4]),names(tt[5]))),collapse=" ")
                   gamy246<-paste(sort(c(names(tt[2]),names(tt[4]),names(tt[6]))),collapse=" ")
                   gamy256<-paste(sort(c(names(tt[2]),names(tt[5]),names(tt[6]))),collapse=" ")
                   gamy345<-paste(sort(c(names(tt[3]),names(tt[4]),names(tt[5]))),collapse=" ")
                   gamy346<-paste(sort(c(names(tt[3]),names(tt[4]),names(tt[6]))),collapse=" ")
                   gamy356<-paste(sort(c(names(tt[3]),names(tt[5]),names(tt[6]))),collapse=" ")
                   gamy456<-paste(sort(c(names(tt[4]),names(tt[5]),names(tt[6]))),collapse=" ")
                   y123<-(gameteFrequenciesTable[[1,gamy123]])/6
                   y124<-(gameteFrequenciesTable[[1,gamy124]])/6
                   y125<-(gameteFrequenciesTable[[1,gamy125]])/6
                   y126<-(gameteFrequenciesTable[[1,gamy126]])/6
                   y134<-(gameteFrequenciesTable[[1,gamy134]])/6
                   y135<-(gameteFrequenciesTable[[1,gamy135]])/6
                   y136<-(gameteFrequenciesTable[[1,gamy136]])/6
                   y145<-(gameteFrequenciesTable[[1,gamy145]])/6
                   y146<-(gameteFrequenciesTable[[1,gamy146]])/6
                   y156<-(gameteFrequenciesTable[[1,gamy156]])/6
                   y234<-(gameteFrequenciesTable[[1,gamy234]])/6
                   y235<-(gameteFrequenciesTable[[1,gamy235]])/6
                   y236<-(gameteFrequenciesTable[[1,gamy236]])/6
                   y245<-(gameteFrequenciesTable[[1,gamy245]])/6
                   y246<-(gameteFrequenciesTable[[1,gamy246]])/6
                   y256<-(gameteFrequenciesTable[[1,gamy256]])/6
                   y345<-(gameteFrequenciesTable[[1,gamy345]])/6
                   y346<-(gameteFrequenciesTable[[1,gamy346]])/6
                   y356<-(gameteFrequenciesTable[[1,gamy356]])/6
                   y456<-(gameteFrequenciesTable[[1,gamy456]])/6
                   return ((72*(y123*y456))+(72*(y124*y356))+(72*(y125*y346))+(72*
                          (y126*y345))+(72*(y134*y256))+(72*(y135*y246))+(72*
                          (y136*y245))+(72*(y145*y236))+(72*(y146*y235))+(72*(y234*y156)))
                  
             } # End Hexallele switch
           ) # End switch function 
} # End getProbGenotypeGivenPopnHex function 

# test zone 
#          gameteFrequenciesTable<-gameteFrequenciesTable[[thisPopn]][[thisLocus]]
#           thisGenotype<-c("246","246","255","259")
#    getProbGenotypeGivenPopn(seedlingGenotypes[[seedling]]
#                     ,gameteFrequenciesTable[[thatPopn]][[thisLocus]],0,epsilon)  
      
      
                       
genotypeFreqPopTetr <- function (thisGenotype,gameteFrequenciesTable,alleleFrequenciesTable,DRR,epsilon) {
  ###########################################################
  # Tetraploid - frequency of given genotype at equilibrium #
  ###########################################################
  
  # First screening if alleles missing in population
  thisGenotypesAlleles<-unique(thisGenotype)
  popAlleles<-names(alleleFrequenciesTable)
  if (!all(thisGenotypesAlleles %in% popAlleles)) {
  ## If father gamete alleles are not present at all in the population: 
  return(epsilon)
  }   
  ##Returns the probability of a specified genotype, given a
  ##vector of gamete frequencies
  ##NOTE: y12 from gamete frequencies table is actually = 2y12 (so must divide by 2 to get y12)
    switch(length(unique(thisGenotype)),
           {##Case "aaaa" - alleles identical, so use gamete[1]...
             tt <- sort(table(thisGenotype),decreasing=TRUE) 
             gamp11<-paste(rep(names(tt[1]),2),collapse=" ")     
             p11<-gameteFrequenciesTable[[1,gamp11]]
             return (p11^2)
           }, # End switch
           {##Case Biallele "aaab, aabb, abbb".
              #count table of each allele, sorted so most frequent comes first 
             tt <- sort(table(thisGenotype),decreasing=TRUE) 
             if (max(tt)==3) { #Biallele type I, if max no. of allele is 3 must be type I
                   # gamete p11, made from repeating the name of the allele which occured 2 times
                   # alleles pasted and collapsed with a space left in between e.g. "114 114"
                   gamp11<-paste(rep(names(tt)[tt==3],2),collapse=" ")
                   gamy12<-paste(sort(c(rep(names(tt)[tt==3],1),names(tt)[tt==1])),collapse=" ")
                   # extract the probability of a gamete from table and send to object
                   p11<-gameteFrequenciesTable[[1,gamp11]]
                   y12<-(gameteFrequenciesTable[[1,gamy12]])/2
                   #expected frequency of genotype at equilibrium
                   return (4*(p11*y12))
                                 
             } else if (max(tt)==2) { #Biallele type II, if max no. of allele is 2 must be type II
                   gamp11<-paste(rep(names(tt[1]),2),collapse=" ")
                   gamz22<-paste(rep(names(tt[2]),2),collapse=" ")
                   gamy12<-paste(sort(c(names(tt[1]),names(tt[2]))),collapse=" ")
                   p11<-gameteFrequenciesTable[[1,gamp11]]
                   y12<-(gameteFrequenciesTable[[1,gamy12]])/2
                   z22<-(gameteFrequenciesTable[[1,gamz22]])
                   return ((4*((y12)^2)) + (2*(p11*z22)))
             }
           }, # End biallele switch
           {##Case Triallele: "aabc"
              tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   gamp11<-paste(rep(names(tt)[tt==2],2),collapse=" ") # gamete p11 
                   gamy12<-paste(sort(c(rep(names(tt)[tt==2],1),names(tt[2]))),collapse=" ")
                   gamy13<-paste(sort(c(rep(names(tt)[tt==2],1),names(tt[3]))),collapse=" ")
                   gamy23<-paste(sort(c(names(tt[2]),names(tt[3]))),collapse=" ")
                   p11<-gameteFrequenciesTable[[1,gamp11]]
                   y12<-(gameteFrequenciesTable[[1,gamy12]])/2
                   y13<-(gameteFrequenciesTable[[1,gamy13]])/2
                   y23<-(gameteFrequenciesTable[[1,gamy23]])/2
                   return ((4*(p11*y23)) + (8*(y12*y13)))
           }, # End triallele switch
           {##Case Quadriallele: "abcd"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   gamy12<-paste(sort(c(names(tt[1]),names(tt[2]))),collapse=" ")
                   gamy13<-paste(sort(c(names(tt[1]),names(tt[3]))),collapse=" ")
                   gamy14<-paste(sort(c(names(tt[1]),names(tt[4]))),collapse=" ")
                   gamy23<-paste(sort(c(names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy24<-paste(sort(c(names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy34<-paste(sort(c(names(tt[3]),names(tt[4]))),collapse=" ")
                   y12<-(gameteFrequenciesTable[[1,gamy12]])/2
                   y13<-(gameteFrequenciesTable[[1,gamy13]])/2
                   y14<-(gameteFrequenciesTable[[1,gamy14]])/2
                   y23<-(gameteFrequenciesTable[[1,gamy23]])/2
                   y24<-(gameteFrequenciesTable[[1,gamy24]])/2
                   y34<-(gameteFrequenciesTable[[1,gamy34]])/2
                   return ((8*(y12*y34)) + (8*(y13*y24)) + (8*(y14*y23)))
             } # End Quadriallele switch
           ) # End switch function 
} # End function 