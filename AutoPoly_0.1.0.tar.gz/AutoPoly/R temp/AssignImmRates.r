
AssignImmRates <- function(inData,AutoPolyOut) { 
  cat("\n ***** Calculating Immigration Rates ***** \n")
  
  AssignmentSummary <- read.csv("AssignmentSummary(2).csv",header=TRUE,sep=",")
  pops <- unique(EremophilaData$pop)
  AssignmentSummary_Mums <- split(AssignmentSummary,AssignmentSummary$mother)
  Mums <- names(AssignmentSummary_Mums)
  SummaryMums <- matrix(0,length(Mums),15)
  colnames(SummaryMums) <- c("Pop","Mum","Nsample","Home_95","Imm_95","Home_90","Imm_90","Home_80","Imm_80",
                             "Home_95_Perc","Imm_95_Perc","Home_90_Perc","Imm_90_Perc","Home_80_Perc","Imm_80_Perc")
  DetailsMums_95CI <- matrix(0,length(Mums),3+length(pops))
  DetailsMums_90CI <- matrix(0,length(Mums),3+length(pops))
  DetailsMums_80CI <- matrix(0,length(Mums),3+length(pops))
  colnames(DetailsMums_95CI) <- c("Pop","Mum","Nsample",pops)
  colnames(DetailsMums_90CI) <- c("Pop","Mum","Nsample",pops)
  colnames(DetailsMums_80CI) <- c("Pop","Mum","Nsample",pops)
  
  for (ThisMumNum in 1:length(Mums)) {
    # ThisMumNum <- 1
    ThisMum <- Mums[ThisMumNum]
    thisMumData <- AssignmentSummary_Mums[[ThisMum]]
    thisHomePop <- as.vector(unique(thisMumData$homePopn))
    DetailsMums_95CI[ThisMumNum,"Mum"] <- ThisMum
    DetailsMums_90CI[ThisMumNum,"Mum"] <- ThisMum
    DetailsMums_80CI[ThisMumNum,"Mum"] <- ThisMum
    SummaryMums[ThisMumNum,"Mum"] <- ThisMum
    DetailsMums_95CI[ThisMumNum,"Pop"] <- as.vector(unique(thisMumData$homePopn))
    DetailsMums_90CI[ThisMumNum,"Pop"] <- as.vector(unique(thisMumData$homePopn))
    DetailsMums_80CI[ThisMumNum,"Pop"] <- as.vector(unique(thisMumData$homePopn))
    SummaryMums[ThisMumNum,"Pop"] <- as.vector(unique(thisMumData$homePopn))
    
    # Extract the different CI 
    CI95 <- thisMumData[thisMumData$criticalValues=="***",]
    CI90 <- thisMumData[thisMumData$criticalValues=="***" | thisMumData$criticalValues=="**",]
    CI80 <- thisMumData[thisMumData$criticalValues=="***" | thisMumData$criticalValues=="**" | thisMumData$criticalValues=="*",]
    location95 <- table(CI95$X1)
    location90 <- table(CI90$X1)
    location80 <- table(CI80$X1)
    DetailsMums_95CI[ThisMumNum,"Nsample"] <- sum(location95)
    DetailsMums_90CI[ThisMumNum,"Nsample"] <- sum(location90)
    DetailsMums_80CI[ThisMumNum,"Nsample"] <- sum(location80)
    
    # Sending location of fathers for this mum 
    # 95CI
    for (ThisPop in names(location95)) {
      # ThisPop <- "GA"
      DetailsMums_95CI[ThisMumNum,ThisPop] <- as.vector(location95[ThisPop])
    }
    # immigrants
    theseImm <- names(location95)!=as.vector(unique(thisMumData$homePopn))
    SummaryMums[ThisMumNum,"Imm_95"] <- sum(location95[theseImm])
    # Non-immigrants
    theseHome <- names(location95)==as.vector(unique(thisMumData$homePopn))
    SummaryMums[ThisMumNum,"Home_95"] <- sum(location95[theseHome])
    # Percentage
    total <- sum(location95[theseImm])+sum(location95[theseHome])
    SummaryMums[ThisMumNum,"Imm_95_Perc"] <- sum(location95[theseImm])/total
    SummaryMums[ThisMumNum,"Home_95_Perc"] <- 1-(sum(location95[theseImm])/total)
    # 90CI
    for (ThisPop in names(location90)) {
      # ThisPop <- "GA"
      DetailsMums_90CI[ThisMumNum,ThisPop] <- as.vector(location90[ThisPop])
    }
    # immigrants
    theseImm <- names(location90)!=as.vector(unique(thisMumData$homePopn))
    SummaryMums[ThisMumNum,"Imm_90"] <- sum(location90[theseImm])
    # Non-immigrants
    theseHome <- names(location90)==as.vector(unique(thisMumData$homePopn))
    SummaryMums[ThisMumNum,"Home_90"] <- sum(location90[theseHome])
    # Percentage
    total <- sum(location90[theseImm])+sum(location90[theseHome])
    SummaryMums[ThisMumNum,"Imm_90_Perc"] <- sum(location90[theseImm])/total
    SummaryMums[ThisMumNum,"Home_90_Perc"] <- 1-(sum(location90[theseImm])/total)
    # 80CI
    for (ThisPop in names(location80)) {
      # ThisPop <- "GA"
      DetailsMums_80CI[ThisMumNum,ThisPop] <- as.vector(location80[ThisPop])
    }
    # immigrants
    theseImm <- names(location80)!=as.vector(unique(thisMumData$homePopn))
    SummaryMums[ThisMumNum,"Imm_80"] <- sum(location80[theseImm])
    # Non-immigrants
    theseHome <- names(location95)==as.vector(unique(thisMumData$homePopn))
    SummaryMums[ThisMumNum,"Home_80"] <- sum(location80[theseHome])
    # Percentage
    total <- sum(location80[theseImm])+sum(location80[theseHome])
    SummaryMums[ThisMumNum,"Imm_80_Perc"] <- sum(location80[theseImm])/total
    SummaryMums[ThisMumNum,"Home_80_Perc"] <- 1-(sum(location80[theseImm])/total)
  } # end loop over mums
  write.csv(as.data.frame(DetailsMums_95CI),file="DetailsMums_95CI.csv",row.names=FALSE,na = " ")
  write.csv(as.data.frame(DetailsMums_90CI),file="DetailsMums_90I.csv",row.names=FALSE,na = " ")
  write.csv(as.data.frame(DetailsMums_80CI),file="DetailsMums_80CI.csv",row.names=FALSE,na = " ")
  write.csv(as.data.frame(SummaryMums),file="SummaryMums.csv",row.names=FALSE,na = " ")
  cat("\n ... Data summaries sent to following files: \n")
  cat("\n ....... DetailsMums_95CI.csv \n")
  cat("\n ....... DetailsMums_90CI.csv \n")
  cat("\n ....... DetailsMums_80CI.csv \n")
  cat("\n ....... SummaryMums.csv \n")
  
} # End function
