##################################
#                                #
#  Expected Gamete frequencies   #
#      Population level          #
#      Hexaploid & Tetraploid    #
#      Author: David Field       #
#         1/2/2010               #
#       updates 10/6/2012        #
################################## 

# test   inData <- currentFileData
#        alleleFrequenciesTable <- alleleFreqTable

#Main function to calculate expecte gamete frequencies at equilibrium for a population
gameteFreq <- function(inData,alleleFrequenciesTable,numLoci,ploidy,DRRtable,DRRtype) {
  cat("\n    Calculating Expected Gamete Frequencies....")
  flush.console()
  if (ploidy==6) {                               
    gameteFreqGivenPopn <- gameteFrequencyPopHex       # frequency of a given gamete
  }
  if (ploidy==4) {         
    gameteFreqGivenPopn <- gameteFrequencyPopTetr      # frequency of a given gamete
  }
  strip.NAs <- function(vv) {
  return(vv[!is.na(vv)])
  }
  lociRanges <- matrix(4:ncol(inData),ncol=ploidy,byrow=TRUE)
  inData <- subset(inData,subset=is.na(mother))
  popnListData <- split(inData,inData$pop)
  # gameteFrequenciesTable$HP7[[2]]
  # colnames(gameteFrequenciesTable$HP7[[2]])
  
  popnGameteProbTable <- lapply(popnListData,  ##Loop over populations in popnList
                          function(thisPopn,alleleFrequenciesTable,DRRtable,DRRtype) {
                            #test thisPopn <- popnListData[[1]]
                            #     nrow(gameteFrequenciesTable$HP7)
                            #     thisPopName<-"combined"
                            #     numAdults <- nrow(thisPopn)
                            
                            gameteProbs <- list()
                            thisPopName <- as.vector(unlist(as.vector(unique(thisPopn["pop"]))))
                            for (thisLocus in 1:numLoci) {
                              # thisLocus <- 1
                              # Pull out DRR rate for current locus
                              if (DRRtype == "fixed") {
                                DRR <- as.vector(DRRtable[thisLocus,2])
                                if (DRR == "min") {
                                DRRgams <- 0.0
                                }
                                if (DRR == "max") {
                                  if (ploidy == 6) {
                                      DRRgams <- 0.2727
                                  }
                                  if (ploidy == 4) {
                                      DRRgams <- 0.1428
                                  }
                                }
                              }
                              
                              if (DRRtype == "general") {
                                DRR <- as.vector(DRRtable[thisLocus,1])
                              }
                              popnAlleles <- as.vector(sort(strip.NAs(unique(unlist(thisPopn[,lociRanges[thisLocus,]])))))
                              numAlleles <- length(popnAlleles)
                              gams1 <- combinations(numAlleles,ploidy/2,popnAlleles,repeats=TRUE)
                              total <- (length(gams1))/(ploidy/2)
                              gameteMatrix <- matrix(0,nrow=1,ncol=total)
                              gameteNames <- matrix(0,nrow=1,ncol=total)
                              for (thisrow in 1:total) {
                                gameteNames[1,thisrow] <- as.vector(paste(gams1[thisrow,],collapse=" "))
                              }
                              colnames(gameteMatrix) <- gameteNames
                              # Expected gamete frequencies
                              for (thisGam in 1:length(gameteMatrix)) {
                                    # thisGam <- 1
                                    # gams1[thisGam,]
                                    thisGamCharacter <- as.character(gams1[thisGam,])
                                    gameteMatrix[1,thisGam] <- gameteFreqGivenPopn(thisGamCharacter,
                                                                alleleFrequenciesTable[[thisPopName]][[thisLocus]],DRR,epsilon)
                              }
                              gameteProbs[[thisLocus]] <- gameteMatrix
                            } ## End Locus loop
                            return (gameteProbs)
                          } ## End lapply function
                           ,alleleFrequenciesTable, DRRtable,DRRtype) ## End lapply
   cat("COMPLETE \n")
            return(popnGameteProbTable)
  }  #end "getExpectedGameteFreqs" function
