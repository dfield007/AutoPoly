#########################################
#       Assignment test of simulated    #
#        genotypes/phenotypes           #
#          Author: David Field          #
#          Date: 1/2/2010               #
#########################################

simAssignment <- function (inData,alleleFrequenciesTable, gameteFrequenciesTable1, gameteFrequenciesTable2, 
                           ploidy, marker, numOffspringSim, selfing, DRRtable1, DRRtable2, segTable1,
                           segTable2, DRRtype, simMissLoci, lociMin, epsilon, errorRate, output.txt,immRateSim)  {
  
  # Temp stuff
#  motherknown <- FALSE
#  inData <- EremophilaData
#  selfing <- 0.00
#  simMissLoci <- 0.00
#  marker <- "phenotype"
#  subsetSampMatePop <- 250
#  simulations <- 100
#  numMothersSim <- 1
#  immigrantRate <- 0.5
#  referenceSize <- 60
#  propDRR <- 1.0
#  errorRate <- 0.02
#  ploidy <- 6
#  DRRtype <- "general"
#  DRRtable1 <- DRRtable_1
#  DRRtable2 <- DRRtable_2
#  alleleFrequenciesTable <- alleleFreqTable
#  gameteFrequenciesTable1 <- gameteFreqTable1
#  gameteFrequenciesTable2 <- gameteFreqTable2
  ####
  
    cat("\n ** Beginning Simulation of Assignment tests.... **\n")
    flush.console()

    strip.NAs <- function(vv) {
    return(vv[!is.na(vv)])
    }

 
    ############################################
    ## Run the simulation & assignment testing #
    ############################################

    if (marker == "phenotype" & motherknown == FALSE) {
          # Simulates genotypes when mother unknown
          simData <- simulate.genos.mother.unknown(inData, alleleFrequenciesTable, gameteFrequenciesTable1, 
                                             ploidy, marker, numOffspringSim, simMissLoci, selfing, errorRate,immRateSim)
          # run convert phenotypes function
          inDataSimData <- convert.phenotypes(simData, numLoci, ploidy)
          # Look for dud simulated individuals
          inDataSimData <- NonDudIndividuals(inDataSimData,numLoci,ploidy,lociMin)
          # Find the number of real adults for simdata
          numGoodAdults <- length(with(inDataSimData,unique(ID[is.na(mother)])))
          # Pull out ActualCrosses
          ActualCrosses <- inDataSimData[-(1:numGoodAdults),"ActualCross",drop=FALSE]
          inDataSimData <- inDataSimData[,1:((ploidy*numLoci)+3)]
          # Run assignment test on simulated individuals
          simResults <- assignmentPheno(inDataSimData,alleleFrequenciesTable,gameteFrequenciesTable2,
                                        numLoci,ploidy,motherknown,DRRtable2,DRRtype,segTable2)
     }
     if (marker == "genotype" & motherknown == FALSE) {
          inDataSimData <- simulate.mother.unknown(inData, alleleFrequenciesTable,gameteFrequenciesTable, 
                                                   ploidy, marker, simulations, simMissLoci, selfing,immRateSim)
          # Look for dud simulated individuals
          inDataSimData<-NonDudIndividuals(inDataSimData,numLoci,ploidy,lociMin) 
          # Find the number of real adults for simdata
          numGoodAdults <- length(with(inDataSimData,unique(ID[is.na(mother)])))
          # Pull out ActualCrosses
          ActualCrosses<-inDataSimData[-(1:numGoodAdults),"ActualCross",drop=FALSE]
          inDataSimData<-inDataSimData[,1:((ploidy*numLoci)+3)]
          # Run assignment test on simulated individuals
          #cat("       Assignment of Simulated Individuals..... \n")
          simResults <- assignmentGeno(inDataSimData,alleleFrequenciesTable,gameteFrequenciesTable,
                                       numLoci,ploidy,motherknown,DRR)
    }
    ###############################################
    # Run posthoc tests on simulated individuals  #
    ###############################################

    # running posthoc
    simPostHoc <- postHocTests(inDataSimData,simResults,epsilon)
    # Collapsing ActualCrosses to be compatible with rankings
    for (thisRow in 1:nrow(ActualCrosses)) {
         #test thisRow<-12
         thesePops<-unlist(strsplit(ActualCrosses[thisRow,]," "))
         thesePops<- unique(thesePops)
         if (length(thesePops) == 2) {
            ActualCrosses[thisRow,] <- paste(thesePops, collapse=" ")
         }
         if (length(thesePops) == 1) {
            ActualCrosses[thisRow,]<- thesePops
         }
     }
    simPostHoc <- cbind(simPostHoc, ActualCrosses)

    #####################
    # Critical Delta    #
    #####################
    # Object with all Delta1 scores
    allDelta1<- simPostHoc[,"Delta1"]
    allDelta1Sorted<- sort(simPostHoc[,"Delta1"])
    # Objects storing correct & incorrect Delta1 Scores
    correctAssign <- simPostHoc[,"1"]==simPostHoc[,"ActualCross"]
    incorrectAssign <- simPostHoc[,"1"]!=simPostHoc[,"ActualCross"]
    Correct <- simPostHoc[correctAssign,]
    InCorrect <- simPostHoc[incorrectAssign,]
    grandTotal <- nrow(Correct) + nrow(InCorrect)
    critcal80 <- "empty"
    critcal90 <- "empty"
    critcal95 <- "empty"
    critcal99 <- "empty"
    Correcttest80 <- NULL
    Correcttest90 <- NULL
    Correcttest95 <- NULL
    Correcttest99 <- NULL
    Unresolved80 <- NULL
    Unresolved90 <- NULL
    Unresolved95 <- NULL
    Unresolved99 <- NULL
    percentAssignableat80 <- NULL
    percentAssignableat90 <- NULL
    percentAssignableat95 <- NULL
    percentAssignableat99 <- NULL

    ########################
    # Loop over all Delta1 #
    ########################
    for (thisDelta in allDelta1Sorted) {
        # test thisDelta<- allDelta1Sorted[1]
        Correcttest <- sum(as.numeric(Correct$"Delta1">=thisDelta))
        InCorrecttest <- sum(as.numeric(InCorrect$"Delta1">=thisDelta))
        PercentCorrect <- Correcttest/(Correcttest+ InCorrecttest)
        # finding the critical regions for 80, 90, 95 * 99% confidence
        if (PercentCorrect >= 0.80 & critcal80=="empty") {
            critcal80 <- thisDelta
            Correcttest80<- sum(as.numeric(allDelta1>=critcal80))
            Unresolved80<- sum(as.numeric(allDelta1<critcal80))
            percentAssignableat80<- Correcttest80/(Correcttest80+Unresolved80)
            #Correcttest80<- Correcttest
            #Unresolved80<- grandTotal-Correcttest80
        }
        if (PercentCorrect >= 0.90 & critcal90=="empty") {
            critcal90 <- thisDelta
            Correcttest90<- sum(as.numeric(allDelta1>=critcal90))
            Unresolved90<- sum(as.numeric(allDelta1<critcal90))
            percentAssignableat90<- Correcttest90/(Correcttest90+Unresolved90)
            #Correcttest90<-Correcttest
            #Unresolved90<-grandTotal-Correcttest90
            #percentAssignableat90<- Correcttest/grandTotal
        }
        if (PercentCorrect >= 0.95 & critcal95=="empty") {
            critcal95 <- thisDelta
            Correcttest95<- sum(as.numeric(allDelta1>=critcal95))
            Unresolved95<- sum(as.numeric(allDelta1<critcal95))
            percentAssignableat95<- Correcttest95/(Correcttest95+Unresolved95)
            #Correcttest95<-Correcttest
            #Unresolved95<-grandTotal-Correcttest95
            #percentAssignableat95<- Correcttest/grandTotal
        }
        if (PercentCorrect >= 0.99 & critcal99=="empty") {
            critcal99 <- thisDelta
            Correcttest99<- sum(as.numeric(allDelta1>=critcal99))
            Unresolved99<- sum(as.numeric(allDelta1<critcal99))
            percentAssignableat99<- Correcttest99/(Correcttest99+Unresolved99)
            #Correcttest99<-Correcttest
            #Unresolved99<-grandTotal-Correcttest99
            #percentAssignableat99<- Correcttest/grandTotal
        }
    }
    ######################################
    # Buildling Simulation Summary file  #
    ######################################
    # Header information
    CurrentDate<-date()
    labelSims<-"Simulation Run Completed:"
    labelfilename<-"File   = "
    labelPloidy<-"Ploidy = "
    labelMarker<-"Marker = "
    labelMother<-"Mother = "
    labelSimsmatrix<-matrix(0,5,2)
    labelSimsmatrix[1,1]<- labelSims
    labelSimsmatrix[2,]<- c(labelfilename,filename)
    labelSimsmatrix[3,]<- c(labelPloidy,ploidy)
    labelSimsmatrix[4,]<- c(labelMarker,marker)
    labelSimsmatrix[5,]<- c(labelMother,motherknown)
    labelSimsmatrix[1,2]<- CurrentDate
    SimDetails1<-paste(labelSimsmatrix[1,1],labelSimsmatrix[1,2])
    SimDetails2<-paste(labelSimsmatrix[2,1],labelSimsmatrix[2,2])
    SimDetails3<-paste(labelSimsmatrix[3,1],labelSimsmatrix[3,2])
    SimDetails4<-paste(labelSimsmatrix[4,1],labelSimsmatrix[4,2])
    SimDetails5<-paste(labelSimsmatrix[5,1],labelSimsmatrix[5,2])
    # Header matrix
    headerMatrix<-matrix(0,16,1)
    headerMatrix[1,]<-c("                                                ")
    headerMatrix[2,]<-c(" ********************************************** ")
    headerMatrix[3,]<-c(" *          PolyAssign 1.0 (1.2.2010)         * ")
    headerMatrix[4,]<-c(" *    Simulation of Assignment testing        * ")
    headerMatrix[5,]<-c(" *          Author: David Field               * ")
    headerMatrix[6,]<-c(" ********************************************** ")
    headerMatrix[7,]<-c("                                                ")
    headerMatrix[8,]<-SimDetails1
    headerMatrix[9,]<-c("                                                ")
    headerMatrix[10,]<-SimDetails2
    headerMatrix[11,]<-SimDetails3
    headerMatrix[12,]<-SimDetails4
    headerMatrix[13,]<-SimDetails5
    headerMatrix[14,]<-c("                                                ")
    headerMatrix[15,]<-c(" ** Summary Statistics **")
    headerMatrix[16,]<-c("                                                ")
    headerMatrix<-as.data.frame(headerMatrix)

    # Summary of simulations
    SimsSummary<-matrix(0,4,5)
    colnames(SimsSummary)<-c("Level    ","CF(%)","Delta","N-Sims","Success(%)")
    SimsSummary[,"Level    "]<-c("Strict    ","Moderate","Relaxed  ","Total     ")
    #SimsSummary[,"Level    "]<-c("Strict","Moderate","Relaxed","Total")
    SimsSummary[,"CF(%)"]<-c("0.95","0.90","0.80","  ")
    SimsSummary[,"Delta"]<-c(signif(critcal95,3),signif(critcal90,3),signif(critcal80,3),"  ")
    SimsSummary[,"N-Sims"]<-c(Correcttest95,Correcttest90,Correcttest80,grandTotal)
    SimsSummary[,"Success(%)"]<-c(signif(percentAssignableat95*100,3),
                                   signif(percentAssignableat90*100,3),
                                   signif(percentAssignableat80*100,3)," ")
    # Sending to output file
    if (output.txt==TRUE) {
        FLAG<-TRUE
        # Send multilocus data to excel file
        write.csv(simPostHoc,"simsAssignmentFull.csv",row.names=FALSE)
        cat("Simulated individuals, Assignment likelihoods sent to: 'simsAssignmentFull.csv' \n")
        # Send header to export file
        write(t(headerMatrix),"SimsSummary.txt",append=TRUE)
        # Send summary of simulations to export file
        write.table(as.data.frame(SimsSummary),"SimsSummary.txt",append=FLAG,quote=FALSE,sep="\t",row.names=FALSE)
        cat("Simulation summary sent to: 'SimsSummary.txt' \n")
    }
    if (output.txt==FALSE) {
            # Summary of simulations
        SimsSummary<-matrix(0,4,5)
        colnames(SimsSummary)<-c("Level","CF(%)","Delta","N-Sims","Success(%)")
        #SimsSummary[,"Level    "]<-c("Strict    ","Moderate","Relaxed  ","Total     ")
        SimsSummary[,"Level"]<-c("Strict","Moderate","Relaxed","Total")
        SimsSummary[,"CF(%)"]<-c("0.95","0.90","0.80","  ")
        SimsSummary[,"Delta"]<-c(round(critcal95,4),round(critcal90,4),round(critcal80,4),"  ")
        SimsSummary[,"N-Sims"]<-c(Correcttest95,Correcttest90,Correcttest80,grandTotal)
        SimsSummary[,"Success(%)"]<-c(signif(percentAssignableat95*100,3),
                                   signif(percentAssignableat90*100,3),
                                   signif(percentAssignableat80*100,3)," ")
        SimsSummary<-as.data.frame(SimsSummary)

        # Send multilocus data to excel file
        write.csv(simPostHoc,"simsAssignmentFull.csv",row.names=FALSE)
        cat("** Simulation Summary Statistics ** \n")
        print(as.data.frame(SimsSummary))
        cat("\n Simulated individuals, Assignment likelihoods sent to: 'simsAssignmentFull.csv' \n")
        }
    
    return(as.data.frame(SimsSummary))

}

# Function to return individuals that meet the minimum loci criteria
NonDudIndividuals<-function(inDataSimData,numLoci,ploidy,lociMin) {
                alleleCounts <- matrix(0, nrow(inDataSimData),ncol=numLoci,
                                      dimnames=list(inDataSimData$ID,paste("Locus",1:numLoci)))
                  ## number of alleles present in each set - store in alleleCounts
              for (thisLocus in 1:numLoci) {
                  #testing thisLocus<-1
                  # thisAdult<-3
                  locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
                  ##Note: apply() returns the _transpose_ of the desired matrix
                  ## below - hence the use of t()...
                  inDataSimData[,locusRange] <- t(apply(inDataSimData[,locusRange],1,sort,
                                     na.last = TRUE))
                  ## Store the numbers of alleles detected at each locus
                  alleleCounts[,thisLocus] <- apply(inDataSimData[,locusRange],1,
                                                  function (thisAlleleVector) {
                                                    sum(!is.na(thisAlleleVector))
                                                  })
                  }
                  numLociData <- apply(alleleCounts,1,
                             function (theseAlleleCounts) {
                               sum(theseAlleleCounts > 0)
                             })
                  GoodPlants <- numLociData >= lociMin
                  return(inDataSimData[as.vector(GoodPlants),])
}
