##########################################
# Population genetic Summary Statistics  #
##########################################

# test area
# popnAlleleProbTable <- alleleFreqTable
# popnGameteProbTable <- gameteFreqTable_1
# inData <- EremophilaData
# epsilon <- 0.05
# DRRtable <- DRRtable_1
#Main function to calculate expecte gamete frequencies at equilibrium  
getStats <- function(inData,numLoci,ploidy,popnAlleleProbTable,popnGameteProbTable,DRRtable,epsilon) {
  strip.NAs <- function(vv) { 
  return(vv[!is.na(vv)])
  }
  # NEW CODE 2012 ##
  #############################################
  # a) Directing required hexaploid functions #
  #############################################
  if (ploidy==6) {
    getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
    if (marker=="genotype") {
      getHetWeight <- getHetWeightHexGeno
    } else if (marker=="phenotype") {
      getHetWeight <- getHetWeightHexPheno
    }
  }
  ################################################
  # b) Directing required tetraploid functions   #
  ################################################
  
  if (ploidy==4) {
    getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
  }
  
  lociRanges <- matrix(4:ncol(inData),ncol=ploidy,byrow=TRUE)
  inData <- subset(inData,subset=is.na(mother))
  popnListData <- split(inData,inData$pop)
  
popnGenoProbTable <- lapply(popnListData,  ##Loop over populations in popnList
            # thisPopn <- popnListData[[1]]
            function(thisPopn,popnAlleleProbTable,popnGameteProbTable,numLoci,ploidy,DRRtable,epsilon) {
            pops <- names(popnListData[])
            numPops <- length(pops)
            numAdults <- nrow(thisPopn)
            genotypeProbs <- list()
            pop <- as.vector(unique(thisPopn["pop"]))
            thisPopName <- as.vector(unlist(pop))
             #Matrix for output of population statistics
              popGenStats <- list()
              popGenStatsMatrix <- matrix(0,nrow=(numLoci)+3,ncol=7)
              colnames(popGenStatsMatrix) <- c("Locus","N","A","Ph","Ho","He","F") 
              popGenStatsMatrix[1:numLoci,1] <- (1:numLoci)
              popGenStatsMatrix[numLoci+1,1] <- "Mean:"
              popGenStatsMatrix[numLoci+2,1] <- "SD:"
              popGenStatsMatrix[numLoci+3,1] <- "SE:"
             # popGenStatsMatrix[1,2:9] <- NA 
            #  popGenStatsMatrix[numLoci+5,1:9] <- NA 
            #  popGenStatsMatrix[numLoci+2,1:9] <- NA
            #  popGenStatsMatrix[numLoci+2,1:9] <- NA
              cat("\n ***** Processing population",thisPopName, "***** \n")
            ##################
            # Loop over loci #
            ##################  
              for (thisLocus in 1:numLoci) {      
                  cat("\n   Processing locus",thisLocus,"of",numLoci,"\n")
                  flush.console() 
                  DRRthisLocus <- DRRtable[thisLocus,1]
                 # thisLocus <- 1
                  # Pulling out data for this pop and this locus
                  thisPopnThisLocus <- thisPopn[,lociRanges[thisLocus,]]
                 #extracting the name of the locus for the output file
                  locusNameAll <- names(thisPopnThisLocus)
                  lengthLoci <- nchar(locusNameAll[1])
                  locusName <- substr(locusNameAll[1],6,lengthLoci-1)
                 # popGenStatsMatrix[(thisLocus+1),1] <- as.character(locusName)
                 #Number of adults in sample: 
                 
                 #Function to remove adults missing all data at the locus
                  goodAdults<-function(thisPopnThisLocus,ploidy) {
                             numAdults<-nrow(thisPopnThisLocus)
                             goodAdults<-matrix(0,nrow=numAdults)
                             for (thisAdult in 1:numAdults) {
                                  if (sum(is.na(thisPopnThisLocus[thisAdult,]))!=ploidy) {
                                      goodAdults[thisAdult,]<-rownames(thisPopnThisLocus[thisAdult,])
                                  }
                              } 
                              goodAdults<-goodAdults[goodAdults!=0,]
                              thisPopnThisLocus<-thisPopnThisLocus[goodAdults,]
                              return(thisPopnThisLocus)
                  }
                   #Running function           
                   thisPopnThisLocus <- goodAdults(thisPopnThisLocus,ploidy)           
                 #sending number of adults to summary
                  numAdults <- nrow(thisPopnThisLocus)
                  popGenStatsMatrix[(thisLocus),2] <- numAdults
           
                 #extracting no. of alleles at the locus for the output file
                  popnAlleles <- sort(strip.NAs(unique(unlist
                                (thisPopnThisLocus))))
                  numAlleles <- length(popnAlleles)
                  popGenStatsMatrix[(thisLocus),3] <- numAlleles
                               
                  #################################               
                  #     All possible genotypes   ##
                  #################################
                 
                  genos1 <- combinations(numAlleles,ploidy,popnAlleles,repeats=TRUE)
                      
                      #testing area   ######################################################################
    #                            lociRanges <- matrix(4:ncol(inData),ncol=ploidy,byrow=TRUE)
    #                            inData <- subset(inData,subset=is.na(mother))
    #                            popnListData <- split(inData,inData$pop)
    #                            length(genoMatrix)
    #                            thisGam<-968
    #                            thisGeno<-1
    #                            thisPopnName <-"GE"
    #                            thisLocus<-5
    #                            thisPopnInLoop<-unique(thisPopn$pop)
    #                            thisPopn<-popnListData[[thisPopnInLoop]]
                              #getProbGenotypeGivenPopn(thisGenotype,popnGameteProbTable[[thisPopName]][[thisLocus]],DRR,epsilon)
                              #thisGenotype<-c("214","216","216","218","218","220")
                      #          pop<-as.vector(unique(thisPopn["pop"]))
                      #          pop<-pop[1,1] 
                        #                             thisPopName<-"GN"
                  # End test area  #####################################################
            
            ### Testing alternative 1
            ### Testing alternative expected genotype frequencies using apply function                  
     #             total<-(length(genos1))/(ploidy)
    #              newColsGenos1<-matrix(0,nrow=total,ncol=1)
    #              newColsGenos1<-apply(genos1,1,function(x) paste (x,collapse=" "))
    #              cat("\n     Calculating Expected Genotype Frequencies for RceS... \n")   
    #              freqsRceS<-as.vector(tapply(newColsGenos1,1:total,getProbGenotypeGivenPopn2, 
    #                                    popnGameteProbTableRceS[[thisPopName]][[thisLocus]],0,epsilon))
    #              cat("\n     Calculating Expected Genotype Frequencies for RceD... \n")   
    #              freqsRceD<-as.vector(tapply(newColsGenos1,1:total,getProbGenotypeGivenPopn2, 
    #                                    popnGameteProbTableRceD[[thisPopName]][[thisLocus]],0,epsilon))

                  
    #              newColsGenos<-matrix(0,nrow=total,ncol=7)
    #              genos1<-cbind(genos1,newColsGenos)
    #              cat("\n     Calculating Expected Genotype Frequencies \n")   
    #              for (thisGeno in 1:total) {
                     # calculate under RceS
    #                    genos1[thisGeno,7]<-getProbGenotypeGivenPopn(genos1[thisGeno,1:6],
    #                                    popnGameteProbTableRceS[[thisPopName]][[thisLocus]],0,epsilon)
    #                  # calculate under RceD DRRmax value
    #                    genos1[thisGeno,8]<-getProbGenotypeGivenPopn(genos1[thisGeno,1:6],
    #                                      popnGameteProbTableRceD[[thisPopName]][[thisLocus]],DRR,epsilon)         
    #              }
                  
         #testing end         
         #####################################################################################         
           
            ###################################
            ## Expected genotype frequencies ##
            ###################################     
                  
            # !!!!  Working from this one in 2012 !!! ###
            ### Testing alternative 2
                  total <- (length(genos1))/(ploidy)
                  newColsGenos <- matrix(0,nrow=total,ncol=7)
                  genos1 <- cbind(genos1,newColsGenos)
                #  cat("\n     Calculating Expected Genotype Frequencies \n")   
                  for (thisGeno in 1:total) {
                    # thisGeno <- 1
                    # Calculate expected genotype frequencies
                  thisGenotype <- genos1[thisGeno,1:ploidy]    
                  genos1[thisGeno,7] <- getProbGenotypeGivenPopn(thisGenotype,popnGameteProbTable[[thisPopName]][[thisLocus]],
                                           popnAlleleProbTable[[thisPopName]][[thisLocus]],DRRthisLocus,epsilon)
                  }
                  # column names for genotype matrix 
                    colnames(genos1)<-c("a1","a2","a3","a4","a5","a6","ExpFreq",
                                        "freq - RceD","pheno","phenocode","H - RceS",
                                        "H - RceD","Weight")
                  # Finding phenotype of each genotype
                    for(thisrow in 1:total) {
                        pheno <- paste(unique(genos1[thisrow,1:6]),collapse=" ")
                        genos1[thisrow,"pheno"] <- pheno
                    }
                          
                          # Determines phenocode
                 #         cat("\n     Calculating Expected Phenotypes \n")   
                          genos1 <- genos1[order(unlist(genos1[,"pheno"])),] 
                          phenoCount <- 1 
                          genos1[1,"phenocode"] <- phenoCount
                          for (thisGeno in 2:total) {
                              if (as.vector(genos1[thisGeno-1,"pheno"]!=genos1[thisGeno,"pheno"])) {
                                 phenoCount<-phenoCount+1 
                                 genos1[thisGeno,"phenocode"]<-phenoCount
                              } else if (as.vector(genos1[thisGeno-1,"pheno"]==genos1[thisGeno,"pheno"])) {
                                 genos1[thisGeno,"phenocode"]<-phenoCount
                              }
                           }
                               
                  ############################
                  # Expected heterozygosity  #
                  ############################              
                #    cat("\n     Calculating Expected Heterozygosity \n")   
                   ### If marker genotype ###    
                  
                  # NOTE genotype data not working yet !! ##
                      if (marker=="genotype") {
                      # calculate weightings                              
                #          cat("\n     Calculating Weightings \n")   
                        for (thisGeno in 1:total) {
                            genos1[thisGeno,"Weight"]<-getHetWeight(as.numeric(genos1[thisGeno,1:6]))
                        }
                        #multiplying frequency by heterozygote weighting to get:
                      #"H - RceS"
                        scoresRceS<-matrix(0,nrow=total,ncol=2)
                        scoresRceS[,1]<-as.numeric(genos1[,"ExpFreq"])
                        scoresRceS[,2]<-as.numeric(genos1[,"Weight"])
                        genos1[,"ExpFreq"]<-apply(scoresRceS,1,prod)
                      #"H - RceD"
             #           scoresRceD<-matrix(0,nrow=total,ncol=2)
            #            scoresRceD[,1]<-as.numeric(genos1[,"freq - RceD"])
            #            scoresRceD[,2]<-as.numeric(genos1[,"Weight"])
            #            genos1[,"H - RceD"]<-apply(scoresRceD,1,prod)
                      #sending to summary stats
                        popGenStatsMatrix[(thisLocus),"He"]<-sum(as.numeric
                                                        (genos1[,"ExpFreq"]))
             #           popGenStatsMatrix[(thisLocus+1),8]<-sum(as.numeric
            #                                            (genos1[,"H - RceD"]))
                      #find number of genotypes
                #        colnames(popGenStatsMatrix)<-c("Locus","N","A","Ge","Ho","RceS-He",
                #                                      "RceS-F","RceD-He","RceD-F") 
                #        numPhenoM<-matrix(0,nrow=nrow(thisPopnThisLocus))
                        for (thisPheno in 1:nrow(thisPopnThisLocus)) {
                            numPhenoM[thisPheno,1]<-paste(strip.NAs(thisPopnThisLocus[thisPheno,]),collapse=" ")
                        }
                        numPhenotypes<-unique(numPhenoM)             

                  ### If marker phenotype ###           
                      } else if (marker=="phenotype") {
            #              cat("\n     Processing Phenotype Markers \n")   
                        #first sort phenotypes and reduce matrix  
                          phenoranks <- order(as.numeric(genos1[,"phenocode"]))
                          genos1 <- genos1[phenoranks,]
                          rownames(genos1) <- 1:total
                        #function for reducing genotype to phenotype matrix
              #            cat("\n     Reducing Matrix \n")   
                          getExpPhenoFreq<-function(genos1,total) { 
                                sumFreqRceS <- aggregate.data.frame(as.numeric(genos1[,"ExpFreq"]), 
                                                        by = list(genos1[,"pheno"]), sum)
                            #    sumFreqRceD <- aggregate.data.frame(as.numeric(genos1[,"freq - RceD"]), 
                            #                            by = list(genos1[,"pheno"]), sum)
                                totalPhenos<-nrow(sumFreqRceS)
                                allPhenos<-unique(genos1[,"pheno"]) 
                                phenolist<-strsplit(allPhenos," ")
                                phenoVec<-unlist(lapply(phenolist,length))
                                weightTable<-c(0,0.48888,0.71111,0.833333,0.9333333,1.0)
                                Weights <- weightTable[phenoVec]
                                phenoMat <- cbind(allPhenos,sumFreqRceS[,"x"],0,Weights)           
                                colnames(phenoMat) <- c("pheno","sum Exp Freq","sum freq - RceD","Weight")
                                return(phenoMat)
                              }
                          #run function 
                             phenoMat <- getExpPhenoFreq(genos1,total)
                        # calculate H
                            ExpPhenoFreq <- matrix(0,nrow=nrow(phenoMat),ncol=2)
                            colnames(ExpPhenoFreq) <- c("H - DRR","H - empty")
                           #"H - DRR"
                            scoresRceS <- matrix(0,nrow=nrow(phenoMat),ncol=2)
                            scoresRceS[,1] <- as.numeric(phenoMat[,"sum Exp Freq"])
                            scoresRceS[,2] <- as.numeric(phenoMat[,"Weight"])
                            ExpPhenoFreq[,"H - DRR"] <- apply(scoresRceS,1,prod)
                           #"H - RceD"
                     #       scoresRceD<-matrix(0,nrow=nrow(phenoMat),ncol=2)
                    #        scoresRceD[,1]<-as.numeric(phenoMat[,"sum freq - RceD"])
                    #        scoresRceD[,2]<-as.numeric(phenoMat[,"Weight"])
                    #        ExpPhenoFreq[,"H - RceD"]<-apply(scoresRceD,1,prod)
                           #sending to summary stats
                            popGenStatsMatrix[(thisLocus),6]<-sum(as.numeric
                                                              (ExpPhenoFreq[,"H - DRR"]))
                     #       popGenStatsMatrix[(thisLocus+1),8]<-sum(as.numeric
                      #                                        (ExpPhenoFreq[,"H - RceD"]))
                      
                         ##################################
                         # number of observed phenotypes  #
                         ################################## 
                     
          #                  cat("\n     Observed no. of Phenotypes \n")   
                #            colnames(popGenStatsMatrix)<-c("Locus","N","A","Ph","Ho","RceS-He",
                #                                          "RceS-F","RceD-He","RceD-F") 
                            numPhenoM <- matrix(0,nrow=nrow(thisPopnThisLocus))
                            for (thisPheno in 1:nrow(thisPopnThisLocus)) {
                                numPhenoM[thisPheno,1]<-paste(strip.NAs(thisPopnThisLocus[thisPheno,]),collapse=" ")
                            }
                            numPhenotypes <- unique(numPhenoM)             
                            popGenStatsMatrix[(thisLocus),"Ph"] <- nrow(numPhenotypes)
                      } #end marker phenotype
                                   
                      ################################       
                      ##  Observed heterozygosity   ##
                      ################################        
      #                cat("\n     Observed Heterozygosity \n")   
                        ObsHetMatrix <- matrix(0,nrow=nrow(thisPopnThisLocus),ncol=1)
                        
                        for (thisAdult in 1:nrow(thisPopnThisLocus)) {
                            thisAdultPheno<-strip.NAs(thisPopnThisLocus[thisAdult,])
                            ObsHetMatrix[thisAdult] <- getHetWeight(as.numeric(thisAdultPheno))
                        }
                        popGenStatsMatrix[(thisLocus),"Ho"] <- (apply(ObsHetMatrix,2,sum))/(nrow(thisPopnThisLocus))
                           
                      ###############################       
                      ## F inbreeding coefficient  ##
                      ###############################
          #            cat("\n     F- Inbreeding Coefficient \n")   
                        popGenStatsMatrix[(thisLocus),"F"]<- (1-
                                          (as.numeric(popGenStatsMatrix[(thisLocus),"Ho"])/
                                          as.numeric(popGenStatsMatrix[(thisLocus),"He"])))
                        #Code for if we want expected no. phenotypes
                        #totalExpPheno<-as.numeric(genos1[total,"phenocode"]) 
                        #popGenStatsMatrix[(thisLocus+1),4]<-totalExpPheno
                                   
                        #genotypeProbs[[thisLocus]]<-genoMatrix
              }  ## End Locus loop
              #  return (genotypeProbs) 
                          
          #############################
          ##  Mean & SD across loci  ##
          #############################  
            cat("\n     Mean & SD - sending summary to table \n")   
            for (thisStat in 1:6) {
                # thisStat <- 1
                #Mean across loci
                  meanthisStat <- round(mean(as.numeric(popGenStatsMatrix[1:numLoci,thisStat+1])),digits=3)
                  popGenStatsMatrix[numLoci+1,thisStat+1] <- meanthisStat
                #Standard deviation across loci
                  SDthisStat <- round(sd(as.numeric(popGenStatsMatrix[1:numLoci,thisStat+1])),digits=3)
                  popGenStatsMatrix[numLoci+2,thisStat+1] <- SDthisStat
                #Standard error across loci
                  popGenStatsMatrix[numLoci+3,thisStat+1] <- as.numeric(as.vector(popGenStatsMatrix[numLoci+2,thisStat+1]))/sqrt(numLoci)
            }
          #Reduce decimel places  
    #        for (thisStat in 1:6) {
    #          popGenStatsMatrix[2:(numLoci+1),thisStat+1]<-round(as.numeric(popGenStatsMatrix[2:(numLoci+1),
    #                                                              thisStat]),digits=3)
    #        } #end loop to reduce decimel places
    popGenStats[[thisPopName]] <- popGenStatsMatrix
    filename <- paste(thisPopName,"popGenStats.csv",sep = "_")
    write.csv(popGenStats,file=filename,row.names=FALSE,na = " ",append=TRUE)

    } ## End lapply function   
    ,popnAlleleProbTable,popnGameteProbTable,numLoci,ploidy,DRRtable,epsilon) ## End lapply    
    
  cat("\n Finished Calculating Expected Genotype Frequencies \n")           
            #return(popnGenoProbTable)                  
} #End 'getStats' function     

  
#delete below later
#this below works to extract out a particular genotype frequency from a given pop, loci. 
#popnGenotypeProbTable[["GN"]][[4]][[1,"271 273 276 283 283 288"]]   
#popnGenotypeProbTable[["GN"]][[3]]  
#popnGenotypeProbTable[["GN"]][[3]][[2]]                           
# 
#popnGenotypeProbTable[["GN"]][[3]][[1,"212 212 212 214 214 214"]]    
#                           
#Sum check of expected genotype frequencies
#lapply(popnGenotypeProbTable[["GF"]][[3]], sum)                            
#apply(popnGenotypeProbTable[["GN"]][[3]],1, sum)                            
#colSums(popnGenotypeProbTable[["GN"]][[1]])
#nums<-length(popnGenotypeProbTable[["GN"]][[3]])
#summatrix<-matrix(0,nrow=nums)
#for (i in 1:nums) {
#    summatrix[i,]<-popnGenotypeProbTable[["GF"]][[3]][[i]]
#    }
#sum(summatrix)