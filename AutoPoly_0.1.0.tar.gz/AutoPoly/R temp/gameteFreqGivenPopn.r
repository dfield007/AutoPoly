#########################################
#                                       #
#  Returns the expected frequency of a  #
#      specified gamete                 #
#           to function                 #
#      - Hexaploid & Tetraploid         #
#      Author: David Field              #
#        Date:1/2/2010                  #
######################################### 

gameteFrequencyPopHex <- function (gamete,alleleFrequenciesTable,DRR,epsilon) {
##################
# 1. Hexaploid   #
##################
 
  if (!all(gamete %in% names(alleleFrequenciesTable))) {
    ## If father gamete alleles are not present at all in the population: 
    return(epsilon)
    ## return some other default value-user specified-"epsilon", say
  } 
  if (all(gamete %in% names(alleleFrequenciesTable))) {
    if (DRR == "min") {
      DRR <- 0.0
    } 
    if (DRR == "max") {
      DRR <- 0.2727
    } 
    if (is.numeric(DRR) == TRUE) {
      switch(length(unique(gamete)),
           {##Case "aaa" - alleles identical, so use gamete[1]...
             a <- alleleFrequenciesTable[gamete[1]]
             aaa1<-(((27*((1-DRR)*(3-DRR))) /
                     ((9+DRR)*(9+(2*DRR))))*(a^3))
             aaa2<-((((45*DRR)*(3-DRR)) /
                     ((9+DRR)*(9+(2*DRR))))*(a^2))
             aaa3<-(((20*(DRR^2)) /
                     ((9+DRR)*(9+(2*DRR))))*(a))
             return(aaa1+aaa2+aaa3)
           },
           {##Case "aab".
             ##Note: "a" must be the allele appearing twice...
             tt <- table(gamete)
             a <- alleleFrequenciesTable[names(tt)[tt==2]]
             b <- alleleFrequenciesTable[names(tt)[tt==1]]
             aab1<-(((27*((1-DRR)*(3-DRR)))/((9+DRR)*(9+(2*DRR))))*((a^2)*b))
             aab2<-((((15*DRR)*(3-DRR))/((9+DRR)*(9+(2*DRR))))*(a*b))
             return(3*(aab1+aab2))
           },
           {##Case "abc"
             a <- alleleFrequenciesTable[gamete[1]]
             b <- alleleFrequenciesTable[gamete[2]]
             c <- alleleFrequenciesTable[gamete[3]]
             abc<-(((27*((1-DRR)*(3-DRR))) /
                    ((9+DRR)*(9+(2*DRR))))*((a*b*c)))
             return(6*(abc))
           }
           )
    }
  }
}
     
#alleleFrequenciesTable <- alleleFrequenciesTable$J[[5]]
#gamete <- c("279","279")

#gameteFrequencyPopTetr(gamete,alleleFrequenciesTable,DRR,epsilon)

gameteFrequencyPopTetr <- function (gamete,alleleFrequenciesTable,DRR,epsilon) {
  ##################
  # 2. Tetraploid  #
  ##################
  if (!all(gamete %in% names(alleleFrequenciesTable))) {
    ## If father gamete alleles are not present at all in the population: 
    return(epsilon)
    ## return some other default value-user specified-"epsilon", say
  } 
  if (all(gamete %in% names(alleleFrequenciesTable))) {
    if (DRR == "min") {
      DRR <- 0.0
    } 
    if (DRR == "max") {
      DRR <- 0.14286
    } 
    if (is.numeric(DRR) == TRUE) {
      switch(length(unique(gamete)),
           {##Case "aa" - alleles identical, so use gamete[1]...
             a <- alleleFrequenciesTable[gamete[1]]
             names(a)<-NULL
             aa1<-(a^2)
             aa2<- ((3*DRR)/(2+DRR))*(a*(1-a))
             return(aa1+aa2)
           },
           {##Case "ab".
             a <- alleleFrequenciesTable[gamete[1]]
             b <- alleleFrequenciesTable[gamete[2]]
             names(a)<-NULL
             names(b)<-NULL
             ab1<-(a*b)
             ab2<-((4-(4*DRR))/(2+DRR))
             return(ab1*ab2)
           },
           )
    }
  }
}