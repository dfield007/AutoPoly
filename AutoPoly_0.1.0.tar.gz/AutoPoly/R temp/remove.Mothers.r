# function to remove mothers
removeMothers <- function(inData) {
      whichHaveMothers <- with(inData,!is.na(mother))
      inData[whichHaveMothers,"mother"] <- "u"
      return(inData)
      }
