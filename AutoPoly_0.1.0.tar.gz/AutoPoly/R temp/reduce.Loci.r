# function to reduce the number of loci in a data set
reduceLoci <- function(inData,ploidy,newLociNum) {
  newDataFile <- inData[,1:(3+newLociNum*ploidy)]
  return(newDataFile)
}