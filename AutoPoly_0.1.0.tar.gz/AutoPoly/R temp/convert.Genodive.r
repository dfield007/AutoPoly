# Function to convert from autopoly to Spagedi

# thisRunData <- EremophilaDataNodashAdults



convertGenodive <- function(thisRunData,numLoci,ploidy) {

               pops <- unique(as.vector(thisRunData[,"pop"]))
               numPopsHere <- length(pops)
               numPerPop <- nrow(thisRunData)/numPopsHere
               randomPick <- matrix(0,(nrow(thisRunData)),ncol(thisRunData))
               colnames(randomPick) <- colnames(thisRunData)
               rownames(randomPick) <- 1: nrow(thisRunData)
               randomPick <- as.matrix(randomPick)
#               for (thisPop in 1:numPopsHere) {
#                  # thisPop <- 1
#                  # new Ids for subset data
#                  thisPopName <- pops[thisPop]
#                  numThisPop <- sum(thisRunData[,"pop"] == thisPopName)
#                  newIds <- (1:numThisPop) + (numThisPop*(thisPop-1))
#                  # random numbers referring to rows in original data file
#                  # randomDraws <- round(runif(numThisPop,1,numPerPop),0)
#                  # Random samples
#                  thisRandomSampleNo <- randomDraws + ((thisPop-1)*numPerPop)
#                  randomPick[newIds,] <- as.matrix(thisRunData[thisRandomSampleNo,])
#                  
#                  
#              }
#              # Make dummy X Y coordinates
#              XYValues <- matrix(0,nrow(randomPick),2)
#              XYValues[,] <- 100
#              # combine together
#              SpagDataFile <- cbind(randomPick[,1:2],XYValues,randomPick[,4:ncol(randomPick)])
#              # Changing Id numbers to fit with spagedi requirements
# #             SpagDataFile[,1] <- 1:nrow(SpagDataFile)
                             
              SpagDataFile <- thisRunData               
              # Collapsing genotype data
              newGenoTypeData <- matrix(0,nrow(thisRunData),numLoci)
              for (thisInd in 1:nrow(newGenoTypeData)) {
                  # thisInd <- 1
                  for (thisLocus in 1:numLoci) {
                    # thisLocus <- 1
                    locusRangeFromMain <- 3 + (thisLocus-1)*ploidy + 1:ploidy
                    thisIndData <- SpagDataFile[thisInd,locusRangeFromMain]
                    theseToReplace <- as.vector(is.na(SpagDataFile[thisInd,locusRangeFromMain]))
                    thisIndData[theseToReplace] <- "000"
                    newGenoStyle <- paste(as.vector(thisIndData),collapse="")
                    newGenoTypeData[thisInd,thisLocus] <- newGenoStyle
                  }
              }
              newData <- cbind(SpagDataFile[,2],SpagDataFile[,1],newGenoTypeData) 
               
#              # Make Spagedi Header
#              SpagHeaders <- matrix(0,3,(4+numLoci))
#              # No. samples
#              SpagHeaders[1,1] <- nrow(randomPick)
#              # No. pops
#              SpagHeaders[1,2] <- numPopsHere
3              # Spatial coordinates flag
#              SpagHeaders[1,3] <- 2
#              # No. loci
#              SpagHeaders[1,4] <- numLoci
              # No. digits per allele
#              SpagHeaders[1,5] <- 3
              # Ploidy
#              SpagHeaders[1,6] <- ploidy
              # 2nd row with dummy distance intervals
#              SpagHeaders[2,1] <- 10
#              SpagHeaders[2,2:11] <- (1:10)*2
              # 3rd row header info
#              SpagHeaders[3,1:4] <- c("Ind","Cat","X","Y")
#              SpagHeaders[3,5:(numLoci+4)] <- paste("Loc",1:numLoci,sep="")
              # Final bindings
#              SpagDataFile <- cbind(SpagDataFile[,1:4],newGenoTypeData)
#              SpagDataFile <- rbind(SpagHeaders,SpagDataFile)
#              colnames(SpagDataFile) <- NULL
#              rownames(SpagDataFile) <- NULL

              # Removing 0
#              thesePos <- SpagDataFile[,]==0
#              SpagDataFile[thesePos] <- ""
              #thesePos <- is.na(SpagDataFile)
              #SpagDataFile[thesePos] <- ""
              #SpagDataFile <- as.matrix(SpagDataFile)
              #SpagDataFile[thesePos] <- ""
              # SpagDataFile <- as.data.frame(SpagDataFile)
              return(newData)

}

              
              