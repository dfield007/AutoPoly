###########################################
#  Function to make Segregatation Table   #
#    - for genotype and phenotype markers #
###########################################

# DRRtable <- DRRtable5
# ploidy <- 6
# DRR
          
makeGameteSegTable <- function(ploidy,DRRtable) {
    if (ploidy == 4) {
      SegTableList <- list()
    for (thisLocus in 1:nrow(DRRtable)) {
      # thisLocus <- 1
      DRR <- DRRtable[thisLocus,1]
      SegTableList[[thisLocus]] <- list()
      SegTableList[[thisLocus]][["Monoallele"]] <- list()
      SegTableList[[thisLocus]][["Biallele"]] <- list()
      SegTableList[[thisLocus]][["Triallele"]] <- list()
      SegTableList[[thisLocus]][["Quadriallele"]] <- list()
           
      ##############
      # Monoallele #
      ##############
      segTableThisLocus <- matrix(0,1,1)
      colnames(segTableThisLocus) <- "aaaa"
      rownames(segTableThisLocus) <- "aa"
      segTableThisLocus[1,1] <- 1
      SegTableList[[thisLocus]][["Monoallele"]] <- segTableThisLocus 
      
      ############
      # Biallele #
      ############
      segTableThisLocus <- matrix(0,3,3)
      colnames(segTableThisLocus) <- c("aaab","aabb","bbba")
      rownames(segTableThisLocus) <- c("aa","ab","bb")
      possibleGenos <- colnames(segTableThisLocus)
      for (thisGenoNum in 1:length(possibleGenos)) {
        # thisGenoNum <- 3
        thisGeno <- possibleGenos[thisGenoNum]
        thisGeno <- as.vector(unlist((strsplit(thisGeno,""))))
        thisTable <- t(as.matrix(sort(table(thisGeno),decreasing=TRUE)))
        ##########################################################
        # Biallele type I (simplex), if max no. of allele is 3
        if (max(thisTable) == 3) { 
            gametes <- c("A1xA1","A1xA2","A2xA2")
            # Segregation probabilities
            theseFreq <- c((0.5+(DRR/4)),(0.5-(DRR/2)),(DRR/4))
            gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
            gametes <- gsub("A2", colnames(thisTable)[2], gametes)
            gametes <- gsub("x", "", gametes)
            
            for (thisGameteNum in 1:length(gametes)) {
              # thisGameteNum <- 1
              thisGamete <- gametes[thisGameteNum]
              gametes[thisGameteNum] <- paste(sort(unlist(strsplit(thisGamete,""))),collapse="")
            }
            names(theseFreq) <- gametes
            for (thisGamete in names(theseFreq)) {
                # thisGamete <- names(theseFreq[1])
              segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector(theseFreq[thisGamete])           
            }    
        }   
        ########################################################
        # Biallele type 2 (duplex), if max no. of allele is 2
        if (max(thisTable) == 2) {   
            gametes <- c("A1xA1","A1xA2","A2xA2")
            # Segregation probabilities
            theseFreq <- c(((1/6)+(DRR/3)),((4/6)-((2*DRR)/3)),((1/6)+(DRR/3)))
            gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
            gametes <- gsub("A2", colnames(thisTable)[2], gametes)
            gametes <- gsub("x", "", gametes)
            names(theseFreq) <- gametes
            for (thisGamete in names(theseFreq)) {
                # thisGamete <- names(theseFreq[1])
              segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector(theseFreq[thisGamete])           
            }
        }   
      } # End Biallele
      # Average segregation ratios for phenotype markers
      segTableThisLocus <- cbind(segTableThisLocus, matrix(apply(segTableThisLocus,1,mean),3,1))
      colnames(segTableThisLocus)[4] <- "Pheno"
      # Send to list
      SegTableList[[thisLocus]][["Biallele"]] <- segTableThisLocus
      
      #############
      # Triallele #
      #############
      segTableThisLocus <- matrix(0,6,3)
      colnames(segTableThisLocus) <- c("aabc","abbc","abcc")
      rownames(segTableThisLocus) <- c("aa", "ab", "ac", "bc", "bb", "cc")
      possibleGenos <- colnames(segTableThisLocus)   
      for (thisGenoNum in 1:length(possibleGenos)) {
        # thisGenoNum <- 1
        thisGeno <- possibleGenos[thisGenoNum]
        thisGeno <- as.vector(unlist((strsplit(thisGeno,""))))
        thisTable <- t(as.matrix(sort(table(thisGeno),decreasing=TRUE)))
        gametes <- c("A1xA1","A1xA2","A1xA3","A2xA3","A2xA2","A3xA3")
        # Segregation probabilities
        theseFreq <- c(((1/6)+(DRR/3)),((1/3)-((DRR)/3)),((1/3)-((DRR)/3)),((1/6)-(DRR/6)),(DRR/4),(DRR/4))
        gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
        gametes <- gsub("A2", colnames(thisTable)[2], gametes)
        gametes <- gsub("A3", colnames(thisTable)[3], gametes)
        gametes <- gsub("x", "", gametes)
            
        for (thisGameteNum in 1:length(gametes)) {
            # thisGameteNum <- 1
            thisGamete <- gametes[thisGameteNum]
            gametes[thisGameteNum] <- paste(sort(unlist(strsplit(thisGamete,""))),collapse="")
        }
        names(theseFreq) <- gametes
        for (thisGamete in names(theseFreq)) {
          # thisGamete <- names(theseFreq[1])
          segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector(theseFreq[thisGamete])           
        }
      }
      # Average segregation ratios for phenotype markers
      segTableThisLocus <- cbind(segTableThisLocus, matrix(apply(segTableThisLocus,1,mean),6,1))
      colnames(segTableThisLocus)[4] <- "Pheno"  
      # Send to list
      SegTableList[[thisLocus]][["Triallele"]] <- segTableThisLocus
      
      ################
      # Quadriallele #
      ################
      segTableThisLocus <- matrix(0,10,1)
      colnames(segTableThisLocus) <- c("abcd")
      rownames(segTableThisLocus) <- c("aa", "ab", "ac", "ad", "bc", "bd", "bb", "cc", "cd", "dd")
      possibleGenos <- colnames(segTableThisLocus)
      thisGeno <- colnames(segTableThisLocus)
      thisGeno <- as.vector(unlist((strsplit(thisGeno,""))))
      thisTable <- t(as.matrix(sort(table(thisGeno),decreasing=TRUE)))
      gametes <- c("A1xA1","A1xA2","A1xA3","A1xA4","A2xA3","A2xA4","A2xA2","A3xA3","A3xA4","A4xA4")
      # Segregation probabilities
      theseFreq <- c((DRR/4),((1/6)-(DRR/6)),((1/6)-(DRR/6)),((1/6)-(DRR/6)),((1/6)-(DRR/6)),((1/6)-(DRR/6)),(DRR/4),(DRR/4),
                    ((1/6)-(DRR/6)),(DRR/4))
      gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
      gametes <- gsub("A2", colnames(thisTable)[2], gametes)
      gametes <- gsub("A3", colnames(thisTable)[3], gametes)
      gametes <- gsub("A4", colnames(thisTable)[4], gametes)
      gametes <- gsub("x", "", gametes)
      segTableThisLocus[,1] <- as.vector(theseFreq)           
      # Send to list
      SegTableList[[thisLocus]][["Quadriallele"]] <- segTableThisLocus
   } # end locus loop
  } # if ploidy = 4    
 
    # DRRtable <- DRRtable5
    # ploidy <- 6
    # DRR    
    

  # Hexaploid     
 if (ploidy == 6) {
   SegTableList <- list()
    for (thisLocus in 1:nrow(DRRtable)) {
      # thisLocus <- 1
      DRR <- DRRtable[thisLocus,1]
      SegTableList[[thisLocus]] <- list()
      SegTableList[[thisLocus]][["Monoallele"]] <- list()
      SegTableList[[thisLocus]][["Biallele"]] <- list()
      SegTableList[[thisLocus]][["Triallele"]] <- list()
      SegTableList[[thisLocus]][["Quadriallele"]] <- list()
      SegTableList[[thisLocus]][["Pentallele"]] <- list()
      SegTableList[[thisLocus]][["Hexallele"]] <- list()
           
      ##############
      # Monoallele #
      ##############
      segTableThisLocus <- matrix(0,1,1)
      colnames(segTableThisLocus) <- "aaaaaa"
      rownames(segTableThisLocus) <- "aaa"
      segTableThisLocus[1,1] <- 1
      SegTableList[[thisLocus]][["Monoallele"]] <- segTableThisLocus 
      
      ############
      # Biallele #
      ############
      segTableThisLocus <- matrix(0,4,5)
      colnames(segTableThisLocus) <- c("aaaaab","abbbbb","aaaabb","aabbbb","aaabbb")
      rownames(segTableThisLocus) <- c("aaa","aab","abb","bbb")
      possibleGenos <- colnames(segTableThisLocus)
      
      ##########################################################
      # Biallele type I (simplex), if max no. of allele is 5
      for (thisGenoNum in 1:5) {
        # thisGenoNum <- 1
        thisGeno <- possibleGenos[thisGenoNum]
        thisGeno <- as.vector(unlist((strsplit(thisGeno,""))))
        thisTable <- t(as.matrix(sort(table(thisGeno),decreasing=TRUE)))
        
        if (max(thisTable) == 5) { 
            gametes <- c("A1xA1xA1","A1xA1xA2","A1xA2xA2","A2xA2xA2")
            # Segregation probabilities
            theseFreq <- c(((3+DRR)/6),((3-(2*DRR))/6),(DRR/6),0)
            gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
            gametes <- gsub("A2", colnames(thisTable)[2], gametes)
            gametes <- gsub("x", "", gametes)
            names(theseFreq) <- gametes
            for (thisGameteNum in 1:length(gametes)) {
              # thisGameteNum <- 1
              thisGamete <- gametes[thisGameteNum]
              gametes[thisGameteNum] <- paste(sort(unlist(strsplit(thisGamete,""))),collapse="")
            }
            names(theseFreq) <- gametes
            for (thisGamete in names(theseFreq)) {
                # thisGamete <- names(theseFreq[1])
              segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector((theseFreq)[thisGamete])           
            }    
        } # if max = 5
        ##########################################################
        # Biallele type II (duplex), if max no. of allele is 4
        if (max(thisTable) == 4) {
            gametes <- c("A1xA1xA1","A1xA1xA2","A1xA2xA2","A2xA2xA2")
            # Segregation probabilities
            theseFreq <- c(((3+(3*DRR))/15),((9-(5*DRR))/15),((3+DRR)/15),(DRR/15))
            gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
            gametes <- gsub("A2", colnames(thisTable)[2], gametes)
            gametes <- gsub("x", "", gametes)
            names(theseFreq) <- gametes
            for (thisGameteNum in 1:length(gametes)) {
              # thisGameteNum <- 1
              thisGamete <- gametes[thisGameteNum]
              gametes[thisGameteNum] <- paste(sort(unlist(strsplit(thisGamete,""))),collapse="")
            }
            names(theseFreq) <- gametes
            for (thisGamete in names(theseFreq)) {
                # thisGamete <- names(theseFreq[1])
              segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector((theseFreq)[thisGamete])           
            }    
        } # if max = 4
        
        ##########################################################
        # Biallele type III (triplex), if max no. of allele is 3
        if (max(thisTable) == 3) {
            gametes <- c("A1xA1xA1","A1xA1xA2","A1xA2xA2","A2xA2xA2")
            # Segregation probabilities
            theseFreq <- c(((1+(3*DRR))/20),((9-(3*DRR))/20),((9-(3*DRR))/20),((1+(3*DRR))/20))
            gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
            gametes <- gsub("A2", colnames(thisTable)[2], gametes)
            gametes <- gsub("x", "", gametes)
            names(theseFreq) <- gametes
            for (thisGameteNum in 1:length(gametes)) {
              # thisGameteNum <- 1
              thisGamete <- gametes[thisGameteNum]
              gametes[thisGameteNum] <- paste(sort(unlist(strsplit(thisGamete,""))),collapse="")
            }
            names(theseFreq) <- gametes
            for (thisGamete in names(theseFreq)) {
                # thisGamete <- names(theseFreq[1])
              segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector((theseFreq)[thisGamete])           
            }    
        } # if max = 3
      } # End loop over bialleles
      # Average segregation ratios for phenotype markers
      segTableThisLocus <- cbind(segTableThisLocus, matrix(apply(segTableThisLocus,1,mean),4,1))
      colnames(segTableThisLocus)[6] <- "Pheno"  
      # Send to list
      SegTableList[[thisLocus]][["Biallele"]] <- segTableThisLocus
    
      #############
      # Triallele #
      #############
      segTableThisLocus <- matrix(0,10,10)
      colnames(segTableThisLocus) <- c("aaaabc","abbbbc","abcccc","aaabbc","aabbbc","abbccc","aaabcc","abbbcc","aabccc","aabbcc")
      rownames(segTableThisLocus) <- c("aaa", "aab", "aac", "bbb", "abb", "bbc", "ccc", "acc", "bcc", "abc")
      possibleGenos <- colnames(segTableThisLocus)
      
      for (thisGenoNum in 1:10) {
        # thisGenoNum <- 10
        thisGeno <- possibleGenos[thisGenoNum]
        thisGeno <- as.vector(unlist((strsplit(thisGeno,""))))
        thisTable <- t(as.matrix(sort(table(thisGeno),decreasing=TRUE))) 
      
      #########################################################
      # Triallele type I (simplex), if max no. of allele is 4
      if (max(thisTable) == 4) { 
            gametes <- c("A1xA1xA1","A1xA1xA2","A1xA1xA3","A2xA2xA2","A1xA2xA2","A2xA2xA3","A3xA3xA3","A1xA3xA3",
                         "A2xA3xA3","A1xA2xA3")
            # Segregation probabilities
            theseFreq <- c(((6+(6*DRR))/30),((9-(5*DRR))/30),((9-(5*DRR))/30),0,((4*DRR)/30),(DRR/30),0,((4*DRR)/30),
                           (DRR/30),((6-(6*DRR))/30))
            gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
            gametes <- gsub("A2", colnames(thisTable)[2], gametes)
            gametes <- gsub("A3", colnames(thisTable)[3], gametes)
            gametes <- gsub("x", "", gametes)
            names(theseFreq) <- gametes
            for (thisGameteNum in 1:length(gametes)) {
              # thisGameteNum <- 1
              thisGamete <- gametes[thisGameteNum]
              gametes[thisGameteNum] <- paste(sort(unlist(strsplit(thisGamete,""))),collapse="")
            }
            names(theseFreq) <- gametes
            for (thisGamete in names(theseFreq)) {
                # thisGamete <- names(theseFreq[1])
              segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector((theseFreq)[thisGamete])           
            }    
        } # if max = 4  
        
        #########################################################
        # Triallele type II (duplex), if max no. of allele is 3
        if (max(thisTable) == 3) { 
            gametes <- c("A1xA1xA1","A1xA1xA2","A1xA1xA3","A2xA2xA2","A1xA2xA2","A2xA2xA3","A3xA3xA3","A1xA3xA3",
                         "A2xA3xA3","A1xA2xA3")
            # Segregation probabilities
            theseFreq <- c(((3+(9*DRR))/60),((18-(6*DRR))/60),((9-(3*DRR))/60),((4*DRR)/60),((9+(3*DRR))/60),
                           ((3+DRR)/60),0,((6*DRR)/60),((4*DRR)/60),((18-(18*DRR))/60))
            gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
            gametes <- gsub("A2", colnames(thisTable)[2], gametes)
            gametes <- gsub("A3", colnames(thisTable)[3], gametes)
            gametes <- gsub("x", "", gametes)
            names(theseFreq) <- gametes
            for (thisGameteNum in 1:length(gametes)) {
              # thisGameteNum <- 1
              thisGamete <- gametes[thisGameteNum]
              gametes[thisGameteNum] <- paste(sort(unlist(strsplit(thisGamete,""))),collapse="")
            }
            names(theseFreq) <- gametes
            for (thisGamete in names(theseFreq)) {
                # thisGamete <- names(theseFreq[1])
              segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector((theseFreq)[thisGamete])           
            }    
        } # if max = 3  
        ############################################################
        # Triallele type III (triplex), if max no. of alleles is 2
        if (max(thisTable) == 2) { 
            gametes <- c("A1xA1xA1","A1xA1xA2","A1xA1xA3","A2xA2xA2","A1xA2xA2","A2xA2xA3","A3xA3xA3","A1xA3xA3",
                         "A2xA3xA3","A1xA2xA3")
            # Segregation probabilities
            theseFreq <- c(((4*DRR)/60),((6+(2*DRR))/60),((6+(2*DRR))/60),((4*DRR)/60),((6+(2*DRR))/60),
                             ((6+(2*DRR))/60),((4*DRR)/60),((6+(2*DRR))/60),((6+(2*DRR))/60),((24-(24*DRR))/60))
            gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
            gametes <- gsub("A2", colnames(thisTable)[2], gametes)
            gametes <- gsub("A3", colnames(thisTable)[3], gametes)
            gametes <- gsub("x", "", gametes)
            names(theseFreq) <- gametes
            for (thisGameteNum in 1:length(gametes)) {
              # thisGameteNum <- 1
              thisGamete <- gametes[thisGameteNum]
              gametes[thisGameteNum] <- paste(sort(unlist(strsplit(thisGamete,""))),collapse="")
            }
            names(theseFreq) <- gametes
            for (thisGamete in names(theseFreq)) {
                # thisGamete <- names(theseFreq[1])
              segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector((theseFreq)[thisGamete])           
            }    
        } # if max = 2  
      } # end triallele 
      # Average segregation ratios for phenotype markers
      segTableThisLocus <- cbind(segTableThisLocus, matrix(apply(segTableThisLocus,1,mean),10,1))
      colnames(segTableThisLocus)[11] <- "Pheno"  
      # Send to list
      SegTableList[[thisLocus]][["Triallele"]] <- segTableThisLocus
      
      ################
      # Quadriallele #
      ################
      segTableThisLocus <- matrix(0,20,10)
      colnames(segTableThisLocus) <- c("aaabcd","abbbcd","abcccd","abcddd","aabbcd","aabccd","aabcdd","abbccd","abbcdd","abccdd")
      rownames(segTableThisLocus) <- c("aaa", "aab", "aac", "aad", "bbb", "abb", "bbc", "bbd","ccc", "acc",
                                    "bcc", "ccd", "add", "bdd", "cdd","ddd", "abc", "abd", "acd", "bcd")
      possibleGenos <- colnames(segTableThisLocus)
      
      for (thisGenoNum in 1:10) {
        # thisGenoNum <- 7
        thisGeno <- possibleGenos[thisGenoNum]
        thisGeno <- as.vector(unlist((strsplit(thisGeno,""))))
        thisTable <- t(as.matrix(sort(table(thisGeno),decreasing=TRUE))) 
      
      #########################################################
      # Quadriallele type I (simplex), if max no. of allele is 3
        if (max(thisTable) == 3) {
            gametes <- c("A1xA1xA1","A1xA1xA2","A1xA1xA3","A1xA1xA4","A2xA2xA2","A1xA2xA2","A2xA2xA3","A2xA2xA4","A3xA3xA3","A1xA3xA3",
                   "A2xA3xA3","A3xA3xA4","A1xA4xA4","A2xA4xA4","A3xA4xA4","A4xA4xA4","A1xA2xA3","A1xA2xA4","A1xA3xA4","A2xA3xA4")
            # Segregation probabilities
            theseFreq <- c(((3+(9*DRR))/60), ((9-(3*DRR))/60), ((9-(3*DRR))/60), ((9-(3*DRR))/60),0,
                          ((6*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),0,((6*DRR)/60), ((2*DRR)/60),
                          ((2*DRR)/60), ((6*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),0,((9-(9*DRR))/60),
                          ((9-(9*DRR))/60), ((9-(9*DRR))/60), ((3-(3*DRR))/60))
            gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
            gametes <- gsub("A2", colnames(thisTable)[2], gametes)
            gametes <- gsub("A3", colnames(thisTable)[3], gametes)
            gametes <- gsub("A4", colnames(thisTable)[4], gametes)
            gametes <- gsub("x", "", gametes)
            names(theseFreq) <- gametes
            for (thisGameteNum in 1:length(gametes)) {
              # thisGameteNum <- 1
              thisGamete <- gametes[thisGameteNum]
              gametes[thisGameteNum] <- paste(sort(unlist(strsplit(thisGamete,""))),collapse="")
            }
            names(theseFreq) <- gametes
            for (thisGamete in names(theseFreq)) {
                # thisGamete <- names(theseFreq[1])
              segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector((theseFreq)[thisGamete])           
            }    
        } # if max = 3
       #############################################################
       # Quadriallele type II (simplex), if max no. of allele is 2
      if (max(thisTable) == 2) {
            gametes <- c("A1xA1xA1","A1xA1xA2","A1xA1xA3","A1xA1xA4","A2xA2xA2","A1xA2xA2","A2xA2xA3","A2xA2xA4","A3xA3xA3","A1xA3xA3",
                   "A2xA3xA3","A3xA3xA4","A1xA4xA4","A2xA4xA4","A3xA4xA4","A4xA4xA4","A1xA2xA3","A1xA2xA4","A1xA3xA4","A2xA3xA4")
            # Segregation probabilities
            theseFreq <- c(((4*DRR)/60), ((6+(2*DRR))/60), ((3+DRR)/60), ((3+DRR)/60), ((4*DRR)/60), ((6+(2*DRR))/60),
                          ((3+DRR)/60), ((3+DRR)/60), 0,((4*DRR)/60), ((4*DRR)/60), ((2*DRR)/60), ((4*DRR)/60), ((4*DRR)/60),
                          ((2*DRR)/60),0 ,((12-(12*DRR))/60), ((12-(12*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60))
            gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
            gametes <- gsub("A2", colnames(thisTable)[2], gametes)
            gametes <- gsub("A3", colnames(thisTable)[3], gametes)
            gametes <- gsub("A4", colnames(thisTable)[4], gametes)
            gametes <- gsub("x", "", gametes)
            names(theseFreq) <- gametes
            for (thisGameteNum in 1:length(gametes)) {
              # thisGameteNum <- 1
              thisGamete <- gametes[thisGameteNum]
              gametes[thisGameteNum] <- paste(sort(unlist(strsplit(thisGamete,""))),collapse="")
            }
            names(theseFreq) <- gametes
            for (thisGamete in names(theseFreq)) {
                # thisGamete <- names(theseFreq[1])
              segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector((theseFreq)[thisGamete])           
            }    
        } # if max = 2
      }    
      # Average segregation ratios for phenotype markers
      segTableThisLocus <- cbind(segTableThisLocus, matrix(apply(segTableThisLocus,1,mean),20,1))
      colnames(segTableThisLocus)[11] <- "Pheno"  
      # Send to list
      SegTableList[[thisLocus]][["Quadriallele"]] <- segTableThisLocus
      
      ################
      # Pentallele   #
      ################
      segTableThisLocus <- matrix(0,35,5)
      colnames(segTableThisLocus) <- c("aabcde","abbcde","abccde","abcdde","abcdee")
      rownames(segTableThisLocus) <- c("aaa","aab","aac","aad","aae","bbb","abb",
                                       "bbc","bbd", "bbe","ccc","acc","bcc","ccd",
                                       "cce","ddd","add","bdd","cdd","dde","eee",
                                       "aee","bee","cee","dee","abc","abd","abe",
                                       "acd","ace","ade","bcd","bce","bde",
                                       "cde")
      possibleGenos <- colnames(segTableThisLocus)
      
      for (thisGenoNum in 1:5) {
        # thisGenoNum <- 2
        thisGeno <- possibleGenos[thisGenoNum]
        thisGeno <- as.vector(unlist((strsplit(thisGeno,""))))
        thisTable <- t(as.matrix(sort(table(thisGeno),decreasing=TRUE))) 
      
        gametes <- c("A1xA1xA1","A1xA1xA2","A1xA1xA3","A1xA1xA4","A1xA1xA5","A2xA2xA2",
                     "A1xA2xA2","A2xA2xA3","A2xA2xA4","A2xA2xA5","A3xA3xA3","A1xA3xA3","A2xA3xA3","A3xA3xA4",
                     "A3xA3xA5","A4xA4xA4","A1xA4xA4","A2xA4xA4","A3xA4xA4","A4xA4xA5","A5xA5xA5",
                     "A1xA5xA5","A2xA5xA5","A3xA5xA5","A4xA5xA5","A1xA2xA3","A1xA2xA4","A1xA2xA5",
                     "A1xA3xA4","A1xA3xA5","A1xA4xA5","A2xA3xA4","A2xA3xA5","A2xA4xA5",
                     "A3xA4xA5")
        # Segregation probabilities
        theseFreq <- c(((4*DRR)/60), ((3+DRR)/60), ((3+DRR)/60), ((3+DRR)/60), ((3+DRR)/60), 0, ((4*DRR)/60), ((2*DRR)/60),
                      ((2*DRR)/60), ((2*DRR)/60), 0, ((4*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), 0, ((4*DRR)/60),
                      ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), 0, ((4*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
                      ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60), ((6-(6*DRR))/60),
                      ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60))  
        
        gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
        gametes <- gsub("A2", colnames(thisTable)[2], gametes)
        gametes <- gsub("A3", colnames(thisTable)[3], gametes)
        gametes <- gsub("A4", colnames(thisTable)[4], gametes)
        gametes <- gsub("A5", colnames(thisTable)[5], gametes)
        gametes <- gsub("x", "", gametes)
        names(theseFreq) <- gametes
        for (thisGameteNum in 1:length(gametes)) {
          # thisGameteNum <- 1
          thisGamete <- gametes[thisGameteNum]
          gametes[thisGameteNum] <- paste(sort(unlist(strsplit(thisGamete,""))),collapse="")
        }
        names(theseFreq) <- gametes
        for (thisGamete in names(theseFreq)) {
          # thisGamete <- names(theseFreq[1])
          segTableThisLocus[thisGamete,possibleGenos[thisGenoNum]] <- as.vector((theseFreq)[thisGamete])           
        }
      } # end loop over genotypes
      
        # Average segregation ratios for phenotype markers
        segTableThisLocus <- cbind(segTableThisLocus, matrix(apply(segTableThisLocus,1,mean),35,1))
        colnames(segTableThisLocus)[6] <- "Pheno"  
        # Send to list
        SegTableList[[thisLocus]][["Pentallele"]] <- segTableThisLocus 
        
      ################
      # Hexallele    #
      ################
      segTableThisLocus <- matrix(0,50,1)
      colnames(segTableThisLocus) <- c("abcdef")
      rownames(segTableThisLocus) <- c("aab", "aac", "aad", "aae", "aaf", "abb", "bbc",
                                       "bbd", "bbe", "bbf", "acc", "bcc", "ccd", "cce",
                                       "ccf", "add", "bdd", "cdd", "dde", "ddf", "aee",
                                       "bee", "cee", "dee", "eef", "aff", "bff", "cff",
                                       "dff", "eff", "abc", "abd", "abe", "abf", "acd",
                                       "ace", "acf", "ade", "adf", "aef", "bcd", "bce",
                                       "bcf", "bde", "bdf", "bef", "cde", "cdf", "cef",
                                       "def")
      possibleGenos <- colnames(segTableThisLocus)
      thisGeno <- colnames(segTableThisLocus)
      thisGeno <- as.vector(unlist((strsplit(thisGeno,""))))
      thisTable <- t(as.matrix(sort(table(thisGeno),decreasing=TRUE)))
      gametes <- c("A1xA1xA2", "A1xA1xA3", "A1xA1xA4", "A1xA1xA5", "A1xA1xA6", "A1xA2xA2", "A2xA2xA3",
                   "A2xA2xA4", "A2xA2xA5", "A2xA2xA6", "A1xA3xA3", "A2xA3xA3", "A3xA3xA4", "A3xA3xA5",
                   "A3xA3xA6", "A1xA4xA4", "A2xA4xA4", "A3xA4xA4", "A4xA4xA5", "A4xA4xA6", "A1xA5xA5",
                   "A2xA5xA5", "A3xA5xA5", "A4xA5xA5", "A5xA5xA6", "A1xA6xA6", "A2xA6xA6", "A3xA6xA6",
                   "A4xA6xA6", "A5xA6xA6", "A1xA2xA3", "A1xA2xA4", "A1xA2xA5", "A1xA2xA6", "A1xA3xA4",
                   "A1xA3xA5", "A1xA3xA6", "A1xA4xA5", "A1xA4xA6", "A1xA5xA6", "A2xA3xA4", "A2xA3xA5",
                   "A2xA3xA6", "A2xA4xA5", "A2xA4xA6", "A2xA5xA6", "A3xA4xA5", "A3xA4xA6", "A3xA5xA6",
                   "A4xA5xA6")
      # Segregation probabilities
      theseFreq <- c(((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
                  ((2*DRR)/60), ((2*DRR)/60),((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
                  ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),
                  ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60), ((2*DRR)/60),((3-(3*DRR))/60), ((3-(3*DRR))/60),
                  ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60),
                  ((3-(3*DRR))/60), ((3-(3*DRR))/60),((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60),
                  ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60), ((3-(3*DRR))/60))
      gametes <- gsub("A1", colnames(thisTable)[1], gametes) 
      gametes <- gsub("A2", colnames(thisTable)[2], gametes)
      gametes <- gsub("A3", colnames(thisTable)[3], gametes)
      gametes <- gsub("A4", colnames(thisTable)[4], gametes)
      gametes <- gsub("A5", colnames(thisTable)[5], gametes)
      gametes <- gsub("A6", colnames(thisTable)[6], gametes)
      gametes <- gsub("x", "", gametes)
      segTableThisLocus[,1] <- as.vector(theseFreq)           
      # Send to list
      SegTableList[[thisLocus]][["Hexallele"]] <- segTableThisLocus
    } # end locus loop 
   # Send to list
   #SegTableList[[thisLocus]][["Pentallele"]] <- segTableThisLocus 
  } # if ploidy = 6    
  
 return(SegTableList) 
} # end function     
      
      
      
 










