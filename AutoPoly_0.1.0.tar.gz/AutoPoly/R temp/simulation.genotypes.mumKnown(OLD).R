#' routine for generating simulated genotypes (mother known)
#'
#' @export
simulateMotherKnown <- function(inData, alleleFrequenciesTable,
                                gameteFrequenciesTable, ploidy, marker,
                                simMissLoci, selfing, errorRate,
                                numAdults, numRef, numMothers, numOffspring) {

  # Initial setup of functions depending on ploidy
  cat("\n         Simulating Genotypes....")
  flush.console()
  #############################################
  # a) Directing required hexaploid functions #
  #############################################
  #if (ploidy==6){
  #    getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
  #    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
  #    getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
  #    gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
  #    if (marker == "genotype") {
  #        if (DRR == "min") {
  #            getMotherGameteInfo <- getMotherGameteInfoHexGenoMin # segregation ratios: gametes from individual
  #        } else if (DRR == "max") {
  #            getMotherGameteInfo <- getMotherGameteInfoHexGenoMax # segregation ratios: gametes from individual
  #        }
  #    }
  #    if (marker == "phenotype") {
  #        if (DRR == "min") {
  #            getMotherGameteInfo <- getMotherGameteInfoHexPhenoMin # segregation ratios: gametes from individual
  #        } else if (DRR == "max") {
  #            getMotherGameteInfo <- getMotherGameteInfoHexPhenoMax # segregation ratios: gametes from individual
  #        }
  #    }
  #}
  ################################################
  # b) Directing required tetraploid functions   #
  ################################################

  #if (ploidy==4) {
  #    getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
  #    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
  #    getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
  #    gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
  #    if (marker == "genotype") {
  #        if (DRR == "min") {
  #            getMotherGameteInfo <- getMotherGameteInfoTetrGenoMin # segregation ratios: gametes from individual
  #        } else if (DRR == "max") {
  #            getMotherGameteInfo <- getMotherGameteInfoTetrGenoMax # segregation ratios: gametes from individual
  #        }
  #    }
  #    if (marker == "phenotype") {
  #        if (DRR == "min") {
  #            getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMin # segregation ratios: gametes from individual
  #        } else if (DRR == "max") {
  #            getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMax # segregation ratios: gametes from individual
  #        }
  #    }
  #}


  # New version
  #############################################
  # a) Directing required hexaploid functions #
  #############################################
  if (ploidy==6) {
    getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
  }
  ################################################
  # b) Directing required tetraploid functions   #
  ################################################

  if (ploidy==4) {
    getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
  }


  #############################
  # Initial setup             #
  # -population information   #
  # -data output structures   #
  #############################
  strip.NAs <- function(vv) {
    return(vv[!is.na(vv)])
  }
  if (ploidy == 6) {
    MAXSEEDLINGGENOTYPES <- 10
  } else if (ploidy == 4) {
    MAXSEEDLINGGENOTYPES <- 3
  }

  ##################################
  #  Setup objects to receive data #
  ##################################
  allPopns <- unique(inData$pop)
  numPopns <- length(allPopns)
  allMothers <- with(inData,unique(strip.NAs(mother)))
  allSeedlings <- with(inData,unique(ID[!is.na(mother)]))
  popnsWithMothers <- unique(with(inData,pop[ID %in% allMothers]))

  ##Strip out the seedlings, leaving adults and mothers:
  inDataAdults <- subset(inData,subset=is.na(mother))
  numAdults<-nrow(inDataAdults)

  ## Add additional column to inDataAdults
  newOne<-matrix(0,nrow(inDataAdults),1)
  colnames(newOne)<- "ActualCross"
  inDataAdults<-cbind(inDataAdults,newOne)

  ## Matrix for simulated progeny
  simCrosses<-matrix(0,numOffspring,ncol(inDataAdults))
  colnames(simCrosses)<- colnames(inDataAdults)

  ## Number of simulations
  numMothers<- length(allMothers)
  numSimsPerMum<- as.integer(numOffspring/length(allMothers))
  numSimsPerMumOutcrossed<-as.integer(numSimsPerMum*(1-selfing))
  numSimsPerMumSelfed<- numSimsPerMum - numSimsPerMumOutcrossed

  # Sets the start of ID labels for simulated progeny from current mother
  flag<-0

  ################################
  ## Begin loop over mothers    ##
  ################################
  for (thisMother in allMothers) {
    #test zone thisMother<-"GF14"

    #################################
    # Sampling of selfed genotypes  #
    #################################
    # simulated progeny ID labels for selfed individuals
    SimProgeny<- flag + (1:(numSimsPerMumSelfed))

    ##########################
    ## Begin loop over loci ##
    ##########################
    for (thisLocus in 1:numLoci) {
      #testing zone thisLocus<-1
      # Current locus column range
      locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
      #################################
      # Sampling of selfed genotypes  #
      #################################
      # First gamete from mother
      motherGenotype <- inData[inData$ID==thisMother,locusRange]
      statusMum1<-!is.na(motherGenotype)
      # if mother has no alleles
      if (all(statusMum1==FALSE)) {
        # send a 0 for current mum
        thisMother.sample<-sample(paste(rep("NA",ploidy),collapse=" "),numSimsPerMumSelfed,replace=TRUE)
        newProgeny<-t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy,))
      }
      # Otherwise mother does have phenotype information and proceed
      if (any(statusMum1==TRUE)) {
        motherGenotype<-as.vector(strip.NAs(motherGenotype))
        motherGametes <-getMotherGameteInfo(motherGenotype)
        thisMother.Gametes<- as.vector(names(motherGametes$prob))
        thisMother.Probs<- as.vector(motherGametes$prob)
        thisMother.sample<- sample(thisMother.Gametes,numSimsPerMumSelfed,replace=TRUE,thisMother.Probs)
        thisMother.sample<- t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy/2,))
        # Second gamete from mother
        thisSelfedFather.sample<- sample(thisMother.Gametes,numSimsPerMumSelfed,replace=TRUE,thisMother.Probs)
        thisSelfedFather.sample<- t(matrix(unlist(strsplit(thisSelfedFather.sample," ")),ploidy/2,))
        newProgeny<-cbind(thisMother.sample,thisSelfedFather.sample)
      }
      # send to dataframe
      simCrosses[SimProgeny,locusRange]<- newProgeny
      simCrosses[SimProgeny,"pop"]<- inData[thisMother,"pop"]
      simCrosses[SimProgeny,"mother"]<- thisMother
      simCrosses[SimProgeny,"ID"]<- paste(SimProgeny,"s",sep="")
      simCrosses[SimProgeny,"ActualCross"]<-inData[thisMother,"pop"]
      # clear out
      newProgeny<-NULL
      thisMother.sample<-NULL
      thisSelfedFather.sample<-NULL
    }

    #####################################
    # Sampling of outcrossed genotypes  #
    #####################################
    # Increase flag for outcrossed progeny
    flag<-max(SimProgeny)
    # simulated progeny ID labels for outcrossed progeny
    SimProgeny<- flag + (1:(numSimsPerMumOutcrossed))

    ########################################
    # random locations of father gametes   #
    ########################################
    randomPopns<-sample(allPopns,numSimsPerMumOutcrossed,replace=TRUE)
    thisPopninTotal.sample<-NULL

    ##########################
    ## Begin loop over loci ##
    ##########################
    for (thisLocus in 1:numLoci) {
      #testing zone thisLocus<-1
      ##current locus
      locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy

      ##########################################
      # Sampling gametes from current mother  ##
      ##########################################
      # First gamete from mother
      motherGenotype <- inData[inData$ID==thisMother,locusRange]
      statusMum1<-!is.na(motherGenotype)
      # if mother has no alleles
      if (all(statusMum1==FALSE)) {
        # send a 0 for current mum
        thisMother.sample<-sample(paste(rep("NA",ploidy/2),collapse=" "),numSimsPerMumOutcrossed,replace=TRUE)
        thisMother.sample<-t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy/2,))
      }
      # Otherwise mother does have phenotype information and proceed
      if (any(statusMum1==TRUE)) {
        motherGenotype<-as.vector(strip.NAs(motherGenotype))
        motherGametes <-getMotherGameteInfo(motherGenotype)
        thisMother.Gametes<- as.vector(names(motherGametes$prob))
        thisMother.Probs<- as.vector(motherGametes$prob)
        thisMother.sample<- sample(thisMother.Gametes,numSimsPerMumOutcrossed,replace=TRUE,thisMother.Probs)
        thisMother.sample<- t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy/2,))
      }

      #########################################
      ## Begin loop over father locations    ##
      #########################################
      for (thisRandomPop in randomPopns) {
        # test thisRandomPop<-"GF"
        ######################################################################
        # Sampling of gametes from current father location in thisPopinTotal #
        ######################################################################
        thisPopninTotal.Gametes<- as.vector(colnames(gameteFrequenciesTable[[thisRandomPop]][[thisLocus]]))
        thisPopninTotal.Probs<- as.vector(gameteFrequenciesTable[[thisRandomPop]][[thisLocus]])
        thisPopninTotal.sample<-c(thisPopninTotal.sample,sample(thisPopninTotal.Gametes,1,replace=TRUE,thisPopninTotal.Probs))
      }
      thisPopninTotal.sample<- t(matrix(unlist(strsplit(thisPopninTotal.sample," ")),ploidy/2,))
      # Combine sampled gametes
      newProgeny<-cbind(thisMother.sample,thisPopninTotal.sample)
      # Remove new progeny with missing information for one gamete
      for (thisRow in 1:nrow(newProgeny)) {
        if (any(is.na(newProgeny[thisRow,]))) {
          newProgeny[thisRow,]<-NA
        }
      }
      # send to dataframe
      simCrosses[SimProgeny,locusRange]<- newProgeny
      simCrosses[SimProgeny,"pop"]<- inData[thisMother,"pop"]
      simCrosses[SimProgeny,"mother"]<- thisMother
      simCrosses[SimProgeny,"ID"]<- paste(SimProgeny,"s",sep="")
      simCrosses[SimProgeny,"ActualCross"]<-randomPopns
      #simCrosses[SimProgeny,"ActualCross"]<-paste(thisMother,randomPopns,sep=" ")
      # clearing out
      thisPopninTotal.sample<-NULL
      newProgeny<-NULL
      thisMother.sample<-NULL
    } #end locus loop
    # clear out randomly selected populations
    randomPopns<-NULL
    # Increase flag ready for selfed seedlings from next population
    flag<-max(SimProgeny)
  } #end mother loop
  these<-simCrosses[,1]!=0
  simCrosses<-simCrosses[these,]
  simCrosses<-as.data.frame(simCrosses)
  rownames(simCrosses)<-simCrosses$ID
  # Error rate, removing loci according to simMissLoci and replace with NA
  for (thisLocus in 1:numLoci) {
    #testing zone thisLocus<-1
    ##current locus
    locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
    randomNums<-runif(nrow(simCrosses),0,1)
    change<-randomNums<=simMissLoci
    simCrosses[change,locusRange]<-rep(NA,ploidy)
  }
  # combine simulated individuals with real adults
  inDataSimData<-rbind(inDataAdults, simCrosses)
  inDataSimData[1:numAdults,"ActualCross"]<-NA
  cat("COMPLETE \n")
  return(inDataSimData)
}

inData, alleleFrequenciesTable, gameteFrequenciesTable1,
ploidy, marker, simMissLoci, selfing, errorRate,
numAdultsSim,numMothersSim,numOffspringSim,fixMothersSim, immRateSim
