##################################
#                                #
#  Possible genotypes for a      #
#     given phenotype            #
#      -Inidividual level        #
#      -Hexaploid & Tetraploid   #
#      Author: David Field       #
#         1/2/2010               #
################################## 

getSeedlingGenotypesHex <- function (phenotype) {
  ###############
  #  Hexaploid  #
  ###############
  ##Pheno is assumed sorted, and with no non-unique entries, and with
  ##no missing (NA) entries.
  switch(length(phenotype),
         {#Monoallele
           gCodes <- c("aaaaaa")},
         {## Biallele
           gCodes <- c("aaaaab", "aaaabb", "aaabbb", "aabbbb",
                       "abbbbb")},
         {## Triallele
           gCodes <- c("aaaabc", "aaabbc", "aaabcc", "aabbbc",
                       "aabbcc", "aabccc", "abbbbc", "abbbcc",
                       "abbccc", "abcccc")},
         {## Quadriallele
           gCodes <-c("aaabcd", "aabbcd", "aabccd", "aabcdd",
                      "abbbcd", "abbccd", "abbcdd", "abcccd",
                      "abccdd", "abcddd")},
         {## Pentallele
           gCodes <- c("aabcde", "abbcde", "abccde", "abcdde",
                       "abcdee")},
         {## Hexallele
           gCodes <- c("abcdef")})
  genotypes <- lapply(strsplit(gCodes,""),  
                      function (thisVec,phenotype)  {
                        y <- match(thisVec,c("a","b","c","d","e","f"))
                        ##return(paste(phenotype[y],collapse=" "))
                        return(phenotype[y])
                      },
                      phenotype
                      )
  names(genotypes) <- lapply(genotypes,
                             function(thisVec) {
                               paste(thisVec,collapse=" ")
                             })
  return(genotypes)  
}


getSeedlingGenotypesTetr <- function (phenotype) {
  ################
  #  Tetraploid  #
  ################
  ##Pheno is assumed sorted, and with no non-unique entries, and with
  ##no missing (NA) entries.
  switch(length(phenotype),
         {#Monoallele
           gCodes <- c("aaaa")
         },
         {## Biallele
           gCodes <- c("aaab","aabb","bbba")
         },
         {## Triallele
           gCodes <- c("aabc","bbac","ccab")
         },
         {## Quadriallele
           gCodes <- c("abcd")
         }
         )
  genotypes <- lapply(strsplit(gCodes,""),  
                      function (thisVec,phenotype)  {
                        y <- match(thisVec,c("a","b","c","d"))
                        ##return(paste(phenotype[y],collapse=" "))
                        return(phenotype[y])
                      },
                      phenotype
                      )
  names(genotypes) <- lapply(genotypes,
                             function(thisVec) {
                               paste(thisVec,collapse=" ")
                             })
  return(genotypes)  
}