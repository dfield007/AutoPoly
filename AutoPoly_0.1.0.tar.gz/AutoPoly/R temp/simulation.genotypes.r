#########################################
#                                       #
#        Simulations                    #
#       Two Separate functions          #
#        1. For mothers UNKNOWN         #
#        2. For mothers KNOWN           #
#                                       #
#          Author: David Field          #
#          Date: 1/2/2010               #
#                                       #
#########################################

simulate.mother.unknown<- function(inData, alleleFrequenciesTable,gameteFrequenciesTable, 
                                              ploidy, marker, simulations, simMissLoci, selfing) {

#########################
# Simulation genotypes  #
#    mother = UNKNOWN   #
#########################
cat("\n         Simulating Genotypes....")
# Initial setup of functions depending on ploidy
#cat("\n ** Beginning Simulations.... **\n")
flush.console()
  #############################################
  # a) Directing required hexaploid functions #
  #############################################
if (ploidy==6){
    getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
    if (marker == "genotype") {
        if (DRR == "min") {
            getMotherGameteInfo <- getMotherGameteInfoHexGenoMin # segregation ratios: gametes from individual
        } else if (DRR == "max") {
            getMotherGameteInfo <- getMotherGameteInfoHexGenoMax # segregation ratios: gametes from individual
        }
    }
    if (marker == "phenotype") {
        if (DRR == "min") {
            getMotherGameteInfo <- getMotherGameteInfoHexPhenoMin # segregation ratios: gametes from individual
        } else if (DRR == "max") {
            getMotherGameteInfo <- getMotherGameteInfoHexPhenoMax # segregation ratios: gametes from individual
        }
    }
}
  ################################################
  # b) Directing required tetraploid functions   #
  ################################################

if (ploidy==4) {
    getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
    if (marker == "genotype") {
        if (DRR == "min") {
            getMotherGameteInfo <- getMotherGameteInfoTetrGenoMin # segregation ratios: gametes from individual
        } else if (DRR == "max") {
            getMotherGameteInfo <- getMotherGameteInfoTetrGenoMax # segregation ratios: gametes from individual
        }
    }
    if (marker == "phenotype") {
        if (DRR == "min") {
            getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMin # segregation ratios: gametes from individual
        } else if (DRR == "max") {
            getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMax # segregation ratios: gametes from individual
        }
    }
}

  #############################
  # Initial setup             #
  # -population information   #
  # -data output structures   #
  #############################
  strip.NAs <- function(vv) {
      return(vv[!is.na(vv)])
  }
  if (ploidy == 6) {
      MAXSEEDLINGGENOTYPES <- 10
  } else if (ploidy == 4) {
      MAXSEEDLINGGENOTYPES <- 3
  }

  ##################################
  #  Setup objects to receive data #
  ##################################

  # possible F1 combinations
  # Required later in assignment test for part c) #
  allPopns <- unique(inData$pop)
  numPopns <- length(allPopns)
  PopsPaired <- matrix(0,numPopns,2)
  for (thisPair in 1:length(allPopns)) {
      # test thisPair<- 1
      Paired<- unlist(strsplit(rep(allPopns[thisPair],2)," "))
      PopsPaired[thisPair,1]<-Paired[1]
      PopsPaired[thisPair,2]<-Paired[2]
  }

  noPopCombinations<-(numPopns*(numPopns-1))/2
  popCombos<-combinations(numPopns,2,allPopns,repeats=FALSE)
  popComboMatrix<-matrix(0,1,noPopCombinations)
  for (thisCombo in 1:nrow(popCombos)) {
      #test thisCombo<-1
      Combo<- popCombos[thisCombo,]
      popComboMatrix[1,thisCombo]<-paste(Combo,collapse=" ")
      #unlist(strsplit(Combo," "))
  }
  allPopnsAllCombos<-c(allPopns,popComboMatrix[1,])
  allPopnsAllCombosMatrix<-rbind(PopsPaired, popCombos)

  ##Strip out the seedlings, leaving adults and mothers:
  inDataAdults <- subset(inData,subset=is.na(mother))
  numAdults<-nrow(inDataAdults)
  ## Add additional column to inDataAdults
  newOne<-matrix(0,nrow(inDataAdults),1)
  colnames(newOne)<- "ActualCross"
  inDataAdults<-cbind(inDataAdults,newOne)
    
  # number of simulations per popcombo  
  numSimsPerPop<- as.integer(simulations/nrow(allPopnsAllCombosMatrix))
  ## Matrix for simulated progeny
  simCrosses<-matrix(0,simulations,ncol(inDataAdults))
  colnames(simCrosses)<- colnames(inDataAdults)

  ## Number of simulations
  numSimsPerPop<- as.integer(simulations/length(allPopns))
  numSimsPerPopOutcrossed<-as.integer(numSimsPerPop*(1-selfing))
  numSimsPerPopSelfed<- numSimsPerPop - numSimsPerPopOutcrossed
  
  # Sets the start of ID labels for simulated progeny from current mother
  flag<-0
 
    #####################################################
    ## Begin loop over populations and combinations    ##
    #####################################################
    for (thisPopn in allPopns) {
        # test thisPopn<-"GA"
        
        #################################
        # Sampling of selfed genotypes  #
        #################################
          # simulated progeny ID labels for selfed individuals
          SimProgeny<- flag + (1:(numSimsPerPopSelfed))

          ##########################
          ## Begin loop over loci ##
          ##########################
          for (thisLocus in 1:numLoci) {
              #testing zone thisLocus<-1
              # Current locus column range
              locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
              # First gamete from home population
              # Weighted sampling of gametes from thisPopninCombo
              thisPopn.Gametes<- as.vector(colnames(gameteFrequenciesTable[[thisPopn]][[thisLocus]]))
              thisPopn.Probs<- as.vector(gameteFrequenciesTable[[thisPopn]][[thisLocus]])
              thisPopn.sample<-sample(thisPopn.Gametes,numSimsPerPopSelfed,replace=TRUE,thisPopn.Probs)
              thisPopn.sample<- t(matrix(unlist(strsplit(thisPopn.sample," ")),ploidy/2,))
              # Cobine sampled gametes
              # note 2 copies of same gamete for a simple version of selfing
              newProgeny<- cbind(thisPopn.sample,thisPopn.sample)
              # send to dataframe
              simCrosses[SimProgeny,locusRange]<- newProgeny
              simCrosses[SimProgeny,"pop"]<- thisPopn
              simCrosses[SimProgeny,"mother"]<- "u"
              simCrosses[SimProgeny,"ID"]<- paste(SimProgeny,"s",sep="")
              simCrosses[SimProgeny,"ActualCross"]<-thisPopn
          }
          # write.csv(simCrosses,"simCrosses.csv",row.names=FALSE)
        
        #####################################
        # Sampling of outcrossed genotypes  #
        #####################################
          # Increase flag for outcrossed progeny   
          flag<-max(SimProgeny)
          # simulated progeny ID labels for outcrossed progeny
          SimProgeny<- flag + (1:(numSimsPerPopOutcrossed))
        ########################################
        # random locations of father gametes   #
        ########################################
        randomPopns<-sample(allPopns,numSimsPerPopOutcrossed,replace=TRUE)
        thisPopninTotal.sample<-NULL

        
          ##########################
          ## Begin loop over loci ##
          ##########################
          for (thisLocus in 1:numLoci) {
              #testing zone thisLocus<-1
              ##current locus
              locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
          
              ##########################################################
              # sampling first lot of outcrossed gametes from homepop ##
              ##########################################################
              thisHomePopn.Gametes<- as.vector(colnames(gameteFrequenciesTable[[thisPopn]][[thisLocus]]))
              thisHomePopn.Probs<- as.vector(gameteFrequenciesTable[[thisPopn]][[thisLocus]])
              thisHomePopn.sample<-sample(thisHomePopn.Gametes,numSimsPerPopOutcrossed,replace=TRUE,thisHomePopn.Probs)
              thisHomePopn.sample<- t(matrix(unlist(strsplit(thisHomePopn.sample," ")),ploidy/2,))
              
              #######################################
              ## Begin loop over father locations  ##
              #######################################
              # Matrix to store the other population gametes
              thisPopninTotal.sample<-matrix(0,numSimsPerPopOutcrossed,ploidy/2)

              for (thisOne in 1:numSimsPerPopOutcrossed) {
                  # test thisRandomPop<-"GF"
                  thisRandomPop<-randomPopns[thisOne]
                  ####################################################
                  # Weighted sampling of gametes from thisPopinTotal #
                  ####################################################
                  thisPopninTotal.Gametes<- as.vector(colnames(gameteFrequenciesTable[[thisRandomPop]][[thisLocus]]))
                  thisPopninTotal.Probs<- as.vector(gameteFrequenciesTable[[thisRandomPop]][[thisLocus]])
                  sampledGam<-unlist(strsplit(sample(thisPopninTotal.Gametes,1,replace=TRUE,thisPopninTotal.Probs)," "))
                  thisPopninTotal.sample[thisOne,]<-sampledGam
              }
              #thisPopninTotal.sample<- t(matrix(unlist(strsplit(thisPopninTotal.sample," ")),ploidy/2,))
              # Cobine sampled gametes
              newProgeny<-cbind(thisHomePopn.sample,thisPopninTotal.sample)
              # send to dataframe          ncol(simCrosses)
              simCrosses[SimProgeny,locusRange]<- newProgeny
              simCrosses[SimProgeny,"pop"]<- thisPopn
              simCrosses[SimProgeny,"mother"]<- "u"
              simCrosses[SimProgeny,"ID"]<- paste(SimProgeny,"s",sep="")
              simCrosses[SimProgeny,"ActualCross"]<-paste(thisPopn,randomPopns,sep=" ")
              # clear out
              newProgeny<-NULL
              thisMother.sample<-NULL
              thisPopninTotal.sample<-NULL
        } # end locus loop   
        # clear out randomly selected populations
        randomPopns<-NULL
        # Increase flag ready for selfed seedlings from next population  
        flag<-max(SimProgeny)
      } # end population loop
      
  # convert end product to data frame
  these<-simCrosses[,1]!=0
  simCrosses<-simCrosses[these,]
  simCrosses<-as.data.frame(simCrosses)
  rownames(simCrosses)<-simCrosses$ID
  # Error rate, removing loci according to simMissLoci and replace with NA
  for (thisLocus in 1:numLoci) {
      #testing zone thisLocus<-1
      ##current locus
      locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
      randomNums<-runif(nrow(simCrosses),0,1)
      change<-randomNums<=simMissLoci
      simCrosses[change,locusRange]<-rep(NA,ploidy)
  }
  # combine simulated individuals with real adults
  inDataSimData<-rbind(inDataAdults, simCrosses)
  inDataSimData[1:numAdults,"ActualCross"]<-NA
  cat("COMPLETE \n")
  return(inDataSimData)
}


simulate.mother.known<- function(inData, alleleFrequenciesTable,gameteFrequenciesTable, 
                                  ploidy, marker, simulations, simMissLoci, selfing) {

#########################
# Simulation genotypes  #
#    mother = KNOWN     #
#########################

# Initial setup of functions depending on ploidy
cat("\n         Simulating Genotypes....")
flush.console()
  #############################################
  # a) Directing required hexaploid functions #
  #############################################
if (ploidy==6){
    getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
    if (marker == "genotype") {
        if (DRR == "min") {
            getMotherGameteInfo <- getMotherGameteInfoHexGenoMin # segregation ratios: gametes from individual
        } else if (DRR == "max") {
            getMotherGameteInfo <- getMotherGameteInfoHexGenoMax # segregation ratios: gametes from individual
        }
    }
    if (marker == "phenotype") {
        if (DRR == "min") {
            getMotherGameteInfo <- getMotherGameteInfoHexPhenoMin # segregation ratios: gametes from individual
        } else if (DRR == "max") {
            getMotherGameteInfo <- getMotherGameteInfoHexPhenoMax # segregation ratios: gametes from individual
        }
    }
}
  ################################################
  # b) Directing required tetraploid functions   #
  ################################################

if (ploidy==4) {
    getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
    if (marker == "genotype") {
        if (DRR == "min") {
            getMotherGameteInfo <- getMotherGameteInfoTetrGenoMin # segregation ratios: gametes from individual
        } else if (DRR == "max") {
            getMotherGameteInfo <- getMotherGameteInfoTetrGenoMax # segregation ratios: gametes from individual
        }
    }
    if (marker == "phenotype") {
        if (DRR == "min") {
            getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMin # segregation ratios: gametes from individual
        } else if (DRR == "max") {
            getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMax # segregation ratios: gametes from individual
        }
    }
}

  #############################
  # Initial setup             #
  # -population information   #
  # -data output structures   #
  #############################
  strip.NAs <- function(vv) {
      return(vv[!is.na(vv)])
  }
  if (ploidy == 6) {
      MAXSEEDLINGGENOTYPES <- 10
  } else if (ploidy == 4) {
      MAXSEEDLINGGENOTYPES <- 3
  }

  ##################################
  #  Setup objects to receive data #
  ##################################
  allPopns <- unique(inData$pop)
  numPopns <- length(allPopns)
  allMothers <- with(inData,unique(strip.NAs(mother)))
  allSeedlings <- with(inData,unique(ID[!is.na(mother)]))
  popnsWithMothers <- unique(with(inData,pop[ID %in% allMothers]))

  ##Strip out the seedlings, leaving adults and mothers:
  inDataAdults <- subset(inData,subset=is.na(mother))
  numAdults<-nrow(inDataAdults)

  ## Add additional column to inDataAdults
  newOne<-matrix(0,nrow(inDataAdults),1)
  colnames(newOne)<- "ActualCross"
  inDataAdults<-cbind(inDataAdults,newOne)

  ## Matrix for simulated progeny
  simCrosses<-matrix(0,simulations,ncol(inDataAdults))
  colnames(simCrosses)<- colnames(inDataAdults)

  ## Number of simulations
  numMothers<- length(allMothers)
  numSimsPerMum<- as.integer(simulations/length(allMothers))
  numSimsPerMumOutcrossed<-as.integer(numSimsPerMum*(1-selfing))
  numSimsPerMumSelfed<- numSimsPerMum - numSimsPerMumOutcrossed

  # Sets the start of ID labels for simulated progeny from current mother
  flag<-0

    ################################
    ## Begin loop over mothers    ##
    ################################
    for (thisMother in allMothers) {
        #test zone thisMother<-"GF14"

        #################################
        # Sampling of selfed genotypes  #
        #################################
          # simulated progeny ID labels for selfed individuals
          SimProgeny<- flag + (1:(numSimsPerMumSelfed))

          ##########################
          ## Begin loop over loci ##
          ##########################
          for (thisLocus in 1:numLoci) {
              #testing zone thisLocus<-1
              # Current locus column range
              locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
              #################################
              # Sampling of selfed genotypes  #
              #################################
              # First gamete from mother
              motherGenotype <- inData[inData$ID==thisMother,locusRange]             
              statusMum1<-!is.na(motherGenotype)
              # if mother has no alleles
                  if (all(statusMum1==FALSE)) {
                        # send a 0 for current mum
                        thisMother.sample<-sample(paste(rep("NA",ploidy),collapse=" "),numSimsPerMumSelfed,replace=TRUE)
                        newProgeny<-t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy,))
                  }
                  # Otherwise mother does have phenotype information and proceed
                  if (any(statusMum1==TRUE)) {
                      motherGenotype<-as.vector(strip.NAs(motherGenotype)) 
                      motherGametes <-getMotherGameteInfo(motherGenotype)
                      thisMother.Gametes<- as.vector(names(motherGametes$prob))
                      thisMother.Probs<- as.vector(motherGametes$prob)
                      thisMother.sample<- sample(thisMother.Gametes,numSimsPerMumSelfed,replace=TRUE,thisMother.Probs)
                      thisMother.sample<- t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy/2,))
                      # Second gamete from mother
                      thisSelfedFather.sample<- sample(thisMother.Gametes,numSimsPerMumSelfed,replace=TRUE,thisMother.Probs)
                      thisSelfedFather.sample<- t(matrix(unlist(strsplit(thisSelfedFather.sample," ")),ploidy/2,))
                      newProgeny<-cbind(thisMother.sample,thisSelfedFather.sample)
                  }
              # send to dataframe
              simCrosses[SimProgeny,locusRange]<- newProgeny
              simCrosses[SimProgeny,"pop"]<- inData[thisMother,"pop"]
              simCrosses[SimProgeny,"mother"]<- thisMother
              simCrosses[SimProgeny,"ID"]<- paste(SimProgeny,"s",sep="")
              simCrosses[SimProgeny,"ActualCross"]<-inData[thisMother,"pop"]
              # clear out
              newProgeny<-NULL
              thisMother.sample<-NULL
              thisSelfedFather.sample<-NULL
          }

        #####################################
        # Sampling of outcrossed genotypes  #
        #####################################
          # Increase flag for outcrossed progeny
          flag<-max(SimProgeny)
          # simulated progeny ID labels for outcrossed progeny
          SimProgeny<- flag + (1:(numSimsPerMumOutcrossed))

        ########################################
        # random locations of father gametes   #
        ########################################
        randomPopns<-sample(allPopns,numSimsPerMumOutcrossed,replace=TRUE)
        thisPopninTotal.sample<-NULL

          ##########################
          ## Begin loop over loci ##
          ##########################
          for (thisLocus in 1:numLoci) {
              #testing zone thisLocus<-1
              ##current locus
              locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy

              ##########################################
              # Sampling gametes from current mother  ##
              ##########################################
              # First gamete from mother
              motherGenotype <- inData[inData$ID==thisMother,locusRange]             
              statusMum1<-!is.na(motherGenotype)
              # if mother has no alleles
                  if (all(statusMum1==FALSE)) {
                        # send a 0 for current mum
                        thisMother.sample<-sample(paste(rep("NA",ploidy/2),collapse=" "),numSimsPerMumOutcrossed,replace=TRUE)
                        thisMother.sample<-t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy/2,))
                  }
                  # Otherwise mother does have phenotype information and proceed
                  if (any(statusMum1==TRUE)) {
                      motherGenotype<-as.vector(strip.NAs(motherGenotype))  
                      motherGametes <-getMotherGameteInfo(motherGenotype)
                      thisMother.Gametes<- as.vector(names(motherGametes$prob))
                      thisMother.Probs<- as.vector(motherGametes$prob)
                      thisMother.sample<- sample(thisMother.Gametes,numSimsPerMumOutcrossed,replace=TRUE,thisMother.Probs)
                      thisMother.sample<- t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy/2,))
                  }
                        
              #########################################
              ## Begin loop over father locations    ##
              #########################################
              for (thisRandomPop in randomPopns) {
                  # test thisRandomPop<-"GF"
                  ######################################################################
                  # Sampling of gametes from current father location in thisPopinTotal #
                  ######################################################################
                  thisPopninTotal.Gametes<- as.vector(colnames(gameteFrequenciesTable[[thisRandomPop]][[thisLocus]]))
                  thisPopninTotal.Probs<- as.vector(gameteFrequenciesTable[[thisRandomPop]][[thisLocus]])
                  thisPopninTotal.sample<-c(thisPopninTotal.sample,sample(thisPopninTotal.Gametes,1,replace=TRUE,thisPopninTotal.Probs))
              }
              thisPopninTotal.sample<- t(matrix(unlist(strsplit(thisPopninTotal.sample," ")),ploidy/2,))
              # Combine sampled gametes
              newProgeny<-cbind(thisMother.sample,thisPopninTotal.sample)
              # Remove new progeny with missing information for one gamete
              for (thisRow in 1:nrow(newProgeny)) {
                  if (any(is.na(newProgeny[thisRow,]))) {
                      newProgeny[thisRow,]<-NA
                  }
              }               
              # send to dataframe
              simCrosses[SimProgeny,locusRange]<- newProgeny
              simCrosses[SimProgeny,"pop"]<- inData[thisMother,"pop"]
              simCrosses[SimProgeny,"mother"]<- thisMother
              simCrosses[SimProgeny,"ID"]<- paste(SimProgeny,"s",sep="")
              simCrosses[SimProgeny,"ActualCross"]<-randomPopns
              #simCrosses[SimProgeny,"ActualCross"]<-paste(thisMother,randomPopns,sep=" ")
              # clearing out
              thisPopninTotal.sample<-NULL
              newProgeny<-NULL
              thisMother.sample<-NULL
          } #end locus loop
          # clear out randomly selected populations
          randomPopns<-NULL
          # Increase flag ready for selfed seedlings from next population
          flag<-max(SimProgeny)
        } #end mother loop
    these<-simCrosses[,1]!=0
    simCrosses<-simCrosses[these,]
    simCrosses<-as.data.frame(simCrosses)
    rownames(simCrosses)<-simCrosses$ID
    # Error rate, removing loci according to simMissLoci and replace with NA
    for (thisLocus in 1:numLoci) {
        #testing zone thisLocus<-1
        ##current locus
        locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
        randomNums<-runif(nrow(simCrosses),0,1)
        change<-randomNums<=simMissLoci
        simCrosses[change,locusRange]<-rep(NA,ploidy)
    }
  # combine simulated individuals with real adults
  inDataSimData<-rbind(inDataAdults, simCrosses)
  inDataSimData[1:numAdults,"ActualCross"]<-NA
  cat("COMPLETE \n")
  return(inDataSimData)
}
                