accuracyStruct <- function(StructData,summaryStructure,thisBatch,cutoff) {
        cat("\n ** Calculating Summary Statistics STRUCTURE.... **\n")
        flush.console()
        allPopns <- unique(StructData$pop)
        numPopns <- length(allPopns)
        # resorting clusters into pop order (A - J)
        popReOrder <- matrix(0,numPopns,numPopns+2)
        colnames(popReOrder) <- c("pop","currentCol",1:10)
        popReOrder[,1] <- c("A","B","C","D","E","F","G","H","I","J")
        adults <- StructData[StructData[,"ActualCross"]==0,]

        for (thisPop in 1:10) {
            # thisPop <- 1
            currentPop <- as.vector(popReOrder[thisPop,1])
            thisPopData <- adults[adults[,"pop"]==currentPop,]
            for (thisCluster in 1:10) {
                # thisCluster <- 1
                popReOrder[thisPop,(2+thisCluster)] <- round(mean(thisPopData[,4+(thisCluster)]),3)
            }
        }
        popReOrder <- as.data.frame(popReOrder)
        popReOrderSub <- popReOrder[,3:12]
        popReOrderSub <- as.matrix(popReOrderSub)
        tempMatrix <- matrix(0,10,1)
        for (thisPop in 1:10) {
            # thisPop <- 1
            tempMatrix[thisPop,1] <- as.numeric(names(popReOrderSub[thisPop,as.vector((popReOrderSub[thisPop,] >= cutoff))]))
        }
        popReOrder[,2]  <- tempMatrix
        # Reordering
        temp2 <- cbind(StructData[,1:4],StructData[,(4+as.vector(popReOrder[1,2]))],
                       StructData[,(4+as.vector(popReOrder[2,2]))],
                       StructData[,(4+as.vector(popReOrder[3,2]))],
                       StructData[,(4+as.vector(popReOrder[4,2]))],
                       StructData[,(4+as.vector(popReOrder[5,2]))],
                       StructData[,(4+as.vector(popReOrder[6,2]))],
                       StructData[,(4+as.vector(popReOrder[7,2]))],
                       StructData[,(4+as.vector(popReOrder[8,2]))],
                       StructData[,(4+as.vector(popReOrder[9,2]))],
                       StructData[,(4+as.vector(popReOrder[10,2]))],
                       StructData[,15:17]
                       )
        colnames(temp2)[5:14] <- c("A","B","C","D","E","F","G","H","I","J")
        StructData <- temp2
        # Separating adults and seedlings
        adults <- StructData[StructData[,"ActualCross"]==0,]
        seedlings <- StructData[StructData[,"ActualCross"]!=0,]
        # ranking pops
        cSRanks <- t(apply(seedlings[,(5:14)],1,
                   function(vv) {
                   rank(vv,ties.method="random")
                   }
                   ))
        numSeedlings <- max(row(seedlings))
        rankMatrix <- matrix(0,numSeedlings,7)
        rankMatrix[,1] <- as.vector(seedlings[,1])
        colnames(rankMatrix) <- c("SeedlingID","Q_0.9","Q_0.8","Q_0.7","Q_0.6","Q_0.5","Q_0.4")
        #rownames(rankMatrix) <- rownames(cSRanks)

        for(thisSeedling in 1:numSeedlings) {
            # thisSeedling <-1
            vec <- cSRanks[thisSeedling,,drop=FALSE]
            FirstRank <-colnames(vec[,vec==10,drop=FALSE])
            SecondRank <- colnames(vec[,vec==9,drop=FALSE])
            combinedNames <- paste(sort(c(FirstRank,SecondRank)),collapse="_")
            FirstRankQ <- seedlings[thisSeedling,FirstRank]
            SecondRankQ <- seedlings[thisSeedling,SecondRank]
            combinedScores <- c(FirstRankQ,SecondRankQ)
            highQ <- max(combinedScores)
            if (highQ >= 0.9) {
                rankMatrix[thisSeedling,2:7] <- rep(paste(FirstRank,FirstRank,sep="_"),6)
            }
            if (0.8 <= highQ & highQ < 0.9) {
                rankMatrix[thisSeedling,2:7] <- c(rep(combinedNames,1),
                                                   rep(paste(FirstRank,FirstRank,sep="_"),5))
            }
            if (0.7 <= highQ & highQ < 0.8) {
                rankMatrix[thisSeedling,2:7] <- c(rep(combinedNames,2),
                                                   rep(paste(FirstRank,FirstRank,sep="_"),4))
            }
            if (0.6 <= highQ & highQ < 0.7) {
                rankMatrix[thisSeedling,2:7] <- c(rep(combinedNames,3),
                                                   rep(paste(FirstRank,FirstRank,sep="_"),3))
            }
            if (0.5 <= highQ & highQ < 0.6) {
                rankMatrix[thisSeedling,2:7] <- c(rep(combinedNames,4),
                                                   rep(paste(FirstRank,FirstRank,sep="_"),2))
            }
            if (0.4 <= highQ & highQ < 0.5) {
                rankMatrix[thisSeedling,2:7] <- c(rep(combinedNames,5),
                                                   rep(paste(FirstRank,FirstRank,sep="_"),1))
            }
            if (highQ <= 0.4) {
                rankMatrix[thisSeedling,2:7] <- rep(combinedNames,6)
            }
         } # End loop over seedlings
        FinalStructureData <- cbind(seedlings[,15:17],seedlings[,4:14],rankMatrix[,2:7])

        # Correct & Incorrect
        CorrectQ90 <- as.vector(FinalStructureData[,"Q_0.9"]) == FinalStructureData[,"ActualCross"]
        CorrectQ80 <- as.vector(FinalStructureData[,"Q_0.8"]) == FinalStructureData[,"ActualCross"]
        CorrectQ70 <- as.vector(FinalStructureData[,"Q_0.7"]) == FinalStructureData[,"ActualCross"]
        CorrectQ60 <- as.vector(FinalStructureData[,"Q_0.6"]) == FinalStructureData[,"ActualCross"]
        CorrectQ50 <- as.vector(FinalStructureData[,"Q_0.5"]) == FinalStructureData[,"ActualCross"]
        CorrectQ40 <- as.vector(FinalStructureData[,"Q_0.4"]) == FinalStructureData[,"ActualCross"]
        InCorrectQ90 <- as.vector(FinalStructureData[,"Q_0.9"]) != FinalStructureData[,"ActualCross"]
        InCorrectQ80 <- as.vector(FinalStructureData[,"Q_0.8"]) != FinalStructureData[,"ActualCross"]
        InCorrectQ70 <- as.vector(FinalStructureData[,"Q_0.7"]) != FinalStructureData[,"ActualCross"]
        InCorrectQ60 <- as.vector(FinalStructureData[,"Q_0.6"]) != FinalStructureData[,"ActualCross"]
        InCorrectQ50 <- as.vector(FinalStructureData[,"Q_0.5"]) != FinalStructureData[,"ActualCross"]
        InCorrectQ40 <- as.vector(FinalStructureData[,"Q_0.4"]) != FinalStructureData[,"ActualCross"]
        # Overall Accuracy
        TotalAccuracy_Q90 <- round(sum(as.numeric(CorrectQ90))/((sum(as.numeric(CorrectQ90)))+(sum(as.numeric(InCorrectQ90)))),3)
        TotalAccuracy_Q80 <- round(sum(as.numeric(CorrectQ80))/((sum(as.numeric(CorrectQ80)))+(sum(as.numeric(InCorrectQ80)))),3)
        TotalAccuracy_Q70 <- round(sum(as.numeric(CorrectQ70))/((sum(as.numeric(CorrectQ70)))+(sum(as.numeric(InCorrectQ70)))),3)
        TotalAccuracy_Q60 <- round(sum(as.numeric(CorrectQ60))/((sum(as.numeric(CorrectQ60)))+(sum(as.numeric(InCorrectQ60)))),3)
        TotalAccuracy_Q50 <- round(sum(as.numeric(CorrectQ50))/((sum(as.numeric(CorrectQ50)))+(sum(as.numeric(InCorrectQ50)))),3)
        TotalAccuracy_Q40 <- round(sum(as.numeric(CorrectQ40))/((sum(as.numeric(CorrectQ40)))+(sum(as.numeric(InCorrectQ40)))),3)
        summaryStructure[thisBatch,"Q90_Accuracy_Total"] <- TotalAccuracy_Q90
        summaryStructure[thisBatch,"Q80_Accuracy_Total"] <- TotalAccuracy_Q80
        summaryStructure[thisBatch,"Q70_Accuracy_Total"] <- TotalAccuracy_Q70
        summaryStructure[thisBatch,"Q60_Accuracy_Total"] <- TotalAccuracy_Q60
        summaryStructure[thisBatch,"Q50_Accuracy_Total"] <- TotalAccuracy_Q50
        summaryStructure[thisBatch,"Q40_Accuracy_Total"] <- TotalAccuracy_Q40

        # Accuracy Within Population crosses
        thisRunWithinPop <- FinalStructureData[FinalStructureData[,"CrossType"] == "W_POP",]
        CorrectQ90_WI <- as.vector(thisRunWithinPop[,"Q_0.9"]) == thisRunWithinPop[,"ActualCross"]
        CorrectQ80_WI <- as.vector(thisRunWithinPop[,"Q_0.8"]) == thisRunWithinPop[,"ActualCross"]
        CorrectQ70_WI <- as.vector(thisRunWithinPop[,"Q_0.7"]) == thisRunWithinPop[,"ActualCross"]
        CorrectQ60_WI <- as.vector(thisRunWithinPop[,"Q_0.6"]) == thisRunWithinPop[,"ActualCross"]
        CorrectQ50_WI <- as.vector(thisRunWithinPop[,"Q_0.5"]) == thisRunWithinPop[,"ActualCross"]
        CorrectQ40_WI <- as.vector(thisRunWithinPop[,"Q_0.4"]) == thisRunWithinPop[,"ActualCross"]
        InCorrectQ90_WI <- as.vector(thisRunWithinPop[,"Q_0.9"]) != thisRunWithinPop[,"ActualCross"]
        InCorrectQ80_WI <- as.vector(thisRunWithinPop[,"Q_0.8"]) != thisRunWithinPop[,"ActualCross"]
        InCorrectQ70_WI <- as.vector(thisRunWithinPop[,"Q_0.7"]) != thisRunWithinPop[,"ActualCross"]
        InCorrectQ60_WI <- as.vector(thisRunWithinPop[,"Q_0.6"]) != thisRunWithinPop[,"ActualCross"]
        InCorrectQ50_WI <- as.vector(thisRunWithinPop[,"Q_0.5"]) != thisRunWithinPop[,"ActualCross"]
        InCorrectQ40_WI <- as.vector(thisRunWithinPop[,"Q_0.4"]) != thisRunWithinPop[,"ActualCross"]
        WIpopAccuracy_Q90 <- round(sum(as.numeric(CorrectQ90_WI))/((sum(as.numeric(CorrectQ90_WI)))+(sum(as.numeric(InCorrectQ90_WI)))),3)
        WIpopAccuracy_Q80 <- round(sum(as.numeric(CorrectQ80_WI))/((sum(as.numeric(CorrectQ80_WI)))+(sum(as.numeric(InCorrectQ80_WI)))),3)
        WIpopAccuracy_Q70 <- round(sum(as.numeric(CorrectQ70_WI))/((sum(as.numeric(CorrectQ70_WI)))+(sum(as.numeric(InCorrectQ70_WI)))),3)
        WIpopAccuracy_Q60 <- round(sum(as.numeric(CorrectQ60_WI))/((sum(as.numeric(CorrectQ60_WI)))+(sum(as.numeric(InCorrectQ60_WI)))),3)
        WIpopAccuracy_Q50 <- round(sum(as.numeric(CorrectQ50_WI))/((sum(as.numeric(CorrectQ50_WI)))+(sum(as.numeric(InCorrectQ50_WI)))),3)
        WIpopAccuracy_Q40 <- round(sum(as.numeric(CorrectQ40_WI))/((sum(as.numeric(CorrectQ40_WI)))+(sum(as.numeric(InCorrectQ40_WI)))),3)
        summaryStructure[thisBatch,"Q90_Accuracy_WIPOP"] <- WIpopAccuracy_Q90
        summaryStructure[thisBatch,"Q80_Accuracy_WIPOP"] <- WIpopAccuracy_Q80
        summaryStructure[thisBatch,"Q70_Accuracy_WIPOP"] <- WIpopAccuracy_Q70
        summaryStructure[thisBatch,"Q60_Accuracy_WIPOP"] <- WIpopAccuracy_Q60
        summaryStructure[thisBatch,"Q50_Accuracy_WIPOP"] <- WIpopAccuracy_Q50
        summaryStructure[thisBatch,"Q40_Accuracy_WIPOP"] <- WIpopAccuracy_Q40

        # Accuracy Between Population crosses               thisRunBetweenPop[2000:2100,]
                                                         # nrow(thisRunBetweenPop)
        thisRunBetweenPop <- FinalStructureData[FinalStructureData[,"CrossType"] == "B_POP",]
        CorrectQ90_BW <- as.vector(thisRunBetweenPop[,"Q_0.9"]) == thisRunBetweenPop[,"ActualCross"]
        CorrectQ80_BW <- as.vector(thisRunBetweenPop[,"Q_0.8"]) == thisRunBetweenPop[,"ActualCross"]
        CorrectQ70_BW <- as.vector(thisRunBetweenPop[,"Q_0.7"]) == thisRunBetweenPop[,"ActualCross"]
        CorrectQ60_BW <- as.vector(thisRunBetweenPop[,"Q_0.6"]) == thisRunBetweenPop[,"ActualCross"]
        CorrectQ50_BW <- as.vector(thisRunBetweenPop[,"Q_0.5"]) == thisRunBetweenPop[,"ActualCross"]
        CorrectQ40_BW <- as.vector(thisRunBetweenPop[,"Q_0.4"]) == thisRunBetweenPop[,"ActualCross"]
        InCorrectQ90_BW <- as.vector(thisRunBetweenPop[,"Q_0.9"]) != thisRunBetweenPop[,"ActualCross"]
        InCorrectQ80_BW <- as.vector(thisRunBetweenPop[,"Q_0.8"]) != thisRunBetweenPop[,"ActualCross"]
        InCorrectQ70_BW <- as.vector(thisRunBetweenPop[,"Q_0.7"]) != thisRunBetweenPop[,"ActualCross"]
        InCorrectQ60_BW <- as.vector(thisRunBetweenPop[,"Q_0.6"]) != thisRunBetweenPop[,"ActualCross"]
        InCorrectQ50_BW <- as.vector(thisRunBetweenPop[,"Q_0.5"]) != thisRunBetweenPop[,"ActualCross"]
        InCorrectQ40_BW <- as.vector(thisRunBetweenPop[,"Q_0.4"]) != thisRunBetweenPop[,"ActualCross"]
        BWpopAccuracy_Q90 <- round(sum(as.numeric(CorrectQ90_BW))/((sum(as.numeric(CorrectQ90_BW)))+(sum(as.numeric(InCorrectQ90_BW)))),3)
        BWpopAccuracy_Q80 <- round(sum(as.numeric(CorrectQ80_BW))/((sum(as.numeric(CorrectQ80_BW)))+(sum(as.numeric(InCorrectQ80_BW)))),3)
        BWpopAccuracy_Q70 <- round(sum(as.numeric(CorrectQ70_BW))/((sum(as.numeric(CorrectQ70_BW)))+(sum(as.numeric(InCorrectQ70_BW)))),3)
        BWpopAccuracy_Q60 <- round(sum(as.numeric(CorrectQ60_BW))/((sum(as.numeric(CorrectQ60_BW)))+(sum(as.numeric(InCorrectQ60_BW)))),3)
        BWpopAccuracy_Q50 <- round(sum(as.numeric(CorrectQ50_BW))/((sum(as.numeric(CorrectQ50_BW)))+(sum(as.numeric(InCorrectQ50_BW)))),3)
        BWpopAccuracy_Q40 <- round(sum(as.numeric(CorrectQ40_BW))/((sum(as.numeric(CorrectQ40_BW)))+(sum(as.numeric(InCorrectQ40_BW)))),3)
        summaryStructure[thisBatch,"Q90_Accuracy_BWPOP"] <- BWpopAccuracy_Q90
        summaryStructure[thisBatch,"Q80_Accuracy_BWPOP"] <- BWpopAccuracy_Q80
        summaryStructure[thisBatch,"Q70_Accuracy_BWPOP"] <- BWpopAccuracy_Q70
        summaryStructure[thisBatch,"Q60_Accuracy_BWPOP"] <- BWpopAccuracy_Q60
        summaryStructure[thisBatch,"Q50_Accuracy_BWPOP"] <- BWpopAccuracy_Q50
        summaryStructure[thisBatch,"Q40_Accuracy_BWPOP"] <- BWpopAccuracy_Q40

        # Prepare data to test efficiency
        modifyPopAssign <- as.matrix(FinalStructureData[,15:20])
        modifyPopAssignType <- as.matrix(FinalStructureData[,15:20])
        modifyPopAssignType[,] <- 0
        for (thisRow in 1:nrow(FinalStructureData)) {
             # test thisRow <- 1
             for (thisCol in 1:ncol(modifyPopAssign)) {
                # test thisCol <- 1
                thesePops <- unlist(strsplit(as.vector(modifyPopAssign[thisRow,thisCol]),"_"))
                if (length(unique(thesePops)) !=2)   {
                    modifyPopAssign[thisRow,thisCol] <- thesePops[1]
                    modifyPopAssignType[thisRow,thisCol] <- "W_POP"
                }
                if (length(unique(thesePops)) ==2)   {
                    modifyPopAssignType[thisRow,thisCol] <- "B_POP"
                }
             }
        }
        head(FinalStructureData)
        head(modifyPopAssign)
        head(modifyPopAssignType)
        colnames(modifyPopAssignType) <- c("TypeQ_0.9","TypeQ_0.8","TypeQ_0.7","TypeQ_0.6","TypeQ_0.5","TypeQ_0.4")
        FinalStructureData <- cbind(FinalStructureData,modifyPopAssignType)

        modifyPopAssignType <- as.data.frame(modifyPopAssignType)
        modifyPopAssign <- as.data.frame(modifyPopAssign)
       # Efficiency Within Population Crosses
       numActual_W_POP <- sum(as.numeric(FinalStructureData$CrossType == "W_POP"))
       theseDetectedQ90_W_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.9"] == "W_POP",]
       theseDetectedQ80_W_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.8"] == "W_POP",]
       theseDetectedQ70_W_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.7"] == "W_POP",]
       theseDetectedQ60_W_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.6"] == "W_POP",]
       theseDetectedQ50_W_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.5"] == "W_POP",]
       theseDetectedQ40_W_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.4"] == "W_POP",]
       correctAssignWithinQ90_Eff <- sum(as.numeric(as.vector(theseDetectedQ90_W_POP[,"ActualCross"]) == theseDetectedQ90_W_POP[,"Q_0.9"]))
       correctAssignWithinQ80_Eff <- sum(as.numeric(as.vector(theseDetectedQ80_W_POP[,"ActualCross"]) == theseDetectedQ80_W_POP[,"Q_0.8"]))
       correctAssignWithinQ70_Eff <- sum(as.numeric(as.vector(theseDetectedQ70_W_POP[,"ActualCross"]) == theseDetectedQ70_W_POP[,"Q_0.7"]))
       correctAssignWithinQ60_Eff <- sum(as.numeric(as.vector(theseDetectedQ60_W_POP[,"ActualCross"]) == theseDetectedQ60_W_POP[,"Q_0.6"]))
       correctAssignWithinQ50_Eff <- sum(as.numeric(as.vector(theseDetectedQ50_W_POP[,"ActualCross"]) == theseDetectedQ50_W_POP[,"Q_0.5"]))
       correctAssignWithinQ40_Eff <- sum(as.numeric(as.vector(theseDetectedQ40_W_POP[,"ActualCross"]) == theseDetectedQ40_W_POP[,"Q_0.4"]))
       numDetectedQ90_W_POP <- nrow(theseDetectedQ90_W_POP)
       numDetectedQ80_W_POP <- nrow(theseDetectedQ80_W_POP)
       numDetectedQ70_W_POP <- nrow(theseDetectedQ70_W_POP)
       numDetectedQ60_W_POP <- nrow(theseDetectedQ60_W_POP)
       numDetectedQ50_W_POP <- nrow(theseDetectedQ50_W_POP)
       numDetectedQ40_W_POP <- nrow(theseDetectedQ40_W_POP)
       EffQ90_W_POP <- correctAssignWithinQ90_Eff/nrow(theseDetectedQ90_W_POP)
       EffQ80_W_POP <- correctAssignWithinQ80_Eff/nrow(theseDetectedQ80_W_POP)
       EffQ70_W_POP <- correctAssignWithinQ70_Eff/nrow(theseDetectedQ70_W_POP)
       EffQ60_W_POP <- correctAssignWithinQ60_Eff/nrow(theseDetectedQ60_W_POP)
       EffQ50_W_POP <- correctAssignWithinQ50_Eff/nrow(theseDetectedQ50_W_POP)
       EffQ40_W_POP <- correctAssignWithinQ40_Eff/nrow(theseDetectedQ40_W_POP)
       summaryStructure[thisBatch,"Q90_Efficiency_WIPOP"] <- EffQ90_W_POP
       summaryStructure[thisBatch,"Q80_Efficiency_WIPOP"] <- EffQ80_W_POP
       summaryStructure[thisBatch,"Q70_Efficiency_WIPOP"] <- EffQ70_W_POP
       summaryStructure[thisBatch,"Q60_Efficiency_WIPOP"] <- EffQ60_W_POP
       summaryStructure[thisBatch,"Q50_Efficiency_WIPOP"] <- EffQ50_W_POP
       summaryStructure[thisBatch,"Q40_Efficiency_WIPOP"] <- EffQ40_W_POP

       # Efficiency Between Population Crosses
       numActual_B_POP <- sum(as.numeric(FinalStructureData$CrossType == "B_POP"))
       theseDetectedQ90_B_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.9"] == "B_POP",]
       theseDetectedQ80_B_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.8"] == "B_POP",]
       theseDetectedQ70_B_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.7"] == "B_POP",]
       theseDetectedQ60_B_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.6"] == "B_POP",]
       theseDetectedQ50_B_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.5"] == "B_POP",]
       theseDetectedQ40_B_POP <- FinalStructureData[FinalStructureData[,"TypeQ_0.4"] == "B_POP",]
       correctAssignBetweenQ90_Eff <- sum(as.numeric(as.vector(theseDetectedQ90_B_POP[,"ActualCross"]) == theseDetectedQ90_B_POP[,"Q_0.9"]))
       correctAssignBetweenQ80_Eff <- sum(as.numeric(as.vector(theseDetectedQ80_B_POP[,"ActualCross"]) == theseDetectedQ80_B_POP[,"Q_0.8"]))
       correctAssignBetweenQ70_Eff <- sum(as.numeric(as.vector(theseDetectedQ70_B_POP[,"ActualCross"]) == theseDetectedQ70_B_POP[,"Q_0.7"]))
       correctAssignBetweenQ60_Eff <- sum(as.numeric(as.vector(theseDetectedQ60_B_POP[,"ActualCross"]) == theseDetectedQ60_B_POP[,"Q_0.6"]))
       correctAssignBetweenQ50_Eff <- sum(as.numeric(as.vector(theseDetectedQ50_B_POP[,"ActualCross"]) == theseDetectedQ50_B_POP[,"Q_0.5"]))
       correctAssignBetweenQ40_Eff <- sum(as.numeric(as.vector(theseDetectedQ40_B_POP[,"ActualCross"]) == theseDetectedQ40_B_POP[,"Q_0.4"]))
       numDetectedQ90_B_POP <- nrow(theseDetectedQ90_B_POP)
       numDetectedQ80_B_POP <- nrow(theseDetectedQ80_B_POP)
       numDetectedQ70_B_POP <- nrow(theseDetectedQ70_B_POP)
       numDetectedQ60_B_POP <- nrow(theseDetectedQ60_B_POP)
       numDetectedQ50_B_POP <- nrow(theseDetectedQ50_B_POP)
       numDetectedQ40_B_POP <- nrow(theseDetectedQ40_B_POP)
       EffQ90_B_POP <- correctAssignBetweenQ90_Eff/numDetectedQ90_B_POP
       EffQ80_B_POP <- correctAssignBetweenQ80_Eff/numDetectedQ80_B_POP
       EffQ70_B_POP <- correctAssignBetweenQ70_Eff/numDetectedQ70_B_POP
       EffQ60_B_POP <- correctAssignBetweenQ60_Eff/numDetectedQ60_B_POP
       EffQ50_B_POP <- correctAssignBetweenQ50_Eff/numDetectedQ50_B_POP
       EffQ40_B_POP <- correctAssignBetweenQ40_Eff/numDetectedQ40_B_POP
       summaryStructure[thisBatch,"Q90_Efficiency_BWPOP"] <- EffQ90_B_POP
       summaryStructure[thisBatch,"Q80_Efficiency_BWPOP"] <- EffQ80_B_POP
       summaryStructure[thisBatch,"Q70_Efficiency_BWPOP"] <- EffQ70_B_POP
       summaryStructure[thisBatch,"Q60_Efficiency_BWPOP"] <- EffQ60_B_POP
       summaryStructure[thisBatch,"Q50_Efficiency_BWPOP"] <- EffQ50_B_POP
       summaryStructure[thisBatch,"Q40_Efficiency_BWPOP"] <- EffQ40_B_POP

       # Overall % of B-Pop crosses detected (correct or incorrect)
       immgrantDetectedQ90 <- numDetectedQ90_B_POP/(numDetectedQ90_B_POP+numDetectedQ90_W_POP)
       immgrantDetectedQ80 <- numDetectedQ80_B_POP/(numDetectedQ80_B_POP+numDetectedQ80_W_POP)
       immgrantDetectedQ70 <- numDetectedQ70_B_POP/(numDetectedQ70_B_POP+numDetectedQ70_W_POP)
       immgrantDetectedQ60 <- numDetectedQ60_B_POP/(numDetectedQ60_B_POP+numDetectedQ60_W_POP)
       immgrantDetectedQ50 <- numDetectedQ50_B_POP/(numDetectedQ50_B_POP+numDetectedQ50_W_POP)
       immgrantDetectedQ40 <- numDetectedQ40_B_POP/(numDetectedQ40_B_POP+numDetectedQ40_W_POP)
       summaryStructure[thisBatch,"Q90_B-POP Estimate"] <- immgrantDetectedQ90
       summaryStructure[thisBatch,"Q80_B-POP Estimate"] <- immgrantDetectedQ80
       summaryStructure[thisBatch,"Q70_B-POP Estimate"] <- immgrantDetectedQ70
       summaryStructure[thisBatch,"Q60_B-POP Estimate"] <- immgrantDetectedQ60
       summaryStructure[thisBatch,"Q50_B-POP Estimate"] <- immgrantDetectedQ50
       summaryStructure[thisBatch,"Q40_B-POP Estimate"] <- immgrantDetectedQ40
       return(summaryStructure[thisBatch,])

}
