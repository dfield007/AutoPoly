##########################################
#                                        #
#       Allele frequencies               #
#       Three separate functions         #
#        1. alleleFrequenciesPhenoSimple #
#        2. alleleFrequenciesPhenoIter   #
#        3. alleleFrequenciesGeno        #
#                                        #
#          Author: David Field           #
#          Date: 1/2/2010                #
#                                        #
##########################################

alleleFrequenciesPhenoSimple <- function(inData,numLoci,ploidy,resample,nsample) {

    strip.NAs <- function(vv) {
    return(vv[!is.na(vv)])
  }
  lociRanges <- matrix(4:ncol(inData),ncol=ploidy,byrow=TRUE)
  ##Strip out the seedlings, leaving adults and mothers:
  inData <- subset(inData,subset=is.na(mother))
  ##Split up the populations:
  popnList <- split(inData,inData$pop)
  alleleFrequenciesTable <- lapply(popnList,  ##Loop over populations in popnList
                          function (thisPopn) {
                            locusAlleleProbs <- list()
                            for (thisLocus in 1:numLoci) {
                              #test thisLocus <- 1
                              #test thisPopn <- popnList[[1]]
                              thisPopnThisLocus <- thisPopn[,lociRanges[thisLocus,]]
                              #remove adults with no data
                              numAdults <- nrow(thisPopnThisLocus)
                              goodAdults <- matrix(0,nrow=numAdults)
                              for (thisAdult in 1:numAdults) {
                                 #test thisAdult <- 1
                                if (sum(is.na(thisPopnThisLocus[thisAdult,])) != ploidy) {
                                  goodAdults[thisAdult,] <- rownames(thisPopnThisLocus[thisAdult,])
                                  }
                              }
                              goodAdults <- goodAdults[goodAdults!=0,]
                              thisPopnThisLocus <- thisPopnThisLocus[goodAdults,]
                              #get number of adults
                              numAdults <- nrow(thisPopnThisLocus)
                              ##Get unique alleles at current locus in current population
                              popnAlleles <- sort(strip.NAs(unique(unlist(thisPopnThisLocus))))
                              ##The matrix of allele frequencies for each adult
                              alleleMatrix <- matrix(0,nrow=numAdults,ncol=length(popnAlleles))
                              colnames(alleleMatrix) <- popnAlleles
                              for (thisAdult in 1:numAdults) {
                                      #test thisAdult <- 1
                                      thisAdultsAlleles <- strip.NAs(thisPopnThisLocus[thisAdult,])
                                      if (mode(thisAdultsAlleles)=="numeric") {
                                          thisAdultsAlleles <- unlist(strsplit(as.character(thisAdultsAlleles)," "))
                                      }
                                      alleleMatrix[thisAdult,thisAdultsAlleles] <- 1/length(thisAdultsAlleles)
                              }  ##End loop
                                  locusAlleleProbs[[thisLocus]] <- apply(alleleMatrix,2,mean)
                            } ##End thisLocus loop
                            return(locusAlleleProbs)
                          } ##End thisPopn lapply function
                          )
   cat("COMPLETE \n")
  return(alleleFrequenciesTable)
}

alleleFrequenciesPhenoResample <- function(inData,numLoci,ploidy,resample,nsample) {

    strip.NAs <- function(vv) {
    return(vv[!is.na(vv)])
  }
  lociRanges <- matrix(4:ncol(inData),ncol=ploidy,byrow=TRUE)
  ##Strip out the seedlings, leaving adults and mothers:
  inData <- subset(inData,subset=is.na(mother))
  ##Split up the populations:
  popnList <- split(inData,inData$pop)
  alleleFrequenciesTable <- lapply(popnList,  ##Loop over populations in popnList
                          function (thisPopn) {
                            locusAlleleProbs <- list()
                            for (thisLocus in 1:numLoci) {
                              #test thisLocus<-1
                              #test thisPopn<-popnList[[1]]
                              thisPopnThisLocus<-thisPopn[,lociRanges[thisLocus,]]
                              #remove adults with no data
                              numAdults<-nrow(thisPopnThisLocus)
                              goodAdults<-matrix(0,nrow=numAdults)
                              for (thisAdult in 1:numAdults) {
                                 #test thisAdult<-1
                                if (sum(is.na(thisPopnThisLocus[thisAdult,]))!=ploidy) {
                                  goodAdults[thisAdult,]<-rownames(thisPopnThisLocus[thisAdult,])
                                  }
                                }
                              goodAdults<-goodAdults[goodAdults!=0,]
                              thisPopnThisLocus<-thisPopnThisLocus[goodAdults,]
                              #get number of adults
                              numAdults<-nrow(thisPopnThisLocus)
                              ##Get unique alleles at current locus in current population
                              popnAlleles <- sort(strip.NAs(unique(unlist(thisPopnThisLocus))))
                              ##The matrix of allele frequencies for each adult
                              alleleMatrix <- matrix(0,nrow=numAdults,ncol=length(popnAlleles))
                              colnames(alleleMatrix) <- popnAlleles
                              for (thisAdult in 1:numAdults) {
                                      #test thisAdult<-4
                                      thisAdultsAlleles <- strip.NAs(thisPopnThisLocus[thisAdult,])
                                      alleleMatrix[thisAdult,thisAdultsAlleles] <- 1/length(thisAdultsAlleles)
                                  }  ##End loop
                                  locusAlleleProbs[[thisLocus]] <- apply(alleleMatrix,2,mean)
                            } ##End thisLocus loop
                            return(locusAlleleProbs)
                          } ##End thisPopn lapply function
                          )
   cat("COMPLETE \n")
    return(alleleFrequenciesTable)
}

alleleFrequenciesGeno <- function(inData,numLoci,ploidy) {

    strip.NAs <- function(vv) {
    return(vv[!is.na(vv)])
  }
  lociRanges <- matrix(4:ncol(inData),ncol=ploidy,byrow=TRUE)
  ##Strip out the seedlings, leaving adults and mothers:
  inData <- subset(inData,subset=is.na(mother))
  ##Split up the populations:
  popnList <- split(inData,inData$pop)
  alleleFrequenciesTable <- lapply(popnList,  ##Loop over populations in popnList
                          function (thisPopn) {
                            locusAlleleProbs <- list()
                            for (thisLocus in 1:numLoci) {
                              #test thisLocus<-1
                              #test thisPopn<-popnList[[1]]
                              thisPopnThisLocus<-thisPopn[,lociRanges[thisLocus,]]
                              #remove adults with no data
                              numAdults<-nrow(thisPopnThisLocus)
                              goodAdults<-matrix(0,nrow=numAdults)
                              for (thisAdult in 1:numAdults) {
                                 #test thisAdult<-1
                                if (sum(is.na(thisPopnThisLocus[thisAdult,]))!=ploidy) {
                                  goodAdults[thisAdult,]<-rownames(thisPopnThisLocus[thisAdult,])
                                  }
                                }
                              goodAdults<-goodAdults[goodAdults!=0,]
                              thisPopnThisLocus<-thisPopnThisLocus[goodAdults,]
                              #get number of adults
                              numAdults<-nrow(thisPopnThisLocus)
                              ##Get unique alleles at current locus in current population
                              popnAlleles <- sort(strip.NAs(unique(unlist(thisPopnThisLocus))))
                              ##The matrix of allele frequencies for each adult
                              alleleMatrix <- matrix(0,nrow=numAdults,ncol=length(popnAlleles))
                              colnames(alleleMatrix) <- popnAlleles
                              # Get total number of alleles in population
                              popnAllelesNum<-ploidy*numAdults
                              # Number of each allele
                              numEachAllele<-table(unlist(thisPopnThisLocus))
                              # Frequency of each allele
                              locusAlleleProbs[[thisLocus]]<-numEachAllele/popnAllelesNum

                        #      for (thisAdult in 1:numAdults) {
                        #              #test thisAdult<-1
                        #              thisAdultsAlleles <- strip.NAs(thisPopnThisLocus[thisAdult,])
                        #              alleleMatrix[thisAdult,thisAdultsAlleles] <- 1/length(thisAdultsAlleles)
                        #          }  ##End loop
                        #          locusAlleleProbs[[thisLocus]] <- apply(alleleMatrix,2,mean)
                            } ##End thisLocus loop
                            return(locusAlleleProbs)
                          } ##End thisPopn lapply function
                          )
   cat("COMPLETE \n")
    return(alleleFrequenciesTable)
}

alleleFreqPheno <- function(inData,numLoci,ploidy,resample,nsample) {
                                  cat("\n    Calculating Allele Frequencies....")
                                        flush.console()
                                    if (resample==FALSE) {
                                        alleleFrequenciesMain <- alleleFrequenciesPhenoSimple
                                        return(alleleFrequenciesMain(inData,numLoci,ploidy,resample,nsample))
                                    }
                                    if (resample==TRUE) {
                                        alleleFrequenciesMain<-alleleFrequenciesPhenoResample
                                    return(alleleFrequenciesMain(inData,numLoci,ploidy,resample,nsample))
                                    }
                                  }

alleleFreqGeno <- function(inData,numLoci,ploidy) {
                            cat("\n    Calculating Allele Frequencies....")
                            flush.console()
                            alleleFrequenciesMain<-alleleFrequenciesGeno
                            return(alleleFrequenciesMain(inData,numLoci,ploidy))
                            }
