# Setup DRR for loci

DRRsetupPowerTest <- function(numLoci,ploidy,propDRR) {
      DRR <- matrix(0,numLoci,2)
      rownames(DRR) <- 1:numLoci
      colnames(DRR) <- c("DRR","Simple DDR")
      DRR <- as.data.frame(DRR)
      for (thisLoc in 1:6) {
          DRR[1:6,1] <- sample(c(rep(0,6*(1-propDRR)),runif(6*propDRR,0.01,0.2727)),replace=FALSE)
      }
      for (thisLoc in 7:12) {
          DRR[7:12,1] <- sample(c(rep(0,6*(1-propDRR)),runif(6*propDRR,0.01,0.2727)),replace=FALSE)
      }
      for (thisLoc in 8:24) {
          DRR[13:24,1] <- sample(c(rep(0,12*(1-propDRR)),runif(12*propDRR,0.01,0.2727)),replace=FALSE)
      }

      for (thisLoc in 1:numLoci) {
          # thisLoc <-2
          if (DRR[thisLoc,1] == 0) {
             DRR[thisLoc,2] <- "min"
          }
          if (DRR[thisLoc,1] != 0) {
             DRR[thisLoc,2] <- "max"
          }
      }
      return(DRR)
    }