getHetWeightHexGeno <- function (thisGenotype) {
  ##Returns the weighted heterozygosity of a genotype
    switch(length(unique(thisGenotype)),
           {##Case "aaaaaa" - alleles identical
             tt <- sort(table(thisGenotype),decreasing=TRUE)
             weight<-0
             return (weight)
           }, # End switch
           {##Case Biallele "aaaaab, aaaabb, aaabbb".
              #count table of each allele, sorted so most frequent comes first
             tt <- sort(table(thisGenotype),decreasing=TRUE)
             if (max(tt)==5) { #Biallele type I, if max no. of allele is 5 must be type I
                   weight<-0.333333
                   return (weight)
             } else if (max(tt)==4) { #Biallele type II, if max no. of allele is 4 must be type II
                   weight<-0.533333
                   return (weight)
             } else if (max(tt)==3) { #Biallele type III, if max no. of allele is 3 must be type III
                   weight<-0.6
                   return (weight)
             }
           }, # End switch
           {##Case Triallele: "aaaabc, aaabbc, aabbcc"
              tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
             if (max(tt)==4) { #Triallele type I if max no. of allele is 4 must be type I
                   weight<-0.6
                   return (weight)
             } else if (max(tt)==3) { #Triallele type II, if max no. of allele is 3 must be type II
                   weight<-0.7333333
                   return (weight)
             } else if (max(tt)==2) { #Triallele type III, if max no. of allele is 2 must be type III
                   weight<-0.8
                   return (weight)
             }
           }, # End switch
           {##Case Quadriallele: "aaabcd, aabbcd"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
             if (max(tt)==3) { #Quadriallele type I if max no. of allele is 3 must be type I
                   weight<-0.8
                   return (weight)
             } else if (max(tt)==2) { #Quadriallele type II if max no. of allele is 2 must be type II
                   weight<-0.8666666
                   return (weight)
             }  # End Quadriallele Type II
           },  # End Quadriallele switch
           {##Case Pentallele: "aabcde"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   weight<-0.9333333
                   return (weight)
           },  # End Pentallele switch
           {## Case Hexallele: "abcdef"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   weight<-1.0
                   return (weight)
             } # End Hexallele switch
           ) # End switch function
} # End function

getHetWeightHexPheno <- function (thisGenotype) {
  ##Returns the weighted heterozygosity of a genotype
    switch(length(unique(thisGenotype)),
           {##Case "aaaaaa" 
             tt <- sort(table(thisGenotype),decreasing=TRUE)
             weight<-0
             return (weight)
           }, # End switch
           {##Case Biallele "aaaaab, aaaabb, aaabbb".
              #count table of each allele, sorted so most frequent comes first
                   weight<-0.48888
                   return (weight)
           }, # End switch
           {##Case Triallele: "aaaabc, aaabbc, aabbcc"
              tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   weight<-0.71111
                   return (weight)
           }, # End switch
           {##Case Quadriallele: "aaabcd, aabbcd"
                   weight<-0.833333
                   return (weight)
               # End Quadriallele Type II
           },  # End Quadriallele switch
           {##Case Pentallele: "aabcde"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   weight<-0.9333333
                   return (weight)
           },  # End Pentallele switch
           {## Case Hexallele: "abcdef"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   weight<-1.0
                   return (weight)
             } # End Hexallele switch
           ) # End switch function
} # End function

#getHetWeightTetrGeno
