# Setup DRR for loci

DRRsetup <- function(numLoci,ploidy,propDRR) {
      DRR <- matrix(0,numLoci,2)
      rownames(DRR) <- 1:numLoci
      colnames(DRR) <- c("DRR","Simple DDR")
      DRR <- as.data.frame(DRR)
      if (ploidy == 6) {
          DRR[,1] <- sample(c(rep(0,numLoci*(1-propDRR)),runif(numLoci*propDRR,0.01,0.2727)),replace=FALSE)
      }
      if (ploidy == 4) {
          DRR[,1] <- sample(c(rep(0,numLoci*(1-propDRR)),runif(numLoci*propDRR,0.01,0.1428)),replace=FALSE)
      }
      for (thisLoc in 1:numLoci) {
          # thisLoc <-2
          if (DRR[thisLoc,1] == 0) {
             DRR[thisLoc,2] <- "min"
          }
          if (DRR[thisLoc,1] != 0) {
             DRR[thisLoc,2] <- "max"
          }
      }
      return(DRR)
    }