#####################################
#  Probability of mixed F1 genotype #
#      -For a given genotype &      #
#          population               #
#      -Hexaploid & Tetraploid      #
#      Author: David Field          #
#         1/2/2010                  #
#####################################

mixedGenotypeFreqPopHex <- function (thisGenotype,thisLocus,thisPopninCombo,thatPopninCombo,
                                     gameteFrequenciesTable,alleleFrequenciesTable,DRR,epsilon)  {
  ##########################################################
  # Hexaploid - frequency of given genotype at equilibrium #
  ##########################################################
  ##Returns the probability of a specified genotype, given a
  ##vector of gamete probabilities (popnGameteProbTable).
  ##NOTE: w112, w122, w133...(are actually =3w112, 3w122, 3w133), so must divide by 3.
  ##NOTE: y123, y124, y125...(are actually =6y123, 6y124, 6y125),so must divide by 6.
  #          thisGenotype<-possibleSeedlingGenos[[thisGeno]]
  #          thisGenotype<-c("249","249","249","249","252","271")
  #          thisPopn<-"GF"
  #          thatPopn<-"GI"
  # Special function to extract a gamate from table, but return 0 if absent
  extractGameteFreqTable <- function(gamete,gameteFrequenciesTable) {
           if (!all(gamete %in% colnames(gameteFrequenciesTable))) {
              return(0)
           } else if (all(gamete %in% colnames(gameteFrequenciesTable))) {
              gameteFreq<-gameteFrequenciesTable[[1,gamete]]
              return(gameteFreq)
           }
  }
  # Pulling out the specific gamete frequency table
  gameteFrequenciesTablePop1<-gameteFrequenciesTable[[thisPopninCombo]][[thisLocus]]
  gameteFrequenciesTablePop2<-gameteFrequenciesTable[[thatPopninCombo]][[thisLocus]]

    switch(length(unique(thisGenotype)),
           {##Case "aaaaaa" - alleles identical, so use gamete[1]...
             tt <- sort(table(thisGenotype),decreasing=TRUE)
             # gamete names
             gamp111<-paste(rep(names(tt[1]),3),collapse=" ")
             # defining frequency of each allele in pop1 & pop2
             # pop1 & pop2 gametes
             p111pop1<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop1)
             p111pop2<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop2)
             # final calculation
             return (p111pop1*p111pop2)

           }, # End switch
           {##Case Biallele "aaaaab, aaaabb, aaabbb".
              #count table of each allele, sorted so most frequent comes first
             tt <- sort(table(thisGenotype),decreasing=TRUE)
             if (max(tt)==5) { #Biallele type I, if max no. of allele is 5 must be type I
                   # gamete p111, made from repeating the name of the allele which occured 4 times
                   # alleles pasted and collapsed with a space left in between e.g. "114 114 114"
                   gamp111<-paste(rep(names(tt)[tt==5],3),collapse=" ")
                   gamw112<-paste(sort(c(rep(names(tt)[tt==5],2),names(tt)[tt==1])),collapse=" ")
                   # defining frequency of each allele in pop1 & pop2
                   # Pop1 gametes
                   p111pop1<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop1)
                   w112pop1<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop1))/3
                   # Pop2 gametes
                   p111pop2<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop2)
                   w112pop2<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop2))/3
                   # Final calculation
                   return ((3*(p111pop1*w112pop2)) + (3*(p111pop2*w112pop1)))

             } else if (max(tt)==4) { #Biallele type II, if max no. of allele is 4 must be type II
                   gamp111<-paste(rep(names(tt)[tt==4],3),collapse=" ")     #
                   gamw112<-paste(sort(c(rep(names(tt)[tt==4],2),names(tt)[tt==2])),collapse=" ")
                   gamw122<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt)[tt==4])),collapse=" ")
                   # Pop1 gametes
                   p111pop1<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop1)
                   w112pop1<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop1))/3
                   w122pop1<- (extractGameteFreqTable(gamw122,gameteFrequenciesTablePop1))/3
                   # Pop2 gametes
                   p111pop2<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop2)
                   w112pop2<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop2))/3
                   w122pop2<- (extractGameteFreqTable(gamw122,gameteFrequenciesTablePop2))/3
                   # Final calculation
                   bit1<- ((3*(p111pop1*w122pop2)) + (3*(p111pop2*w122pop1)))
                   bit2<- (9*(w112pop1*w112pop2))
                   return (bit1 + bit2)

             } else if (max(tt)==3) { #Biallele type III, if max no. of allele is 3 must be type III
                   gamp111<-paste(rep(names(tt[1]),3),collapse=" ")
                   gamq222<-paste(rep(names(tt[2]),3),collapse=" ")
                   gamw112<-paste(sort(c(rep(names(tt[1]),2),names(tt[2]))),collapse=" ")
                   gamw122<-paste(sort(c(rep(names(tt[2]),2),names(tt[1]))),collapse=" ")
                   # Pop1 gametes
                   p111pop1<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop1)
                   w112pop1<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop1))/3
                   w122pop1<- (extractGameteFreqTable(gamw122,gameteFrequenciesTablePop1))/3
                   q222pop1<- extractGameteFreqTable(gamq222,gameteFrequenciesTablePop1)
                   # Pop2 gametes
                   p111pop2<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop2)
                   w112pop2<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop2))/3
                   w122pop2<- (extractGameteFreqTable(gamw122,gameteFrequenciesTablePop2))/3
                   q222pop2<- extractGameteFreqTable(gamq222,gameteFrequenciesTablePop2)
                   # Final calculation
                   bit1<- (p111pop1*q222pop2) + (p111pop2*q222pop1)
                   bit2<- (9*(w112pop1*w122pop2)) + (9*(w112pop2*w122pop1))
                   return (bit1 + bit2)
                   
             }
           }, # End switch
           {##Case Triallele: "aaaabc, aaabbc, aabbcc"
              tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
              if (max(tt)==4) { #Triallele type I if max no. of allele is 4 must be type I
                   gamp111<-paste(rep(names(tt)[tt==4],3),collapse=" ") # gamete p111
                   gamw112<-paste(sort(c(rep(names(tt)[tt==4],2),names(tt[2]))),collapse=" ")
                   gamw113<-paste(sort(c(rep(names(tt)[tt==4],2),names(tt[3]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   # Pop1 gametes
                   p111pop1<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop1)
                   w112pop1<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop1))/3
                   w113pop1<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop1))/3
                   y123pop1<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop1))/6
                   # Pop2 gametes
                   p111pop2<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop2)
                   w112pop2<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop2))/3
                   w113pop2<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop2))/3
                   y123pop2<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop2))/6
                   # Final calculation
                   bit1<- (6*(p111pop1*y123pop2)) + (6*(p111pop2*y123pop1))
                   bit2<- (9*(w112pop1*w113pop2)) + (9*(w112pop2*w113pop1))
                   return (bit1 + bit2)

             } else if (max(tt)==3) { #Triallele type II, if max no. of allele is 3 must be type II
                   gamp111<-paste(rep(names(tt)[tt==3],3),collapse=" ")     # gamete p111
                   gamw112<-paste(sort(c(rep(names(tt)[tt==3],2),names(tt)[tt==2])),collapse=" ")
                   gamw113<-paste(sort(c(rep(names(tt)[tt==3],2),names(tt[3]))),collapse=" ")
                   gamw122<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt)[tt==3])),collapse=" ")
                   gamw223<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt[3]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   # Pop1 gametes
                   p111pop1<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop1)
                   w112pop1<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop1))/3
                   w113pop1<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop1))/3
                   w122pop1<- (extractGameteFreqTable(gamw122,gameteFrequenciesTablePop1))/3
                   w223pop1<- (extractGameteFreqTable(gamw223,gameteFrequenciesTablePop1))/3
                   y123pop1<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop1))/6
                   # Pop2 gametes
                   p111pop2<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop2)
                   w112pop2<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop2))/3
                   w113pop2<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop2))/3
                   w122pop2<- (extractGameteFreqTable(gamw122,gameteFrequenciesTablePop2))/3
                   w223pop2<- (extractGameteFreqTable(gamw223,gameteFrequenciesTablePop2))/3
                   y123pop2<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop2))/6
                   # Final calculation
                   bit1<- (3*(p111pop1*w223pop2)) + (3*(p111pop2*w223pop1))
                   bit2<- (18*(w112pop1*y123pop2)) + (18*(w112pop2*y123pop1))
                   bit3<- (9*(w113pop1*w122pop2)) + (9*(w113pop2*w122pop1))
                   return (bit1 + bit2 + bit3)

             } else if (max(tt)==2) { #Triallele type III, if max no. of allele is 2 must be type III
                   gamw112<-paste(sort(c(names(tt[1]),names(tt[1]),names(tt[2]))),collapse=" ")
                   gamw113<-paste(sort(c(names(tt[1]),names(tt[1]),names(tt[3]))),collapse=" ")
                   gamw122<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[2]))),collapse=" ")
                   gamw133<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[3]))),collapse=" ")
                   gamw223<-paste(sort(c(names(tt[2]),names(tt[2]),names(tt[3]))),collapse=" ")
                   gamw233<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[3]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   # Pop1 gametes
                   w112pop1<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop1))/3
                   w113pop1<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop1))/3
                   w133pop1<- (extractGameteFreqTable(gamw133,gameteFrequenciesTablePop1))/3
                   w122pop1<- (extractGameteFreqTable(gamw122,gameteFrequenciesTablePop1))/3
                   w223pop1<- (extractGameteFreqTable(gamw223,gameteFrequenciesTablePop1))/3
                   w233pop1<- (extractGameteFreqTable(gamw233,gameteFrequenciesTablePop1))/3
                   y123pop1<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop1))/6
                   # Pop2 gametes
                   w112pop2<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop2))/3
                   w113pop2<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop2))/3
                   w133pop2<- (extractGameteFreqTable(gamw133,gameteFrequenciesTablePop2))/3
                   w122pop2<- (extractGameteFreqTable(gamw122,gameteFrequenciesTablePop2))/3
                   w223pop2<- (extractGameteFreqTable(gamw223,gameteFrequenciesTablePop2))/3
                   w233pop2<- (extractGameteFreqTable(gamw233,gameteFrequenciesTablePop2))/3
                   y123pop2<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop2))/6
                   # final calculations
                   bit1<- (9*(w112pop1*w233pop2)) + (9*(w112pop2*w233pop1))
                   bit2<- (9*(w133pop1*w122pop2)) + (9*(w133pop2*w122pop1))
                   bit3<- (9*(w113pop1*w223pop2)) + (9*(w113pop2*w223pop1))
                   bit4<- (18*(y123pop1*y123pop2))
                   return (bit1 + bit2 + bit3 + bit4)

             }
           }, # End switch
           {##Case Quadriallele: "aaabcd, aabbcd"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
             if (max(tt)==3) { #Quadriallele type I if max no. of allele is 3 must be type I
                   gamp111<-paste(rep(names(tt)[tt==3],3),collapse=" ") # gamete p111
                   gamw112<-paste(sort(c(rep(names(tt)[tt==3],2),names(tt[2]))),collapse=" ")
                   gamw113<-paste(sort(c(rep(names(tt)[tt==3],2),names(tt[3]))),collapse=" ")
                   gamw114<-paste(sort(c(rep(names(tt)[tt==3],2),names(tt[4]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy124<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy134<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy234<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[4]))),collapse=" ")
                   # Pop1 gametes
                   p111pop1<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop1)
                   w112pop1<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop1))/3
                   w113pop1<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop1))/3
                   w114pop1<- (extractGameteFreqTable(gamw114,gameteFrequenciesTablePop1))/3
                   y123pop1<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop1))/6
                   y124pop1<- (extractGameteFreqTable(gamy124,gameteFrequenciesTablePop1))/6
                   y134pop1<- (extractGameteFreqTable(gamy134,gameteFrequenciesTablePop1))/6
                   y234pop1<- (extractGameteFreqTable(gamy234,gameteFrequenciesTablePop1))/6
                   # Pop2 gametes
                   p111pop2<- extractGameteFreqTable(gamp111,gameteFrequenciesTablePop2)
                   w112pop2<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop2))/3
                   w113pop2<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop2))/3
                   w114pop2<- (extractGameteFreqTable(gamw114,gameteFrequenciesTablePop2))/3
                   y123pop2<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop2))/6
                   y124pop2<- (extractGameteFreqTable(gamy124,gameteFrequenciesTablePop2))/6
                   y134pop2<- (extractGameteFreqTable(gamy134,gameteFrequenciesTablePop2))/6
                   y234pop2<- (extractGameteFreqTable(gamy234,gameteFrequenciesTablePop2))/6
                   # Final calculation
                   bit1<- (6*(p111pop1*y234pop2)) + (6*(p111pop2*y234pop1))
                   bit2<- (18*(w112pop1*y134pop2)) + (18*(w112pop2*y134pop1))
                   bit3<- (18*(w113pop1*y124pop2)) + (18*(w113pop2*y124pop1))
                   bit4<- (18*(w114pop1*y123pop2)) + (18*(w114pop2*y123pop1))
                   return (bit1 + bit2 + bit3 + bit4)
                   
             } else if (max(tt)==2) { #Quadriallele type II if max no. of allele is 2 must be type II
                   gamw112<-paste(sort(c(rep(names(tt[1]),2),names(tt[2]))),collapse=" ")
                   gamw113<-paste(sort(c(rep(names(tt[1]),2),names(tt[3]))),collapse=" ")
                   gamw114<-paste(sort(c(rep(names(tt[1]),2),names(tt[4]))),collapse=" ")
                   gamw122<-paste(sort(c(rep(names(tt[2]),2),names(tt[1]))),collapse=" ")
                   gamw223<-paste(sort(c(rep(names(tt[2]),2),names(tt[3]))),collapse=" ")
                   gamw224<-paste(sort(c(rep(names(tt[2]),2),names(tt[4]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy124<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy134<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy234<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[4]))),collapse=" ")
                   # Pop1 gametes
                   w112pop1<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop1))/3
                   w113pop1<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop1))/3
                   w114pop1<- (extractGameteFreqTable(gamw114,gameteFrequenciesTablePop1))/3
                   w122pop1<- (extractGameteFreqTable(gamw122,gameteFrequenciesTablePop1))/3
                   w223pop1<- (extractGameteFreqTable(gamw223,gameteFrequenciesTablePop1))/3
                   w224pop1<- (extractGameteFreqTable(gamw224,gameteFrequenciesTablePop1))/3
                   y123pop1<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop1))/6
                   y124pop1<- (extractGameteFreqTable(gamy124,gameteFrequenciesTablePop1))/6
                   y134pop1<- (extractGameteFreqTable(gamy134,gameteFrequenciesTablePop1))/6
                   y234pop1<- (extractGameteFreqTable(gamy234,gameteFrequenciesTablePop1))/6
                   # Pop2 gametes
                   w112pop2<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop2))/3
                   w113pop2<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop2))/3
                   w114pop2<- (extractGameteFreqTable(gamw114,gameteFrequenciesTablePop2))/3
                   w122pop2<- (extractGameteFreqTable(gamw122,gameteFrequenciesTablePop2))/3
                   w223pop2<- (extractGameteFreqTable(gamw223,gameteFrequenciesTablePop2))/3
                   w224pop2<- (extractGameteFreqTable(gamw224,gameteFrequenciesTablePop2))/3
                   y123pop2<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop2))/6
                   y124pop2<- (extractGameteFreqTable(gamy124,gameteFrequenciesTablePop2))/6
                   y134pop2<- (extractGameteFreqTable(gamy134,gameteFrequenciesTablePop2))/6
                   y234pop2<- (extractGameteFreqTable(gamy234,gameteFrequenciesTablePop2))/6
                   # Final calculation
                   bit1<- (18*(w112pop1*y234pop2)) + (18*(w112pop2*y234pop1))
                   bit2<- (9*(w113pop1*w224pop2)) + (9*(w113pop2*w224pop1))
                   bit3<- (9*(w114pop1*w223pop2)) + (9*(w114pop2*w223pop1))
                   bit4<- (36*(y123pop1*y124pop2)) + (36*(y123pop2*y124pop1))
                   bit5<- (18*(y134pop1*w122pop2)) + (18*(y134pop2*w122pop1))
                   return (bit1 + bit2 + bit3 + bit4 + bit5)

             }  # End Quadriallele Type II
           },  # End Quadriallele switch
           {##Case Pentallele: "aabcde"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   gamw112<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt[2]))),collapse=" ")
                   gamw113<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt[3]))),collapse=" ")
                   gamw114<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt[4]))),collapse=" ")
                   gamw115<-paste(sort(c(rep(names(tt)[tt==2],2),names(tt[5]))),collapse=" ")
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy124<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy125<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[5]))),collapse=" ")
                   gamy134<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy135<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[5]))),collapse=" ")
                   gamy145<-paste(sort(c(names(tt[1]),names(tt[4]),names(tt[5]))),collapse=" ")
                   gamy234<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy235<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[5]))),collapse=" ")
                   gamy245<-paste(sort(c(names(tt[2]),names(tt[4]),names(tt[5]))),collapse=" ")
                   gamy345<-paste(sort(c(names(tt[3]),names(tt[4]),names(tt[5]))),collapse=" ")
                   # Pop1 gametes
                   w112pop1<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop1))/3
                   w113pop1<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop1))/3
                   w114pop1<- (extractGameteFreqTable(gamw114,gameteFrequenciesTablePop1))/3
                   w115pop1<- (extractGameteFreqTable(gamw115,gameteFrequenciesTablePop1))/3
                   y123pop1<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop1))/6
                   y124pop1<- (extractGameteFreqTable(gamy124,gameteFrequenciesTablePop1))/6
                   y125pop1<- (extractGameteFreqTable(gamy125,gameteFrequenciesTablePop1))/6
                   y134pop1<- (extractGameteFreqTable(gamy134,gameteFrequenciesTablePop1))/6
                   y135pop1<- (extractGameteFreqTable(gamy135,gameteFrequenciesTablePop1))/6
                   y145pop1<- (extractGameteFreqTable(gamy145,gameteFrequenciesTablePop1))/6
                   y234pop1<- (extractGameteFreqTable(gamy234,gameteFrequenciesTablePop1))/6
                   y235pop1<- (extractGameteFreqTable(gamy235,gameteFrequenciesTablePop1))/6
                   y245pop1<- (extractGameteFreqTable(gamy245,gameteFrequenciesTablePop1))/6
                   y345pop1<- (extractGameteFreqTable(gamy345,gameteFrequenciesTablePop1))/6
                   # Pop2 gametes
                   w112pop2<- (extractGameteFreqTable(gamw112,gameteFrequenciesTablePop2))/3
                   w113pop2<- (extractGameteFreqTable(gamw113,gameteFrequenciesTablePop2))/3
                   w114pop2<- (extractGameteFreqTable(gamw114,gameteFrequenciesTablePop2))/3
                   w115pop2<- (extractGameteFreqTable(gamw115,gameteFrequenciesTablePop2))/3
                   y123pop2<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop2))/6
                   y124pop2<- (extractGameteFreqTable(gamy124,gameteFrequenciesTablePop2))/6
                   y125pop2<- (extractGameteFreqTable(gamy125,gameteFrequenciesTablePop2))/6
                   y134pop2<- (extractGameteFreqTable(gamy134,gameteFrequenciesTablePop2))/6
                   y135pop2<- (extractGameteFreqTable(gamy135,gameteFrequenciesTablePop2))/6
                   y145pop2<- (extractGameteFreqTable(gamy145,gameteFrequenciesTablePop2))/6
                   y234pop2<- (extractGameteFreqTable(gamy234,gameteFrequenciesTablePop2))/6
                   y235pop2<- (extractGameteFreqTable(gamy235,gameteFrequenciesTablePop2))/6
                   y245pop2<- (extractGameteFreqTable(gamy245,gameteFrequenciesTablePop2))/6
                   y345pop2<- (extractGameteFreqTable(gamy345,gameteFrequenciesTablePop2))/6
                   # Final calculation
                   bit1<- (18*(w112pop1*y345pop2)) + (18*(w112pop2*y345pop1))
                   bit2<- (18*(w113pop1*y245pop2)) + (18*(w113pop2*y245pop1))
                   bit3<- (18*(w114pop1*y235pop2)) + (18*(w114pop2*y235pop1))
                   bit4<- (18*(w115pop1*y234pop2)) + (18*(w115pop2*y234pop1))
                   bit5<- (36*(y123pop1*y145pop2)) + (36*(y123pop2*y145pop1))
                   bit6<- (36*(y134pop1*y125pop2)) + (36*(y134pop2*y125pop1))
                   bit7<- (36*(y124pop1*y135pop2)) + (36*(y124pop2*y135pop1))
                   return (bit1 + bit2 + bit3 + bit4 + bit5 + bit6 + bit7)

           },  # End Pentallele switch
           {## Case Hexallele: "abcdef"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   gamy123<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy124<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy125<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[5]))),collapse=" ")
                   gamy126<-paste(sort(c(names(tt[1]),names(tt[2]),names(tt[6]))),collapse=" ")
                   gamy134<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy135<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[5]))),collapse=" ")
                   gamy136<-paste(sort(c(names(tt[1]),names(tt[3]),names(tt[6]))),collapse=" ")
                   gamy145<-paste(sort(c(names(tt[1]),names(tt[4]),names(tt[5]))),collapse=" ")
                   gamy146<-paste(sort(c(names(tt[1]),names(tt[4]),names(tt[6]))),collapse=" ")
                   gamy156<-paste(sort(c(names(tt[1]),names(tt[5]),names(tt[6]))),collapse=" ")
                   gamy234<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[4]))),collapse=" ")
                   gamy235<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[5]))),collapse=" ")
                   gamy236<-paste(sort(c(names(tt[2]),names(tt[3]),names(tt[6]))),collapse=" ")
                   gamy245<-paste(sort(c(names(tt[2]),names(tt[4]),names(tt[5]))),collapse=" ")
                   gamy246<-paste(sort(c(names(tt[2]),names(tt[4]),names(tt[6]))),collapse=" ")
                   gamy256<-paste(sort(c(names(tt[2]),names(tt[5]),names(tt[6]))),collapse=" ")
                   gamy345<-paste(sort(c(names(tt[3]),names(tt[4]),names(tt[5]))),collapse=" ")
                   gamy346<-paste(sort(c(names(tt[3]),names(tt[4]),names(tt[6]))),collapse=" ")
                   gamy356<-paste(sort(c(names(tt[3]),names(tt[5]),names(tt[6]))),collapse=" ")
                   gamy456<-paste(sort(c(names(tt[4]),names(tt[5]),names(tt[6]))),collapse=" ")
                   # Pop1 gametes
                   y123pop1<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop1))/6
                   y124pop1<- (extractGameteFreqTable(gamy124,gameteFrequenciesTablePop1))/6
                   y125pop1<- (extractGameteFreqTable(gamy125,gameteFrequenciesTablePop1))/6
                   y126pop1<- (extractGameteFreqTable(gamy126,gameteFrequenciesTablePop1))/6
                   y134pop1<- (extractGameteFreqTable(gamy134,gameteFrequenciesTablePop1))/6
                   y135pop1<- (extractGameteFreqTable(gamy135,gameteFrequenciesTablePop1))/6
                   y136pop1<- (extractGameteFreqTable(gamy136,gameteFrequenciesTablePop1))/6
                   y145pop1<- (extractGameteFreqTable(gamy145,gameteFrequenciesTablePop1))/6
                   y146pop1<- (extractGameteFreqTable(gamy146,gameteFrequenciesTablePop1))/6
                   y156pop1<- (extractGameteFreqTable(gamy156,gameteFrequenciesTablePop1))/6
                   y234pop1<- (extractGameteFreqTable(gamy234,gameteFrequenciesTablePop1))/6
                   y235pop1<- (extractGameteFreqTable(gamy235,gameteFrequenciesTablePop1))/6
                   y236pop1<- (extractGameteFreqTable(gamy236,gameteFrequenciesTablePop1))/6
                   y245pop1<- (extractGameteFreqTable(gamy245,gameteFrequenciesTablePop1))/6
                   y246pop1<- (extractGameteFreqTable(gamy246,gameteFrequenciesTablePop1))/6
                   y256pop1<- (extractGameteFreqTable(gamy256,gameteFrequenciesTablePop1))/6
                   y345pop1<- (extractGameteFreqTable(gamy345,gameteFrequenciesTablePop1))/6
                   y346pop1<- (extractGameteFreqTable(gamy346,gameteFrequenciesTablePop1))/6
                   y356pop1<- (extractGameteFreqTable(gamy356,gameteFrequenciesTablePop1))/6
                   y456pop1<- (extractGameteFreqTable(gamy456,gameteFrequenciesTablePop1))/6
                   # Pop2 gametes
                   y123pop2<- (extractGameteFreqTable(gamy123,gameteFrequenciesTablePop2))/6
                   y124pop2<- (extractGameteFreqTable(gamy124,gameteFrequenciesTablePop2))/6
                   y125pop2<- (extractGameteFreqTable(gamy125,gameteFrequenciesTablePop2))/6
                   y126pop2<- (extractGameteFreqTable(gamy126,gameteFrequenciesTablePop2))/6
                   y134pop2<- (extractGameteFreqTable(gamy134,gameteFrequenciesTablePop2))/6
                   y135pop2<- (extractGameteFreqTable(gamy135,gameteFrequenciesTablePop2))/6
                   y136pop2<- (extractGameteFreqTable(gamy136,gameteFrequenciesTablePop2))/6
                   y145pop2<- (extractGameteFreqTable(gamy145,gameteFrequenciesTablePop2))/6
                   y146pop2<- (extractGameteFreqTable(gamy146,gameteFrequenciesTablePop2))/6
                   y156pop2<- (extractGameteFreqTable(gamy156,gameteFrequenciesTablePop2))/6
                   y234pop2<- (extractGameteFreqTable(gamy234,gameteFrequenciesTablePop2))/6
                   y235pop2<- (extractGameteFreqTable(gamy235,gameteFrequenciesTablePop2))/6
                   y236pop2<- (extractGameteFreqTable(gamy236,gameteFrequenciesTablePop2))/6
                   y245pop2<- (extractGameteFreqTable(gamy245,gameteFrequenciesTablePop2))/6
                   y246pop2<- (extractGameteFreqTable(gamy246,gameteFrequenciesTablePop2))/6
                   y256pop2<- (extractGameteFreqTable(gamy256,gameteFrequenciesTablePop2))/6
                   y345pop2<- (extractGameteFreqTable(gamy345,gameteFrequenciesTablePop2))/6
                   y346pop2<- (extractGameteFreqTable(gamy346,gameteFrequenciesTablePop2))/6
                   y356pop2<- (extractGameteFreqTable(gamy356,gameteFrequenciesTablePop2))/6
                   y456pop2<- (extractGameteFreqTable(gamy456,gameteFrequenciesTablePop2))/6
                   # Final calculation
                   bit1<- (36*(y123pop1*y456pop2)) + (36*(y123pop2*y456pop1))
                   bit2<- (36*(y124pop1*y356pop2)) + (36*(y124pop2*y356pop1))
                   bit3<- (36*(y125pop1*y346pop2)) + (36*(y125pop2*y346pop1))
                   bit4<- (36*(y126pop1*y345pop2)) + (36*(y126pop2*y345pop1))
                   bit5<- (36*(y134pop1*y256pop2)) + (36*(y134pop2*y256pop1))
                   bit6<- (36*(y135pop1*y246pop2)) + (36*(y135pop2*y246pop1))
                   bit7<- (36*(y136pop1*y245pop2)) + (36*(y136pop2*y245pop1))
                   bit8<- (36*(y145pop1*y236pop2)) + (36*(y145pop2*y236pop1))
                   bit9<- (36*(y146pop1*y235pop2)) + (36*(y146pop2*y235pop1))
                   bit10<- (36*(y234pop1*y156pop2)) + (36*(y234pop2*y156pop1))
                   return (bit1 + bit2 + bit3 + bit4 + bit5 + bit6 + bit7 + bit8 + bit9 + bit10)
             } # End Hexallele switch
           ) # End switch function
} # End getProbGenotypeGivenPopnHex function

# test zone
#          gameteFrequenciesTable<-gameteFrequenciesTable[[thisPopn]][[thisLocus]]
#          thisGenotype<-c("246","246","249","249")
#


mixedGenotypeFreqPopTetr <- function (thisGenotype,thisLocus,thisPopninCombo,thatPopninCombo,gameteFrequenciesTable,DRR,epsilon) {
  ###########################################################
  # Tetraploid - probability of given genotype being an     #
  #                F1 hybrid between two populations        #
  ###########################################################

  #          thisGenotype<-possibleSeedlingGenos[[thisGeno]]
  #          thisGenotype<-c("249","255","267","270")
  #          thisPopn<-"GF"
  #          thatPopn<-"GI"
  # Special function to extract a gamate from table, but return 0 if absent
  extractGameteFreqTable<- function(gamete,gameteFrequenciesTable) {
           if (!all(gamete %in% colnames(gameteFrequenciesTable))) {
              return(0)
           } else if (all(gamete %in% colnames(gameteFrequenciesTable))) {
              gameteFreq<-gameteFrequenciesTable[[1,gamete]]
              return(gameteFreq)
           }
  }
  # Pulling out the specific gamete frequency table
  gameteFrequenciesTablePop1<-gameteFrequenciesTable[[thisPopninCombo]][[thisLocus]]
  gameteFrequenciesTablePop2<-gameteFrequenciesTable[[thatPopninCombo]][[thisLocus]]

  ## Returns the probability of a specified F1 genotype, given seedling genotype and
  # gamete frequencies in each population
  ##NOTE: y12 from gamete frequencies table is actually = 2y12 (so must divide by 2 to get y12)
    switch(length(unique(thisGenotype)),
           {##Case "aaaa" - alleles identical, so use gamete[1]...
             tt <- sort(table(thisGenotype),decreasing=TRUE)
             # defining gamete alleles
             gamp11<-paste(rep(names(tt[1]),2),collapse=" ")
             # defining frequency of each allele in pop1 & pop2
             p11pop1<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop1)
             p11pop2<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop2)
             return (p11pop1*p11pop2)
           }, # End switch
           {##Case Biallele "aaab, aabb, abbb".
              #count table of each allele, sorted so most frequent comes first
             tt <- sort(table(thisGenotype),decreasing=TRUE)
             if (max(tt)==3) { #Biallele type I, if max no. of allele is 3 must be type I
                   # gamete p11, made from repeating the name of the allele which occured 2 times
                   # alleles pasted and collapsed with a space left in between e.g. "114 114"
                   gamp11<-paste(rep(names(tt)[tt==3],2),collapse=" ")
                   gamy12<-paste(sort(c(rep(names(tt)[tt==3],1),names(tt)[tt==1])),collapse=" ")
                   # defining frequency of each allele in pop1 & pop2
                   # Pop1 gametes
                   p11pop1<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop1)
                   y12pop1<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop1))/2
                   # Pop2 gametes
                   p11pop2<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop2)
                   y12pop2<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop2))/2
                   # calculating sections of formula
                   bit1<- (2*(p11pop1*y12pop2)) 
                   bit2<- (2*(p11pop2*y12pop1))
                   # returning final answer
                   return (bit1 + bit2)

             } else if (max(tt)==2) { #Biallele type II, if max no. of allele is 2 must be type II
                   gamp11<-paste(rep(names(tt[1]),2),collapse=" ")
                   gamz22<-paste(rep(names(tt[2]),2),collapse=" ")
                   gamy12<-paste(sort(c(names(tt[1]),names(tt[2]))),collapse=" ")
                   # defining frequency of each allele in pop1 & pop2
                   # Pop1 gametes
                   p11pop1<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop1)
                   y12pop1<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop1))/2
                   z22pop1<- extractGameteFreqTable(gamz22,gameteFrequenciesTablePop1)
                   # Pop2 gametes
                   p11pop2<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop2)
                   y12pop2<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop2))/2
                   z22pop2<- extractGameteFreqTable(gamz22,gameteFrequenciesTablePop2)
                   # calculating sections of formula
                   bit1<- (4*y12pop1*y12pop2)
                   bit2<- (p11pop1*z22pop2) + (p11pop1*z22pop2)
                   # returning final answer
                   return (bit1 + bit2)
             }
           }, # End biallele switch
           {##Case Triallele: "aabc"
              tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   # defining gamete alleles
                   gamp11<-paste(rep(names(tt)[tt==2],2),collapse=" ") # gamete p11
                   gamy12<-paste(sort(c(rep(names(tt)[tt==2],1),names(tt[2]))),collapse=" ")
                   gamy13<-paste(sort(c(rep(names(tt)[tt==2],1),names(tt[3]))),collapse=" ")
                   gamy23<-paste(sort(c(names(tt[2]),names(tt[3]))),collapse=" ")
                   # defining frequency of each allele in pop1 & pop2
                   # Pop1 gametes
                   p11pop1<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop1)
                   y12pop1<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop1))/2
                   y13pop1<- (extractGameteFreqTable(gamy13,gameteFrequenciesTablePop1))/2
                   y23pop1<- (extractGameteFreqTable(gamy23,gameteFrequenciesTablePop1))/2
                   # Pop2 gametes
                   p11pop2<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop2)
                   y12pop2<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop2))/2
                   y13pop2<- (extractGameteFreqTable(gamy13,gameteFrequenciesTablePop2))/2
                   y23pop2<- (extractGameteFreqTable(gamy23,gameteFrequenciesTablePop2))/2
                   # calculating sections of formula
                   bit1<-(2*(p11pop1*y23pop2)) + (2*(p11pop2*y23pop1))
                   bit2<-(4*(y12pop1*y13pop2)) + (4*(y12pop2*y13pop1))
                   # returning final answer
                   return (bit1 + bit2)

           }, # End triallele switch
           {##Case Quadriallele: "abcd"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   # defining gamete alleles
                   gamy12<-paste(sort(c(names(tt[1]),names(tt[2]))),collapse=" ")
                   gamy13<-paste(sort(c(names(tt[1]),names(tt[3]))),collapse=" ")
                   gamy14<-paste(sort(c(names(tt[1]),names(tt[4]))),collapse=" ")
                   gamy23<-paste(sort(c(names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy24<-paste(sort(c(names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy34<-paste(sort(c(names(tt[3]),names(tt[4]))),collapse=" ")
                   # defining frequency of each allele in pop1 & pop2
                   # Pop1 gametes
                   y12pop1<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop1))/2
                   y13pop1<- (extractGameteFreqTable(gamy13,gameteFrequenciesTablePop1))/2
                   y14pop1<- (extractGameteFreqTable(gamy14,gameteFrequenciesTablePop1))/2
                   y23pop1<- (extractGameteFreqTable(gamy23,gameteFrequenciesTablePop1))/2
                   y24pop1<- (extractGameteFreqTable(gamy24,gameteFrequenciesTablePop1))/2
                   y34pop1<- (extractGameteFreqTable(gamy34,gameteFrequenciesTablePop1))/2
                   # Pop2 gametes
                   y12pop2<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop2))/2
                   y13pop2<- (extractGameteFreqTable(gamy13,gameteFrequenciesTablePop2))/2
                   y14pop2<- (extractGameteFreqTable(gamy14,gameteFrequenciesTablePop2))/2
                   y23pop2<- (extractGameteFreqTable(gamy23,gameteFrequenciesTablePop2))/2
                   y24pop2<- (extractGameteFreqTable(gamy24,gameteFrequenciesTablePop2))/2
                   y34pop2<- (extractGameteFreqTable(gamy34,gameteFrequenciesTablePop2))/2
                   # calculating sections of formula
                   bit1<-(4*(y12pop1*y34pop2)) + (4*(y12pop2*y34pop1))
                   bit2<-(4*(y13pop1*y24pop2)) + (4*(y13pop2*y24pop1))
                   bit3<-(4*(y14pop1*y23pop2)) + (4*(y14pop2*y23pop1))
                   # returning final answer
                   return (bit1 + bit2 + bit3)
             } # End Quadriallele switch
           ) # End switch function
} # End function
