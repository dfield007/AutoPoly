#' returns probability of genotypes given a population of genotypes for a tetraploid population
#'
#' @return procudes a list with genotype probabilities for each population and locus
#' @author David L. Field
#' @export
genotypeFreqPopTetr <- function (thisGenotype,gameteFrequenciesTable,alleleFrequenciesTable,DRR,epsilon) {
  # tetraploid
  # First screening if alleles missing in population
  thisGenotypesAlleles<-unique(thisGenotype)
  popAlleles<-names(alleleFrequenciesTable)
  # if (!all(thisGenotypesAlleles %in% popAlleles)) {
  # ## If father gamete alleles are not present at all in the population:
  # return(epsilon)
  # }
  
  ##Returns the probability of a specified genotype, given a
  ##vector of gamete frequencies
  ##NOTE: y12 from gamete frequencies table is actually = 2y12 (so must divide by 2 to get y12)
    switch(length(unique(thisGenotype)),
           {##Case "aaaa" - alleles identical, so use gamete[1]...
             tt <- sort(table(thisGenotype),decreasing=TRUE)
             gamp11<-paste(rep(names(tt[1]),2),collapse=" ")
             p11<-gameteFrequenciesTable[[1,gamp11]]
             return (p11^2)
           }, # End switch
           {##Case Biallele "aaab, aabb, abbb".
              #count table of each allele, sorted so most frequent comes first
             tt <- sort(table(thisGenotype),decreasing=TRUE)
             if (max(tt)==3) { #Biallele type I, if max no. of allele is 3 must be type I
                   # gamete p11, made from repeating the name of the allele which occured 2 times
                   # alleles pasted and collapsed with a space left in between e.g. "114 114"
                   gamp11<-paste(rep(names(tt)[tt==3],2),collapse=" ")
                   gamy12<-paste(sort(c(rep(names(tt)[tt==3],1),names(tt)[tt==1])),collapse=" ")
                   # extract the probability of a gamete from table and send to object
                   p11<-gameteFrequenciesTable[[1,gamp11]]
                   y12<-(gameteFrequenciesTable[[1,gamy12]])/2
                   #expected frequency of genotype at equilibrium
                   return (4*(p11*y12))

             } else if (max(tt)==2) { #Biallele type II, if max no. of allele is 2 must be type II
                   gamp11<-paste(rep(names(tt[1]),2),collapse=" ")
                   gamz22<-paste(rep(names(tt[2]),2),collapse=" ")
                   gamy12<-paste(sort(c(names(tt[1]),names(tt[2]))),collapse=" ")
                   p11<-gameteFrequenciesTable[[1,gamp11]]
                   y12<-(gameteFrequenciesTable[[1,gamy12]])/2
                   z22<-(gameteFrequenciesTable[[1,gamz22]])
                   return ((4*((y12)^2)) + (2*(p11*z22)))
             }
           }, # End biallele switch
           {##Case Triallele: "aabc"
              tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   gamp11<-paste(rep(names(tt)[tt==2],2),collapse=" ") # gamete p11
                   gamy12<-paste(sort(c(rep(names(tt)[tt==2],1),names(tt[2]))),collapse=" ")
                   gamy13<-paste(sort(c(rep(names(tt)[tt==2],1),names(tt[3]))),collapse=" ")
                   gamy23<-paste(sort(c(names(tt[2]),names(tt[3]))),collapse=" ")
                   p11<-gameteFrequenciesTable[[1,gamp11]]
                   y12<-(gameteFrequenciesTable[[1,gamy12]])/2
                   y13<-(gameteFrequenciesTable[[1,gamy13]])/2
                   y23<-(gameteFrequenciesTable[[1,gamy23]])/2
                   return ((4*(p11*y23)) + (8*(y12*y13)))
           }, # End triallele switch
           {##Case Quadriallele: "abcd"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   gamy12<-paste(sort(c(names(tt[1]),names(tt[2]))),collapse=" ")
                   gamy13<-paste(sort(c(names(tt[1]),names(tt[3]))),collapse=" ")
                   gamy14<-paste(sort(c(names(tt[1]),names(tt[4]))),collapse=" ")
                   gamy23<-paste(sort(c(names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy24<-paste(sort(c(names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy34<-paste(sort(c(names(tt[3]),names(tt[4]))),collapse=" ")
                   y12<-(gameteFrequenciesTable[[1,gamy12]])/2
                   y13<-(gameteFrequenciesTable[[1,gamy13]])/2
                   y14<-(gameteFrequenciesTable[[1,gamy14]])/2
                   y23<-(gameteFrequenciesTable[[1,gamy23]])/2
                   y24<-(gameteFrequenciesTable[[1,gamy24]])/2
                   y34<-(gameteFrequenciesTable[[1,gamy34]])/2
                   return ((8*(y12*y34)) + (8*(y13*y24)) + (8*(y14*y23)))
             } # End Quadriallele switch
           ) # End switch function
} # End function
