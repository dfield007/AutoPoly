#' returns probability of mixed F1 genotype from a tetraploid
#'
#' @export
mixedGenotypeFreqPopTetr <- function (thisGenotype,thisLocus,thisPopninCombo,thatPopninCombo,gameteFrequenciesTable,epsilon) {
  # Tetraploid - probability of given genotype being an
  #                F1 hybrid between two populations

  # Special function to extract a gamate from table, but return 0 if absent
  extractGameteFreqTable<- function(gamete,gameteFrequenciesTable) {
           if (!all(gamete %in% colnames(gameteFrequenciesTable))) {
              return(0)
           } else if (all(gamete %in% colnames(gameteFrequenciesTable))) {
              gameteFreq<-gameteFrequenciesTable[[1,gamete]]
              return(gameteFreq)
           }
  }
  # Pulling out the specific gamete frequency table
  gameteFrequenciesTablePop1<-gameteFrequenciesTable[[thisPopninCombo]][[thisLocus]]
  gameteFrequenciesTablePop2<-gameteFrequenciesTable[[thatPopninCombo]][[thisLocus]]

  ## Returns the probability of a specified F1 genotype, given seedling genotype and
  # gamete frequencies in each population
  ##NOTE: y12 from gamete frequencies table is actually = 2y12 (so must divide by 2 to get y12)
    switch(length(unique(thisGenotype)),
           {##Case "aaaa" - alleles identical, so use gamete[1]...
             tt <- sort(table(thisGenotype),decreasing=TRUE)
             # defining gamete alleles
             gamp11<-paste(rep(names(tt[1]),2),collapse=" ")
             # defining frequency of each allele in pop1 & pop2
             p11pop1<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop1)
             p11pop2<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop2)
             return (p11pop1*p11pop2)
           }, # End switch
           {##Case Biallele "aaab, aabb, abbb".
              #count table of each allele, sorted so most frequent comes first
             tt <- sort(table(thisGenotype),decreasing=TRUE)
             if (max(tt)==3) { #Biallele type I, if max no. of allele is 3 must be type I
                   # gamete p11, made from repeating the name of the allele which occured 2 times
                   # alleles pasted and collapsed with a space left in between e.g. "114 114"
                   gamp11<-paste(rep(names(tt)[tt==3],2),collapse=" ")
                   gamy12<-paste(sort(c(rep(names(tt)[tt==3],1),names(tt)[tt==1])),collapse=" ")
                   # defining frequency of each allele in pop1 & pop2
                   # Pop1 gametes
                   p11pop1<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop1)
                   y12pop1<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop1))/2
                   # Pop2 gametes
                   p11pop2<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop2)
                   y12pop2<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop2))/2
                   # calculating sections of formula
                   bit1<- (2*(p11pop1*y12pop2))
                   bit2<- (2*(p11pop2*y12pop1))
                   # returning final answer
                   return (bit1 + bit2)

             } else if (max(tt)==2) { #Biallele type II, if max no. of allele is 2 must be type II
                   gamp11<-paste(rep(names(tt[1]),2),collapse=" ")
                   gamz22<-paste(rep(names(tt[2]),2),collapse=" ")
                   gamy12<-paste(sort(c(names(tt[1]),names(tt[2]))),collapse=" ")
                   # defining frequency of each allele in pop1 & pop2
                   # Pop1 gametes
                   p11pop1<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop1)
                   y12pop1<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop1))/2
                   z22pop1<- extractGameteFreqTable(gamz22,gameteFrequenciesTablePop1)
                   # Pop2 gametes
                   p11pop2<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop2)
                   y12pop2<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop2))/2
                   z22pop2<- extractGameteFreqTable(gamz22,gameteFrequenciesTablePop2)
                   # calculating sections of formula
                   bit1<- (4*y12pop1*y12pop2)
                   bit2<- (p11pop1*z22pop2) + (p11pop1*z22pop2)
                   # returning final answer
                   return (bit1 + bit2)
             }
           }, # End biallele switch
           {##Case Triallele: "aabc"
              tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   # defining gamete alleles
                   gamp11<-paste(rep(names(tt)[tt==2],2),collapse=" ") # gamete p11
                   gamy12<-paste(sort(c(rep(names(tt)[tt==2],1),names(tt[2]))),collapse=" ")
                   gamy13<-paste(sort(c(rep(names(tt)[tt==2],1),names(tt[3]))),collapse=" ")
                   gamy23<-paste(sort(c(names(tt[2]),names(tt[3]))),collapse=" ")
                   # defining frequency of each allele in pop1 & pop2
                   # Pop1 gametes
                   p11pop1<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop1)
                   y12pop1<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop1))/2
                   y13pop1<- (extractGameteFreqTable(gamy13,gameteFrequenciesTablePop1))/2
                   y23pop1<- (extractGameteFreqTable(gamy23,gameteFrequenciesTablePop1))/2
                   # Pop2 gametes
                   p11pop2<- extractGameteFreqTable(gamp11,gameteFrequenciesTablePop2)
                   y12pop2<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop2))/2
                   y13pop2<- (extractGameteFreqTable(gamy13,gameteFrequenciesTablePop2))/2
                   y23pop2<- (extractGameteFreqTable(gamy23,gameteFrequenciesTablePop2))/2
                   # calculating sections of formula
                   bit1<-(2*(p11pop1*y23pop2)) + (2*(p11pop2*y23pop1))
                   bit2<-(4*(y12pop1*y13pop2)) + (4*(y12pop2*y13pop1))
                   # returning final answer
                   return (bit1 + bit2)

           }, # End triallele switch
           {##Case Quadriallele: "abcd"
             tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
                   # defining gamete alleles
                   gamy12<-paste(sort(c(names(tt[1]),names(tt[2]))),collapse=" ")
                   gamy13<-paste(sort(c(names(tt[1]),names(tt[3]))),collapse=" ")
                   gamy14<-paste(sort(c(names(tt[1]),names(tt[4]))),collapse=" ")
                   gamy23<-paste(sort(c(names(tt[2]),names(tt[3]))),collapse=" ")
                   gamy24<-paste(sort(c(names(tt[2]),names(tt[4]))),collapse=" ")
                   gamy34<-paste(sort(c(names(tt[3]),names(tt[4]))),collapse=" ")
                   # defining frequency of each allele in pop1 & pop2
                   # Pop1 gametes
                   y12pop1<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop1))/2
                   y13pop1<- (extractGameteFreqTable(gamy13,gameteFrequenciesTablePop1))/2
                   y14pop1<- (extractGameteFreqTable(gamy14,gameteFrequenciesTablePop1))/2
                   y23pop1<- (extractGameteFreqTable(gamy23,gameteFrequenciesTablePop1))/2
                   y24pop1<- (extractGameteFreqTable(gamy24,gameteFrequenciesTablePop1))/2
                   y34pop1<- (extractGameteFreqTable(gamy34,gameteFrequenciesTablePop1))/2
                   # Pop2 gametes
                   y12pop2<- (extractGameteFreqTable(gamy12,gameteFrequenciesTablePop2))/2
                   y13pop2<- (extractGameteFreqTable(gamy13,gameteFrequenciesTablePop2))/2
                   y14pop2<- (extractGameteFreqTable(gamy14,gameteFrequenciesTablePop2))/2
                   y23pop2<- (extractGameteFreqTable(gamy23,gameteFrequenciesTablePop2))/2
                   y24pop2<- (extractGameteFreqTable(gamy24,gameteFrequenciesTablePop2))/2
                   y34pop2<- (extractGameteFreqTable(gamy34,gameteFrequenciesTablePop2))/2
                   # calculating sections of formula
                   bit1<-(4*(y12pop1*y34pop2)) + (4*(y12pop2*y34pop1))
                   bit2<-(4*(y13pop1*y24pop2)) + (4*(y13pop2*y24pop1))
                   bit3<-(4*(y14pop1*y23pop2)) + (4*(y14pop2*y23pop1))
                   # returning final answer
                   return (bit1 + bit2 + bit3)
             } # End Quadriallele switch
           ) # End switch function
} # End function
