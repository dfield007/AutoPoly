#' routine for generating simulated genotypes (mother known).
#'
#'Called from : \code{\link{simAssignmentMums}} and \code{\link{simAssignment}}
#' @return procudes a dataframe of simulated multilocus genotypes
#' @author David L. Field
#' @export
simulateGenosMotherKnown <- function(inData, alleleFrequencies,gameteFrequencies,
                            DRRtable,DRRtype,ploidy, marker, numLoci,simMissLoci,selfing,errorRate1,
                            numAdultsSim,numMothersSim,numOffspringSim,
                            fixMothersSim, immRateSim) {

  cat("\n         Simulating Genotypes....")
  # Initial setup of functions depending on ploidy
  #cat("\n ** Beginning Simulations.... **\n")
  flush.console()
  if (ploidy==6) {
    getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
  }
  if (ploidy==4) {
    getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
    mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
    getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
    gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
  }

  strip.NAs <- function(vv) {
    return(vv[!is.na(vv)])
  }
  if (ploidy == 6) {
    MAXSEEDLINGGENOTYPES <- 10
  } else if (ploidy == 4) {
    MAXSEEDLINGGENOTYPES <- 3
  }

  #  Setup objects to receive data #
  allPopns <- unique(inData$pop)
  numPopns <- length(allPopns)
  allMothers <- with(inData,unique(strip.NAs(mother)))
  allSeedlings <- with(inData,unique(ID[!is.na(mother)]))
  popnsWithMothers <- unique(with(inData,pop[ID %in% allMothers]))

  ##Strip out the seedlings, leaving adults and mothers:
  inDataAdults <- subset(inData,subset=is.na(mother))
  numAdults <-nrow(inDataAdults)

  ## Add additional column to inDataAdults
  newOne <- matrix(0,nrow(inDataAdults),1)
  colnames(newOne) <- "ActualCross"
  inDataAdults <- cbind(inDataAdults,newOne)

  ## Matrix for simulated adults and mothers
  simAdults <- matrix(0,(numAdultsSim*numPopns),ncol(inDataAdults))
  colnames(simAdults) <- colnames(inDataAdults)

  ## Matrix for simulated progeny
  simCrosses <- matrix(0,numOffspringSim,ncol(inDataAdults))
  colnames(simCrosses)<- colnames(inDataAdults)

  ## Number of simulations per mother
  if (fixMothersSim == TRUE) {
    totalMothers <- length(popnsWithMothers)*numMothersSim
    numSimsPerMum <- as.integer(numOffspringSim/totalMothers)
  }
  if (fixMothersSim == FALSE) {
    totalMothers <- numPopns*numMothersSim
    numSimsPerMum <- as.integer(numOffspringSim/totalMothers)
  }
  if (selfing==0) {
    numSimsPerMumOutcrossed <- numSimsPerMum
    numSimsPerMumSelfed <- 0
  }
  if (selfing>0) {
    numSimsPerMumOutcrossed <- as.integer(numSimsPerMum*(1-selfing))
    numSimsPerMumSelfed <- numSimsPerMum - numSimsPerMumOutcrossed
  }

  # Make simulated population #
  ## Begin loop over populations #
  flag <- 0
  for (thisPopn in allPopns) {
    # thisPopn <- "GA"
    # Sampling of outcrossed genotypes  #
    # simulated progeny ID labels for outcrossed progeny
    SimAdults <- flag + (1:(numAdultsSim))

    ##########################
    ## Begin loop over loci ##
    ##########################
    for (thisLocus in 1:numLoci) {
      # thisLocus<-1
      ##current locus
      locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy

      ##################################
      # Making genotypes from homepop ##
      ##################################
      thisHomePopn.Gametes <- as.vector(colnames(gameteFrequencies[[thisPopn]][[thisLocus]]))
      thisHomePopn.Probs <- as.vector(gameteFrequencies[[thisPopn]][[thisLocus]])
      thisHomePopn.sample1 <- sample(thisHomePopn.Gametes,numAdultsSim,replace=TRUE,thisHomePopn.Probs)
      thisHomePopn.sample1 <- t(matrix(unlist(strsplit(thisHomePopn.sample1," ")),ploidy/2,length(thisHomePopn.sample1)))
      thisHomePopn.sample2 <- sample(thisHomePopn.Gametes,numAdultsSim,replace=TRUE,thisHomePopn.Probs)
      thisHomePopn.sample2 <- t(matrix(unlist(strsplit(thisHomePopn.sample2," ")),ploidy/2,length(thisHomePopn.sample2)))
      # Cobine sampled gametes
      newAdults <- cbind(thisHomePopn.sample1,thisHomePopn.sample2)
      # send to dataframe
      simAdults[SimAdults,locusRange]<- newAdults
      simAdults[SimAdults,"pop"] <- thisPopn
      #simAdults[SimProgeny,"mother"] <- "u"
      simAdults[SimAdults,"ID"] <- paste(SimAdults,paste("A",thisPopn,sep="_"),sep="")
      #simAdults[SimAdults,"ActualCross"] <- paste(thisPopn,randomPopns,sep=" ")
      # clear out
      newAdults <- NULL
      thisHomePopn.sample1 <- NULL
      thisHomePopn.sample2 <- NULL
    } # end locus loop
    # Increase flag ready for next population
    flag <- max(SimAdults)

  } # end population loop

  # Pick out mothers at random #
  newMothers <- NULL
  if (fixMothersSim == TRUE) {
    for (thisPop in popnsWithMothers) {
      # thisPop <- "GA"
      thisPopData <- simAdults[simAdults[,"pop"] == thisPop,]
      mothers <- sample(thisPopData[,"ID"],numMothersSim)
      newMothers <- c(newMothers,mothers)
    }
  }
  if (fixMothersSim == FALSE) {
    for (thisPop in allPopns) {
      # thisPop <- "GA"
      thisPopData <- simAdults[simAdults[,"pop"] == thisPop,]
      mothers <- sample(thisPopData[,"ID"],numMothersSim)
      newMothers <- c(newMothers,mothers)
    }
  }

  simAdults <- as.data.frame(simAdults)

  # Simulating new offspring #
  ## Begin loop over mothers
  flag <- 0

  for (thisMother in newMothers) {
    # thisMother <-"40A_GA"
    if (selfing>0) {
      ################################
      # Sampling of selfed genotypes #
      ################################
      # simulated progeny ID labels for selfed individuals
      SimProgeny <- flag + (1:(numSimsPerMumSelfed))

      ## Begin loop over loci ##
      for (thisLocus in 1:numLoci) {
        # thisLocus <- 1
        # Current locus column range
        locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
        # Fixed DRR #
        # Temporarily change marker type for simulations
        marker <- "genotype"

        if (DRRtype == "fixed") {
          DRR <- DRRtable[thisLocus,2]
          # Pull out functions for particular DRR at this locus
          if (ploidy==6){
            if (marker == "genotype") {
              if (DRR == "min") {
                getMotherGameteInfo <- getMotherGameteInfoHexGenoMin # segregation ratios: gametes from individual
              } else if (DRR == "max") {
                getMotherGameteInfo <- getMotherGameteInfoHexGenoMax # segregation ratios: gametes from individual
              }
            }
            if (marker == "phenotype") {
              if (DRR == "min") {
                getMotherGameteInfo <- getMotherGameteInfoHexPhenoMin # segregation ratios: gametes from individual
              } else if (DRR == "max") {
                getMotherGameteInfo <- getMotherGameteInfoHexPhenoMax # segregation ratios: gametes from individual
              }
            }
          }
          if (ploidy==4) {
            if (marker == "genotype") {
              if (DRR == "min") {
                getMotherGameteInfo <- getMotherGameteInfoTetrGenoMin # segregation ratios: gametes from individual
              } else if (DRR == "max") {
                getMotherGameteInfo <- getMotherGameteInfoTetrGenoMax # segregation ratios: gametes from individual
              }
            }
            if (marker == "phenotype") {
              if (DRR == "min") {
                getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMin # segregation ratios: gametes from individual
              } else if (DRR == "max") {
                getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMax # segregation ratios: gametes from individual
              }
            }
          }
        } # end if DRR == "fixed"
        # General DRR #
        if (DRRtype == "general") {
          DRR <- DRRtable[thisLocus,1]
          # Pull out functions for particular DRR at this locus
          if (ploidy==6) {
            if (marker == "genotype") {
              getMotherGameteInfo <- getMotherGameteInfoHexGenoGeneral # segregation ratios: gametes from individual
            }
            if (marker == "phenotype") {
              getMotherGameteInfo <- getMotherGameteInfoHexPhenoGeneral # segregation ratios: gametes from individual
            }
          }
          if (ploidy==4) {
            if (marker == "genotype") {
              # New approach - no dont use it here for genotype data
              #segTableThisLocus <- segTable[[thisLocus]]
              # OLD approach
              getMotherGameteInfo <- getMotherGameteInfoTetrGenoGeneral # segregation ratios: gametes from individual
            }
            if (marker == "phenotype") {
              getMotherGameteInfo <- getMotherGameteInfoTetrPhenoGeneral # segregation ratios: gametes from individual
            }
          }
        }

        # Sampling of selfed genotypes  #
        # First gamete from mother
        motherGenotype <- simAdults[simAdults$ID==thisMother,locusRange]
        statusMum1 <- !is.na(motherGenotype)
        # if mother has no alleles
        if (all(statusMum1==FALSE)) {
          # send a 0 for current mum
          thisMother.sample <- sample(paste(rep("NA",ploidy),collapse=" "),numSimsPerMumSelfed,replace=TRUE)
          newProgeny <- t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy,))
        }
        # Otherwise mother does have phenotype information and proceed
        if (any(statusMum1==TRUE)) {
          motherGenotype <- as.vector(unlist(strip.NAs(motherGenotype)))
          motherGametes <- getMotherGameteInfo(motherGenotype,DRR)
          thisMother.Gametes <- as.vector(names(motherGametes$prob))
          thisMother.Probs <- as.vector(motherGametes$prob)
          thisMother.sample <- sample(thisMother.Gametes,numSimsPerMumSelfed,replace=TRUE,thisMother.Probs)
          thisMother.sample <- t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy/2,numSimsPerMumSelfed))
          # Second gamete from mother
          thisSelfedFather.sample<- sample(thisMother.Gametes,numSimsPerMumSelfed,replace=TRUE,thisMother.Probs)
          thisSelfedFather.sample<- t(matrix(unlist(strsplit(thisSelfedFather.sample," ")),ploidy/2,numSimsPerMumSelfed))
          newProgeny <- cbind(thisMother.sample,thisSelfedFather.sample)
        }
        # send to dataframe
        simCrosses[SimProgeny,locusRange] <- newProgeny
        simCrosses[SimProgeny,"pop"] <- as.vector(simAdults[simAdults[,"ID"] == thisMother,"pop"])
        simCrosses[SimProgeny,"mother"] <- thisMother
        simCrosses[SimProgeny,"ID"] <- paste(SimProgeny,"s",sep="")
        simCrosses[SimProgeny,"ActualCross"] <- as.vector(simAdults[simAdults[,"ID"] == thisMother,"pop"])
        # clear out
        newProgeny <- NULL
        thisMother.sample <- NULL
        thisSelfedFather.sample <- NULL
      } # End locus loop for selfed simulated offspring

    }

    #####################################
    # Sampling of outcrossed genotypes  #
    #####################################
    # Increase flag for outcrossed progeny
    flag <- max(SimProgeny)
    # simulated progeny ID labels for outcrossed progeny
    SimProgeny <- flag + (1:(numSimsPerMumOutcrossed))

    ########################################
    # random locations of father gametes   #
    ########################################
    randomPopns <- sample(allPopns,numSimsPerMumOutcrossed,replace=TRUE)
    thisPopninTotal.sample <- NULL
    # altering some to reflect the immigration rate selected for simulation
    randomNums <- runif(numSimsPerMumOutcrossed,0,1)
    change <- randomNums <= immRateSim
    theseToChange <- which(change)
    for (thisPop in theseToChange) {
      randomPopns[theseToChange] <- as.vector(thisPopn)
    }
    # Begin loop over loci
    for (thisLocus in 1:numLoci) {
      # thisLocus<-1
      locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
      # Fixed DRR
      # Temporarily change marker type for simulations
      marker <- "genotype"
      if (DRRtype == "fixed") {
        DRR <- DRRtable[thisLocus,2]
        # Pull out functions for particular DRR at this locus
        if (ploidy==6){
          if (marker == "genotype") {
            if (DRR == "min") {
              getMotherGameteInfo <- getMotherGameteInfoHexGenoMin # segregation ratios: gametes from individual
            } else if (DRR == "max") {
              getMotherGameteInfo <- getMotherGameteInfoHexGenoMax # segregation ratios: gametes from individual
            }
          }
          if (marker == "phenotype") {
            if (DRR == "min") {
              getMotherGameteInfo <- getMotherGameteInfoHexPhenoMin # segregation ratios: gametes from individual
            } else if (DRR == "max") {
              getMotherGameteInfo <- getMotherGameteInfoHexPhenoMax # segregation ratios: gametes from individual
            }
          }
        }
        if (ploidy==4) {
          if (marker == "genotype") {
            if (DRR == "min") {
              getMotherGameteInfo <- getMotherGameteInfoTetrGenoMin # segregation ratios: gametes from individual
            } else if (DRR == "max") {
              getMotherGameteInfo <- getMotherGameteInfoTetrGenoMax # segregation ratios: gametes from individual
            }
          }
          if (marker == "phenotype") {
            if (DRR == "min") {
              getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMin # segregation ratios: gametes from individual
            } else if (DRR == "max") {
              getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMax # segregation ratios: gametes from individual
            }
          }
        }
      } # end if DRR == "fixed"
      # General DRR
      if (DRRtype == "general") {
        DRR <- DRRtable[thisLocus,1]
        # Pull out functions for particular DRR at this locus
        if (ploidy==6) {
          if (marker == "genotype") {
            getMotherGameteInfo <- getMotherGameteInfoHexGenoGeneral # segregation ratios: gametes from individual
          }
          if (marker == "phenotype") {
            getMotherGameteInfo <- getMotherGameteInfoHexPhenoGeneral # segregation ratios: gametes from individual
          }
        }
        if (ploidy==4) {
          if (marker == "genotype") {
            # New approach - no dont use it here for genotype data
            #segTableThisLocus <- segTable[[thisLocus]]
            # OLD approach
            getMotherGameteInfo <- getMotherGameteInfoTetrGenoGeneral # segregation ratios: gametes from individual
          }
          if (marker == "phenotype") {
            getMotherGameteInfo <- getMotherGameteInfoTetrPhenoGeneral # segregation ratios: gametes from individual
          }
        }
      }

      # Sampling gametes from current mother
      # First gamete from mother
      motherGenotype <- simAdults[simAdults$ID==thisMother,locusRange]
      statusMum1 <- !is.na(motherGenotype)
      # if mother has no alleles
      if (all(statusMum1==FALSE)) {
        # send a 0 for current mum
        thisMother.sample <- sample(paste(rep("NA",ploidy/2),collapse=" "),numSimsPerMumOutcrossed,replace=TRUE)
        thisMother.sample <- t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy/2,))
      }
      # Otherwise mother does have phenotype information and proceed
      if (any(statusMum1==TRUE)) {
        motherGenotype<-as.vector(strip.NAs(motherGenotype))
        motherGametes <- getMotherGameteInfo(motherGenotype,DRR)
        thisMother.Gametes <- as.vector(names(motherGametes$prob))
        thisMother.Probs <- as.vector(motherGametes$prob)
        thisMother.sample <- sample(thisMother.Gametes,numSimsPerMumOutcrossed,replace=TRUE,thisMother.Probs)
        thisMother.sample <- t(matrix(unlist(strsplit(thisMother.sample," ")),ploidy/2,))
      }

      #########################################
      ## Begin loop over father locations    ##
      #########################################
      for (thisRandomPop in randomPopns) {
        # test thisRandomPop<-"GF"
        ######################################################################
        # Sampling of gametes from current father location in thisPopinTotal #
        ######################################################################
        thisPopninTotal.Gametes <- as.vector(colnames(gameteFrequencies[[thisRandomPop]][[thisLocus]]))
        thisPopninTotal.Probs <- as.vector(gameteFrequencies[[thisRandomPop]][[thisLocus]])
        thisPopninTotal.sample <- c(thisPopninTotal.sample,sample(thisPopninTotal.Gametes,1,replace=TRUE,thisPopninTotal.Probs))
      }
      thisPopninTotal.sample <- t(matrix(unlist(strsplit(thisPopninTotal.sample," ")),ploidy/2,))
      # Combine sampled gametes
      newProgeny <- cbind(thisMother.sample,thisPopninTotal.sample)
      # Remove new progeny with missing information for one gamete
      for (thisRow in 1:nrow(newProgeny)) {
        if (any(is.na(newProgeny[thisRow,]))) {
          newProgeny[thisRow,]<-NA
        }
      }             # head(simCrosses)
      # send to dataframe
      simCrosses[SimProgeny,locusRange] <- newProgeny
      simCrosses[SimProgeny,"pop"] <- as.vector(simAdults[simAdults[,"ID"] == thisMother,"pop"])
      simCrosses[SimProgeny,"mother"] <- thisMother
      simCrosses[SimProgeny,"ID"] <- paste(SimProgeny,"s",sep="")
      simCrosses[SimProgeny,"ActualCross"] <- randomPopns
      #simCrosses[SimProgeny,"ActualCross"]<-paste(thisMother,randomPopns,sep=" ")
      # clearing out   head(simCrosses)
      thisPopninTotal.sample <- NULL
      newProgeny<-NULL
      thisMother.sample<-NULL
    } #end locus loop
    # clear out randomly selected populations
    randomPopns<-NULL
    # Increase flag ready for selfed seedlings from next population
    flag<-max(SimProgeny)
  } #end mother loop
  these <- simCrosses[,1]!=0
  simCrosses <- simCrosses[these,]
  simCrosses <- as.data.frame(simCrosses)
  rownames(simCrosses) <- simCrosses$ID
  # convert end product to data frame
  these <- simCrosses[,1]!=0
  simCrosses <- simCrosses[these,]
  simCrosses <- as.matrix(simCrosses)

  # combine simulated individuals with real adults
  simCrosses <- as.data.frame(simCrosses)
  simAdults <- as.data.frame(simAdults)
  finalSimData <- rbind(simAdults, simCrosses)
  rownames(finalSimData) <- finalSimData$ID
  finalSimData <- as.matrix(finalSimData)

  # Introducing errors
  # 1. Altering alleles according to errorRate
  for (thisLocus in 1:numLoci) {
    #testing zone thisLocus <- 1
    ##current locus
    locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
    randomNums <- runif(nrow(finalSimData),0,1)
    change <- randomNums <= errorRate1
    theseToChange <- which(change)
    for (thisInd in theseToChange) {
      # thisInd <- 1072
      thisPop <- finalSimData[thisInd,"pop"]
      alleles <- finalSimData[thisInd,locusRange]
      possAlleles <- names(alleleFrequencies[[thisPop]][[thisLocus]])
      alleleChange <- sample(possAlleles,1)
      positionChange <- sample(1:length(alleles),1)
      alleles[positionChange] <- alleleChange
      finalSimData[thisInd,locusRange] <- as.character(t(t(alleles)[,1]))
    }
  }
  # 2. removing loci according to simMissLoci and replace with NA
  for (thisLocus in 1:numLoci) {
    #testing zone thisLocus<-1
    ##current locus
    locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
    randomNums <- runif(nrow(simCrosses),0,1)
    change <- randomNums <= simMissLoci
    finalSimData[change,locusRange] <- rep(NA,ploidy)
  }
  finalSimData <- as.data.frame(finalSimData)
  finalSimData[1:(numAdultsSim*numPopns),"ActualCross"] <- NA
  finalSimData[1:(numAdultsSim*numPopns),"mother"] <- NA
  cat("COMPLETE \n")
  return(finalSimData)
}
