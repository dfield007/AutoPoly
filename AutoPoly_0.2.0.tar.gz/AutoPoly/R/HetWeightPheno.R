#' heterozygosity weighting for phenotypes
#' @author David L. Field
#' @export
getHetWeightHexPheno <- function (thisGenotype) {
  ##Returns the weighted heterozygosity of a genotype
  switch(length(unique(thisGenotype)),
         {##Case "aaaaaa"
           tt <- sort(table(thisGenotype),decreasing=TRUE)
           weight<-0
           return (weight)
         }, # End switch
         {##Case Biallele "aaaaab, aaaabb, aaabbb".
           #count table of each allele, sorted so most frequent comes first
           weight<-0.48888
           return (weight)
         }, # End switch
         {##Case Triallele: "aaaabc, aaabbc, aabbcc"
           tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
           weight<-0.71111
           return (weight)
         }, # End switch
         {##Case Quadriallele: "aaabcd, aabbcd"
           weight<-0.833333
           return (weight)
           # End Quadriallele Type II
         },  # End Quadriallele switch
         {##Case Pentallele: "aabcde"
           tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
           weight<-0.9333333
           return (weight)
         },  # End Pentallele switch
         {## Case Hexallele: "abcdef"
           tt <- sort(table(thisGenotype),decreasing=TRUE)  #count table of each allele
           weight<-1.0
           return (weight)
         } # End Hexallele switch
  ) # End switch function
} # End function
