#' returns possible genotypes for a given phenotype (tetraploid)
#'
#' @export
getSeedlingGenotypesTetr <- function (phenotype) {
  #  Tetraploid  #
  ##Pheno is assumed sorted, and with no non-unique entries, and with
  ##no missing (NA) entries.
  switch(length(phenotype),
         {#Monoallele
           gCodes <- c("aaaa")
         },
         {## Biallele
           gCodes <- c("aaab","aabb","bbba")
         },
         {## Triallele
           gCodes <- c("aabc","bbac","ccab")
         },
         {## Quadriallele
           gCodes <- c("abcd")
         }
         )
  genotypes <- lapply(strsplit(gCodes,""),
                      function (thisVec,phenotype)  {
                        y <- match(thisVec,c("a","b","c","d"))
                        ##return(paste(phenotype[y],collapse=" "))
                        return(phenotype[y])
                      },
                      phenotype
                      )
  names(genotypes) <- lapply(genotypes,
                             function(thisVec) {
                               paste(thisVec,collapse=" ")
                             })
  return(genotypes)
}
