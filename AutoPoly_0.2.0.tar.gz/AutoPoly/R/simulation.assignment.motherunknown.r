#' simulate individuals with unknown mother
#'
#' for simulating data and estimating confidence levels for assignment (when mother is known).
#' Other fuctions must be run prior to this function to generate required data (see details)
#' @param inData dataframe, genotype/phenotype data.
#' @param alleleFrequencies list, allele frequencies for each locus in each population.
#' @param replacement logical, whether to account for missing alleles in populations (TRUE) or use strictly the observed data (FALSE).
#' @param gameteFreq_actual list, gamete frequencies for each locus in each population, actual correct frequencies
#' @param gameteFreq_est list, gamete frequencies for each locus in each population, estimated values to compare.
#' @param ploidy numeric, number of homologous chromosomes. Must be 4 or 6 (i.e. tetraploid or hexaploid).
#' @param marker character, must be either “phenotype” (allele copy number unknown) or “genotype” (allele copy number known).
#' @param numLoci numeric, number of loci in the data set.
#' @param selfing numeric, the amount of selfing to simulate. Must be a proportion (between 0 and 1)
#' @param DRRtype character, method uses either "general" or "fixed" formulas for genotype probabilities at RME (See details)
#' @param DRRtable_actual dataframe, actual correct frequencies. Generated from function: \code{\link{DRRsetup}},
#' @param DRRtable_est dataframe, estimated frequencies to compare with actual. Generated from function: \code{\link{DRRsetup}},
#' @param segTable_actual dataframe, segregation ratios actual correct values. Generated from function: \code{\link{makeGameteSegTable}},
#' @param segTable_est dataframe, segregation ratios estimated frequencies to compare with actual. Generated from function: \code{\link{makeGameteSegTable}},
#' @param simMissLoci numeric, mean proportion of missing loci to simulate per individual
#' @param lociMin integer, minimum number of available loci to include individual in assignment.
#' @param epsilon numeric, proportion of lowest likelihood to adjust for missing locus data (see details)
#' @param errorRate1 numeric, proportion of dropout errors to introduce into simulated data.
#' @param errorRate2 numeric, proportion of mistyping errors to introduce into simulated data.
#' @param output.txt logical, whether to save results of simulation power test to file (TRUE/FALSE)
#' @param numOffspringSim numeric, the number of offspring to simulate per mother
#' @param immRateSim numeric, proportion of interpopulation migrants to simulate
#' @details
#' \emph{Required data input}
#' \itemize{
#'  \item {allele frequencies must be provided and can be calculated using: \code{\link{alleleFreqPheno}}}
#'  \item {gamete frequencies must be provided and can be calculated using: \code{\link{gameteFreq}}}
#'  \item {expected segregation ratio must be provided and can be calculated using: \code{\link{makeGameteSegTable}}}
#' }
#' \emph{Output}
#' \itemize{
#'  \item {A list of two: $LScoresMatrix and $seedlingStatus}
#'  \item {$LScoresMatrix. This contains a dataframe where rows are the offspring and columns are the assignment likelihoods
#'  for each candidate population at each locus. Columns identify the population and locus number}
#'  \item {$seedlingStatus. This contains a dataframe where rows are the offspring and columns flag the quality of the data at each locus,
#'  as either "OK" (data present at locus), "S" (data missing at locus), "MS" (parent-offspring mismatch)}
#' }
#' @return procudes a dataframe of the assignment scores for simulated data
#' @author David L. Field
#' @examples
#' # Empirical data example.
#' # Eremophila glabra data consists of: 6 SSR loci, phenotypes, mother unknown, DRR and segregation ratios unknown.
#' data(Eremophila)
#' # modify to remove mother information
#' Eremophila[,"mother"] <- as.vector(Eremophila[,"mother"])
#' Eremophila[Eremophila[,"mother"]!="","mother"] <- "u"
#' write.csv(Eremophila,"Eremophila_mumUnKnown.csv",quote=F,row.names=F)
#'
#' # 1. Make table with the Double Reduction Rates (DRR) at each locus. Make second estimate the same as first
#' DRRtable_1 <- DRRsetup(numLoci=6,ploidy=6,propDRR=1)
#' DRRtable_2 <- DRRtable_1
#' # 2. import and process data
#' EremophilaData <- inputData("Eremophila_mumUnKnown.csv",numLoci=6,lociMin=5,ploidy=6,marker="phenotype",cohorts=T,motherknown=F,DRRtable_1)
#'
#' # 3. Make a new gamete segregation table (this calculates the expected segregation ratios at each locus for all phenotypes)
#' segTable_1 <- makeGameteSegTable(ploidy=6,DRRtable_1)
#' segTable_2 <- makeGameteSegTable(ploidy=6,DRRtable_2)
#'
#' # 4. allele frequencies
#' alleleFreq <- alleleFreqPheno(EremophilaData,numLoci=6,ploidy=6,replacement=T)
#'
#' # 5. Calculate gamete frequencies
#' gameteFreq_1 <- gameteFreq(EremophilaData,alleleFreq,numLoci=6,
#' ploidy=6,DRRtable_1,DRRtype="general")
#'
#' # 6. simulate assignment (to obtain credible intervals)
#' simulationEremophila <- simAssignment(inData=EremophilaData, alleleFrequencies=alleleFreq,replacement=T,
#'   gameteFreq_actual=gameteFreq_1, gameteFreq_est=gameteFreq_2, ploidy=6,marker="phenotype", numLoci=6,
#'   selfing=0.1, DRRtype="general",DRRtable_actual=DRRtable_1, DRRtable_est=DRRtable_2, segTable_actual=segTable_1,segTable_est=segTable_2,
#'   simMissLoci=0.1, lociMin=1, epsilon=0.1,
#'   errorRate1=0.01,errorRate2=0.01, output.txt=F,numMothersSim=10,numOffspringSim=5000,immRateSim=0.3)
#' @export
simAssignment <- function(inData,alleleFrequencies, replacement,gameteFreq_actual, gameteFreq_est,
                           ploidy, marker, numLoci,selfing, DRRtype,DRRtable_actual, DRRtable_est,
                          segTable_actual, segTable_est,simMissLoci, lociMin, epsilon, errorRate1,errorRate2,
                          output.txt,numMothersSim,numOffspringSim,immRateSim)  {
  # inData=EremophilaData;alleleFrequencies=alleleFreq;gameteFreq_actual=gameteFreq_1
  # gameteFreq_est=gameteFreq_1;segTable_est=segTable_2;segTable_actual=segTable_1
  # DRRtable_actual=DRRtable_1;DRRtable_est=DRRtable_2;simMissLoci=0
  # ploidy=6;numLoci=6;replacement=T;DRRtype="general"


    motherknown <- F
    cat("\n ** Beginning Simulation of Assignment tests.... **\n")
    flush.console()
    strip.NAs <- function(vv) {
    return(vv[!is.na(vv)])
    }
    ## Run the simulation & assignment testing #
    if (marker == "phenotype" & motherknown == FALSE) {
          # Simulates genotypes when mother unknown
          simData <- simulateGenosMotherUnknown(inData, alleleFrequencies,
                                      gameteFrequencies=gameteFreq_actual,
                                      ploidy, marker, numLoci, simMissLoci, selfing,
                                      errorRate1,numMothersSim,numOffspringSim,immRateSim)
          # simData <- simulateGenosMotherUnknown(inData=EremophilaData, alleleFrequencies=alelleFreq,
          #                                       gameteFrequencies=gameteFreq_actual,
          #                                       ploidy=6, marker=6, numLoci=6, simMissLoci=0,
          #                                       selfing=0,errorRate1=0,numMothersSim=10,
          #                                       numOffspringSim=1000,immRateSim=0.5)

          simData <- convert.phenotypes(simData, numLoci, ploidy)
          # Look for dud simulated individuals
          if (simMissLoci > 0) {
            simData <- NonDudIndividuals(simData,numLoci,ploidy,lociMin)
          }
          # Find the number of real adults for simdata
          numGoodAdults <- length(with(simData,unique(ID[is.na(mother)])))
          # Pull out ActualCrosses
          ActualCrosses <- simData[-(1:numGoodAdults),"ActualCross",drop=FALSE]
          simData <- simData[,1:((ploidy*numLoci)+3)]
          # Allele frequencies in simulation
          #alleleFreqSim <- alleleFreqPheno(simData,numLoci,ploidy,replacement)
          # gamete frequencies  in simulation
          #gameteFreqSim_2 <- gameteFreq(simData,alleleFreqSim,numLoci,ploidy,DRRtable_est,DRRtype)
          # Assignment
          simResults <- assignmentPheno(inData=simData,alleleFrequencies,
                                        gameteFrequencies=gameteFreq_actual,
                                        numLoci,ploidy,motherknown,DRRtable_est,
                                        DRRtype,segregationRatios=segTable_est)
     }
    if (marker == "genotype" & motherknown == FALSE) {
      simData <- simulateGenosMotherUnknown(inData, alleleFrequencies,replacement,gameteFrequencies_actual,
                                                  ploidy, marker, numLoci,numMothersSim,numOffspringSim, simMissLoci, selfing,errorRate1,immRateSim)          # run convert phenotypes function
      # Look for dud simulated individuals
      simData<-NonDudIndividuals(simData,numLoci,ploidy,lociMin)
      # Find the number of real adults for simdata
      numGoodAdults <- length(with(simData,unique(ID[is.na(mother)])))
      # Pull out ActualCrosses
      ActualCrosses<-simData[-(1:numGoodAdults),"ActualCross",drop=FALSE]
      simData<-simData[,1:((ploidy*numLoci)+3)]
      # Allele frequencies in simulation
      alleleFreqSim <- alleleFreqGeno(simData,numLoci,ploidy)
      # Gamete frequencies in simulation
      gameteFreqSim_2 <- gameteFreq(simData,alleleFreqSim,numLoci,ploidy,DRRtable_2,DRRtype="general")
      # Assignment
      simResults <- assignmentGeno(inData=simData,alleleFrequencies,gameteFrequencies=gameteFrequencies_actual,
                                  numLoci,ploidy,motherknown,DRRtable_est,
                                  DRRtype,segregationRatios=segTable_est)
    }
    # Run posthoc tests on simulated individuals  #
    simPostHoc <- postHocTests(simData,motherknown,numLoci,simResults,epsilon)
    # Collapsing ActualCrosses to be compatible with rankings
    for (thisRow in 1:nrow(ActualCrosses)) {
         #test thisRow<-12
         thesePops<-unlist(strsplit(ActualCrosses[thisRow,]," "))
         thesePops<- unique(thesePops)
         if (length(thesePops) == 2) {
            ActualCrosses[thisRow,] <- paste(thesePops, collapse=" ")
         }
         if (length(thesePops) == 1) {
            ActualCrosses[thisRow,]<- thesePops
         }
     }
    simPostHoc <- cbind(simPostHoc, ActualCrosses)
    # Critical Delta    #
    # Object with all Delta1 scores
    allDelta1 <- simPostHoc[,"Delta1"]
    allDelta1Sorted <- sort(simPostHoc[,"Delta1"])

    # Objects storing correct & incorrect Delta1 Scores
    correctAssign <- as.vector(simPostHoc[,"1"]) == as.vector(simPostHoc[,"ActualCross"])
    incorrectAssign <- as.vector(simPostHoc[,"1"]) != as.vector(simPostHoc[,"ActualCross"])
    Correct <- simPostHoc[correctAssign,]
    InCorrect <- simPostHoc[incorrectAssign,]
    grandTotal <- nrow(Correct) + nrow(InCorrect)
    critcal80 <- 0
    critcal90 <- 0
    critcal95 <- 0
    critcal99 <- 0
    Correcttest80 <- NULL
    Correcttest90 <- NULL
    Correcttest95 <- NULL
    Correcttest99 <- NULL
    Unresolved80 <- NULL
    Unresolved90 <- NULL
    Unresolved95 <- NULL
    Unresolved99 <- NULL
    percentAssignableat80 <- NULL
    percentAssignableat90 <- NULL
    percentAssignableat95 <- NULL
    percentAssignableat99 <- NULL

    # Loop over all Delta1 #
    for (thisDelta in allDelta1Sorted) {
      # thisDelta<- allDelta1Sorted[1]
      Correcttest <- sum(as.numeric(Correct[,"Delta1"]>=thisDelta))
      InCorrecttest <- sum(as.numeric(InCorrect[,"Delta1"]>=thisDelta))
      PercentCorrect <- Correcttest/(Correcttest + InCorrecttest)
      # finding the critical regions for 80, 90, 95 * 99% confidence
      if (PercentCorrect >= 0.80 & PercentCorrect < 0.9 & critcal80==0) {
        critcal80 <- thisDelta
        Correcttest80<- sum(as.numeric(allDelta1>=critcal80))
        Unresolved80<- sum(as.numeric(allDelta1<critcal80))
        percentAssignableat80<- Correcttest80/(Correcttest80+Unresolved80)
      }
      if (PercentCorrect >= 0.90 & PercentCorrect < 0.95 & critcal90==0) {
        critcal90 <- thisDelta
        Correcttest90<- sum(as.numeric(allDelta1>=critcal90))
        Unresolved90<- sum(as.numeric(allDelta1<critcal90))
        percentAssignableat90<- Correcttest90/(Correcttest90+Unresolved90)
      }
      if (PercentCorrect >= 0.95 & PercentCorrect < 0.99 & critcal95==0) {
        critcal95 <- thisDelta
        Correcttest95<- sum(as.numeric(allDelta1>=critcal95))
        Unresolved95<- sum(as.numeric(allDelta1<critcal95))
        percentAssignableat95<- Correcttest95/(Correcttest95+Unresolved95)
      }
      if (PercentCorrect >= 0.99 & critcal99==0) {
        critcal99 <- thisDelta
        Correcttest99<- sum(as.numeric(allDelta1>=critcal99))
        Unresolved99<- sum(as.numeric(allDelta1<critcal99))
        percentAssignableat99<- Correcttest99/(Correcttest99+Unresolved99)
      }
    }
    # Buildling Simulation Summary file  #
    # Header information
    CurrentDate<-date()
    labelSims<-"Simulation Run Completed:"
    labelfilename<-"File   = "
    labelPloidy<-"Ploidy = "
    labelMarker<-"Marker = "
    labelMother<-"Mother = "
    labelSimsmatrix<-matrix(0,5,2)
    labelSimsmatrix[1,1]<- labelSims
    labelSimsmatrix[2,]<- c(labelfilename,"_")
    labelSimsmatrix[3,]<- c(labelPloidy,ploidy)
    labelSimsmatrix[4,]<- c(labelMarker,marker)
    labelSimsmatrix[5,]<- c(labelMother,motherknown)
    labelSimsmatrix[1,2]<- CurrentDate
    SimDetails1<-paste(labelSimsmatrix[1,1],labelSimsmatrix[1,2])
    SimDetails2<-paste(labelSimsmatrix[2,1],labelSimsmatrix[2,2])
    SimDetails3<-paste(labelSimsmatrix[3,1],labelSimsmatrix[3,2])
    SimDetails4<-paste(labelSimsmatrix[4,1],labelSimsmatrix[4,2])
    SimDetails5<-paste(labelSimsmatrix[5,1],labelSimsmatrix[5,2])
    # Header matrix
    headerMatrix<-matrix(0,16,1)
    headerMatrix[1,]<-c("                                                ")
    headerMatrix[2,]<-c(" ********************************************** ")
    headerMatrix[3,]<-c(" *          PolyAssign 1.0 (1.2.2010)         * ")
    headerMatrix[4,]<-c(" *    Simulation of Assignment testing        * ")
    headerMatrix[5,]<-c(" *          Author: David Field               * ")
    headerMatrix[6,]<-c(" ********************************************** ")
    headerMatrix[7,]<-c("                                                ")
    headerMatrix[8,]<-SimDetails1
    headerMatrix[9,]<-c("                                                ")
    headerMatrix[10,]<-SimDetails2
    headerMatrix[11,]<-SimDetails3
    headerMatrix[12,]<-SimDetails4
    headerMatrix[13,]<-SimDetails5
    headerMatrix[14,]<-c("                                                ")
    headerMatrix[15,]<-c(" ** Summary Statistics **")
    headerMatrix[16,]<-c("                                                ")
    headerMatrix<-as.data.frame(headerMatrix)

    # Summary of simulations
    SimsSummary<-matrix(0,4,5)
    colnames(SimsSummary)<-c("Level    ","CF(%)","Delta","N-Sims","Success(%)")
    SimsSummary[,"Level    "]<-c("Strict    ","Moderate","Relaxed  ","Total     ")
    #SimsSummary[,"Level    "]<-c("Strict","Moderate","Relaxed","Total")
    SimsSummary[,"CF(%)"]<-c("0.95","0.90","0.80","  ")
    SimsSummary[,"Delta"]<-c(signif(critcal95,3),signif(critcal90,3),signif(critcal80,3),"  ")
    SimsSummary[,"N-Sims"]<-c(Correcttest95,Correcttest90,Correcttest80,grandTotal)
    SimsSummary[,"Success(%)"]<-c(signif(percentAssignableat95*100,3),
                                   signif(percentAssignableat90*100,3),
                                   signif(percentAssignableat80*100,3)," ")
    # Sending to output file
    if (output.txt==TRUE) {
        FLAG<-TRUE
        # Send multilocus data to excel file
        write.csv(simPostHoc,"simsAssignmentFull.csv",row.names=FALSE)
        cat("Simulated individuals, Assignment likelihoods sent to: 'simsAssignmentFull.csv' \n")
        # Send header to export file
        write(t(headerMatrix),"SimsSummary.txt",append=TRUE)
        # Send summary of simulations to export file
        write.table(as.data.frame(SimsSummary),"SimsSummary.txt",append=FLAG,quote=FALSE,sep="\t",row.names=FALSE)
        cat("Simulation summary sent to: 'SimsSummary.txt' \n")
    }
    if (output.txt==FALSE) {
            # Summary of simulations
        SimsSummary<-matrix(0,4,5)
        colnames(SimsSummary)<-c("Level","CF(%)","Delta","N-Sims","Success(%)")
        #SimsSummary[,"Level    "]<-c("Strict    ","Moderate","Relaxed  ","Total     ")
        SimsSummary[,"Level"]<-c("Strict","Moderate","Relaxed","Total")
        SimsSummary[,"CF(%)"]<-c("0.95","0.90","0.80","  ")
        SimsSummary[,"Delta"]<-c(round(critcal95,4),round(critcal90,4),round(critcal80,4),"  ")
        SimsSummary[,"N-Sims"]<-c(Correcttest95,Correcttest90,Correcttest80,grandTotal)
        SimsSummary[,"Success(%)"]<-c(signif(percentAssignableat95*100,3),
                                   signif(percentAssignableat90*100,3),
                                   signif(percentAssignableat80*100,3)," ")
        SimsSummary<-as.data.frame(SimsSummary)

        # Send multilocus data to excel file
        write.csv(simPostHoc,"simsAssignmentFull.csv",row.names=FALSE)
        cat("** Simulation Summary Statistics ** \n")
        print(as.data.frame(SimsSummary))
        cat("\n Simulated individuals, Assignment likelihoods sent to: 'simsAssignmentFull.csv' \n")
        }

    return(as.data.frame(SimsSummary))

}
#' @export
# Function to return individuals that meet the minimum loci criteria
NonDudIndividuals<-function(inDataSimData,numLoci,ploidy,lociMin) {
                alleleCounts <- matrix(0, nrow(inDataSimData),ncol=numLoci,
                                      dimnames=list(inDataSimData$ID,paste("Locus",1:numLoci)))
                  ## number of alleles present in each set - store in alleleCounts
              for (thisLocus in 1:numLoci) {
                  #testing thisLocus<-1
                  # thisAdult<-3
                  locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
                  ##Note: apply() returns the _transpose_ of the desired matrix
                  ## below - hence the use of t()...
                  inDataSimData[,locusRange] <- t(apply(inDataSimData[,locusRange],1,sort,
                                     na.last = TRUE))
                  ## Store the numbers of alleles detected at each locus
                  alleleCounts[,thisLocus] <- apply(inDataSimData[,locusRange],1,
                                                  function (thisAlleleVector) {
                                                    sum(!is.na(thisAlleleVector))
                                                  })
                  }
                  numLociData <- apply(alleleCounts,1,
                             function (theseAlleleCounts) {
                               sum(theseAlleleCounts > 0)
                             })
                  GoodPlants <- numLociData >= lociMin
                  return(inDataSimData[as.vector(GoodPlants),])
}
