#' Post Hoc tests for assignment tests
#'
#'Called from : \code{\link{simAssignmentMums}} and \code{\link{simAssignment}}
#'
#' @return procudes a data frame containing likelihood scores and population assignment scores for each offspring
#' @author David L. Field
#' @export
postHocTests <- function(inData,motherknown,numLoci,results,epsilon) {
          cat("\n ** Beginning Posthoc Tests.... **\n")
    # results <- simResults
    allPopns <- unique(inData$pop)
    numPopns <- length(allPopns)
    fullSeedlingSet <- as.vector(with(inData,unique(ID[!is.na(mother)])))

    ####################################################
    # Build matrix ready to receive multilocus scores  #
    ####################################################
    if (motherknown==TRUE) {
        combinedScoresFull <- matrix(0,nrow=length(fullSeedlingSet),ncol=numPopns,
                                      dimnames=list(fullSeedlingSet,allPopns))
        allPopnsAllCombos<-NULL
        allPopnsAllCombos<-allPopns
        numComboandPops<- ncol(combinedScoresFull)
    } else if (motherknown==FALSE) {
        # possible F1 combinations
        # Required later in assignment test for part c) #
        allPopns <- unique(inData$pop)
        numPopns <- length(allPopns)
        noPopCombinations <- (numPopns*(numPopns-1))/2
        popCombos <- combinations(numPopns,2,allPopns,repeats=FALSE)
        popComboMatrix <- matrix(0,1,noPopCombinations)
        for (thisCombo in 1:nrow(popCombos)) {
            #test thisCombo<-1
            Combo<- popCombos[thisCombo,]
            popComboMatrix[1,thisCombo]<-paste(Combo,collapse=" ")
            #unlist(strsplit(Combo," "))
        }
        allPopnsAllCombos <- c(allPopns,popComboMatrix[1,])
        numComboandPops <- length(allPopnsAllCombos)
        combinedScoresFull <- matrix(0,nrow=length(fullSeedlingSet),ncol=length(allPopnsAllCombos),
                             dimnames=list(fullSeedlingSet,allPopnsAllCombos))

    }

    # Calculate replacement value for missing values
    # results<-simResults
    replaceValueLoci <- matrix(0,numLoci,)
    for (thisLocus in 1:numLoci) {
        # thisLocus<-1
        # nominate columns for this locus in new matrix approach
        colRange <- ((thisLocus-1)*numComboandPops) + (1:numComboandPops)
        allValues <- as.vector(unlist(results$LScoresMatrix[,colRange]))
        minValueThisLocus <- min(allValues,na.rm = TRUE)
        minValueThisLocus <- min(allValues[allValues!=0],na.rm = TRUE)
        replaceValueLoci[thisLocus,] <- as.numeric(minValueThisLocus)/(epsilon*100)
    }

    #################################
    # Calculating multilocus scores #
    #################################
         # thisLocus<-7
         # thisSeedling<-"988s"
        #   results$LScores[[thisLocus]][[thisSeedling]]

    cat("       Processing multi-locus scores...")
    flush.console()
    #  rownames(results$LScoresMatrix) <- as.vector(results$LScoresMatrix[,1])
    combinedScoresFull <- as.matrix(combinedScoresFull)

    for (thisSeedlingNum in 1:length(fullSeedlingSet)) {  # loop over each seedling
        # thisSeedlingNum <-1
        # thisSeedling <-1
        thisSeedling <- fullSeedlingSet[thisSeedlingNum]
        thisSeedlingData<- matrix(0,nrow=numLoci,ncol=length(allPopnsAllCombos),
                             dimnames=list(1:numLoci,allPopnsAllCombos))
        for (thisLocus in 1:numLoci) {
            # thisLocus <- 1
            colRange <- ((thisLocus-1)*numComboandPops) + (1:numComboandPops)
            # below replaces any nulls (data missing in LScores) with the epsilon replacement
            if (is.null(results$LScoresMatrix[thisSeedlingNum,colRange])) {
                thisSeedlingData[thisLocus,] <- replaceValueLoci[thisLocus,]
                # If data is found, below send the information to the multilocus matrix for the individual
            } else if (!is.null(results$LScoresMatrix[thisSeedlingNum,colRange])) {
                    thisSeedlingData[thisLocus,] <- as.numeric(as.vector(unlist((results$LScoresMatrix[thisSeedlingNum,colRange]))))
            }
            ### Any remainder 0 values are replaced with a proportion (epsilon) of the smallest value at the locus
            tt <- sapply(thisSeedlingData[thisLocus,],
                  function (ll,replaceValueLoci,thisLocus) {
                      value <- replaceValueLoci[thisLocus,]
                      if (ll==0) {
                          return(value)
                      } else if (ll>0) {
                      return(ll)
                      }
                  }
                  , replaceValueLoci,thisLocus)
            thisSeedlingData[thisLocus,] <- tt
        } # end Locus loop
        # calculates the product across loci
        combinedScoresFull[thisSeedlingNum,] <- as.vector(apply(thisSeedlingData,2,prod))
    } # end seedlings loop
    ######################################
    # Natural log of multilocus scores   #
    ######################################
    combinedScoresFull <- log(as.data.frame(combinedScoresFull))

    #########################
    ## Ranking populations  #
    #########################
    cat("\n       Ranking Populations \n")
    flush.console()
    combinedScoresFull <- cbind(seedling=rownames(combinedScoresFull),
                            homePopn=inData$pop[match(fullSeedlingSet,inData$ID)],
                            mother=inData$mother[match(fullSeedlingSet,inData$ID)],
                            combinedScoresFull)
    cSRanks <- t(apply(combinedScoresFull[,-(1:3)],1,
                function(vv) {length(allPopnsAllCombos) + 1 - rank(vv,ties.method="max")}))

    numSeedlings<-max(row(combinedScoresFull))
    rankMatrix<-matrix(0,nrow=numSeedlings,ncol=length(allPopnsAllCombos))
    rownames(rankMatrix)<-rownames(cSRanks)

    for(seedling in fullSeedlingSet) {
        vec <- cSRanks[seedling,,drop=FALSE]
        names(vec) <- allPopnsAllCombos
        vec <- rank(vec)
        vec <- sort(vec)
        rankMatrix[seedling,] <- names(vec)
        }
    combinedScoresFull <- cbind(combinedScoresFull,rankMatrix)
    ## combine above ranked pops with main output
    ## then determines delta1 (1st - 2nd) & delta2 (2nd - 3rd)

    cat("       Processing Delta    \n\n")
    flush.console()
    popLnOrder<-names(combinedScoresFull[4:(3+length(allPopnsAllCombos))])
    LODmatrix<-matrix(0,nrow=numSeedlings,ncol=2)
    rownames(LODmatrix)<-fullSeedlingSet
    colnames(LODmatrix)<-c("Delta1","Delta2")

    matchingTime<-function(seedlingData,popLnOrder,assignOrder) {
            y<-c(3)+(match(assignOrder,popLnOrder))
            return(seedlingData[,y])
                    }
    for(seedling in fullSeedlingSet) {
         #test  seedling<-"1s"
         seedlingData<-combinedScoresFull[seedling,]
         assignOrder<-as.vector(unlist(seedlingData[(4+length(allPopnsAllCombos)):(3+length(allPopnsAllCombos)*2)]))
         thisLnOrder<-matchingTime(seedlingData,popLnOrder,assignOrder)
         LODmatrix[seedling,1]<-as.numeric(thisLnOrder[1]-thisLnOrder[2])
    }
    combinedScoresFull <- cbind(combinedScoresFull,LODmatrix)
    ##Code for adding number of good loci
    combinedScoresFull$numOKLoci <- 0
    for (seedling in rownames(combinedScoresFull)) {
      combinedScoresFull[seedling,"numOKLoci"]<- sum(results$seedlingStatus[seedling,]=="OK")
    }
    return(combinedScoresFull)
}
