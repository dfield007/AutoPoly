#' performs population assignment on phenotype data
#'
#' for phenotype data of a set of adults and offspring (progeny), the procedure
#' assigns the most likely source population when maternal parent is known or unknown
#' Other fuctions must be run prior to this function to generate required data (see details)
#' @param inData dataframe, genotype/phenotype data.
#' @param alleleFrequencies list, allele frequencies for each locus in each population
#' @param gameteFrequencies list, gamete frequencies for each locus in each population
#' @param numLoci numeric, number of loci in the data set
#' @param ploidy numeric, number of homologous chromosomes. Must be 4 or 6 (i.e. tetraploid or hexaploid).
#' @param motherknown logical, must be either TRUE (i.e. progeny collected from known mothers but father unknown) or FALSE (i.e. progeny from unknown mother or father).
#' @param DRRtable dataframe, double reduction rates at each locus (see details)
#' @param DRRtype character, method uses either "general" or "fixed" formulas for genotype probabilities at RME (see details)
#' @param segregationRatios dataframe, segregation ratios (see details)
#' @details
#' \emph{Required data input}
#' \itemize{
#'  \item {allele frequencies must be provided and can be calculated using: \code{\link{alleleFreqPheno}}}
#'  \item {gamete frequencies must be provided and can be calculated using: \code{\link{gameteFreq}}}
#'  \item {expected segregation ratio must be provided and can be calculated using: \code{\link{makeGameteSegTable}}}
#' }
#' \emph{Output}
#' \itemize{
#'  \item {A list of two: $LScoresMatrix and $seedlingStatus}
#'  \item {$LScoresMatrix. This contains a dataframe where rows are the offspring and columns are the assignment likelihoods
#'  for each candidate population at each locus. Columns identify the population and locus number}
#'  \item {$seedlingStatus. This contains a dataframe where rows are the offspring and columns flag the quality of the data at each locus,
#'  as either "OK" (data present at locus), "S" (data missing at locus), "MS" (parent-offspring mismatch)}
#' }
#' @return procudes a dataframe with same dimensions as excel file
#' @author David L. Field
#' @examples
#' # Empirical data example.
#' # Eremophila glabra data consists of: 6 SSR loci, phenotypes, mother known, DRR and segregation ratios unknown.
#' data(Eremophila)
#' write.csv(Eremophila,"Eremophila_mumKnown.csv",quote=F,row.names=F)
#'
#' # Step 1. Make two tables with the rates of Double Reduction at each locus.
#' # i.e. DRRtable_1 (used for simulations) & DRRtable_2 (assumed DRR used for assignment testing)
#' DRRtable_1 <- DRRsetup(numLoci=6,ploidy=6,propDRR=1)
#' DRRtable_2 <- DRRtable_1
#' DRRtable_2[,1] <- 0.13635
#'
#' # 2. import and process data
#' EremophilaData <- inputData("Eremophila_mumKnown.csv",numLoci=6,lociMin=5,ploidy=6,marker="phenotype",cohorts=T,motherknown=T,DRRtable_1)
#'
#' # 3. Make a new gamete segregation table (this calculates the expected segregation ratios at each locus for all phenotypes)
#' segTable_1 <- makeGameteSegTable(ploidy=6,DRRtable_1)
#' segTable_2 <- makeGameteSegTable(ploidy=6,DRRtable_2)
#'
#' # 4. allele frequencies
#' alleleFreq <- alleleFreqPheno(EremophilaData,numLoci=6,ploidy=6,replacement=T)
#'
#' # 5. Calculate gamete frequencies
#' # Using DRRtable_1 (true DRR for simulations)
#' # Note: Adjust DRRtable_1 and DRRtable_2 to examine the impact of deviations from the true DRR
#' gameteFreq_1 <- gameteFreq(EremophilaData,alleleFreq,numLoci=6,
#' ploidy=6,DRRtable_1,DRRtype="general")
#' # Using DRRtable_2 (assumed DRR for assignment testing and simulations)
#' gameteFreq_2 <- gameteFreq(EremophilaData,alleleFreq,
#' numLoci=6,ploidy=6,DRRtable_2,DRRtype="general")
#'
#' # 6. simulate assignment (to obtain credible intervals)
#' simulationEremophila <- simAssignmentMums(inData=EremophilaData, alleleFrequencies=alleleFreq,replacement=T,
#'                   gameteFreq_actual=gameteFreq_1, gameteFreq_est=gameteFreq_2, ploidy=6,marker="phenotype", numLoci=6,
#'                   selfing=0.1, DRRtable_actual=DRRtable_1, DRRtable_est=DRRtable_2, segTable_actual=segTable_1,segTable_est=segTable_2,
#'                   DRRtype="general", simMissLoci=0, lociMin=1, epsilon=0.1,
#'                   errorRate1=0.01,errorRate2=0.01, output.txt=F,numAdultsSim=50,numMothersSim=10,
#'                   numOffspringSim=5000,fixMothersSim=F,immRateSim=0.3)
#'
#' # 7. Run assignment
#' EremophilaAssignment <- assignmentPheno(inData=EremophilaData,alleleFrequencies=alleleFreq,gameteFrequencies=gameteFreq_2,
#'   numLoci=6,ploidy=6,motherknown=T,DRRtable_2,DRRtype="general",segregationRatios=segTable_2)
#' @export
assignmentPheno <- function(inData,alleleFrequencies,gameteFrequencies,
                            numLoci,ploidy,motherknown,DRRtable,DRRtype,segregationRatios) {

  # inData <- simData;alleleFrequencies <- alleleFreqSim;gameteFrequencies <- gameteFreqSim_2
  # DRRtable <- DRRtable_2
  # segregationRatios <- segTable_2

    strip.NAs <- function(vv) {
        return(vv[!is.na(vv)])
    }
    # Directing appropriate main assignment functions  #
    if (motherknown==TRUE) {
        assign.popMain <- function (inData,alleleFrequencies,gameteFrequencies,
                                    numLoci,ploidy,motherknown,DRRtable,DRRtype,segregationRatios) {
          # Initial setup of functions depending on ploidy
          marker <- "phenotype"
          epsilon3 <-0.0
          cat("\n       Mother = KNOWN ")
          flush.console()

          # a) Directing required hexaploid functions #
          if (ploidy==6) {
            getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
            mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
            getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
            gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
          }
          # b) Directing required tetraploid functions   #
          if (ploidy==4) {
            getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
            mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
            getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
            gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
          }

          # Main setup
          # -population information
          # -data output structures
          strip.NAs <- function(vv) {
            return(vv[!is.na(vv)])
          }

          if (ploidy == 6) {
            MAXSEEDLINGGENOTYPES <- 10
          } else if (ploidy == 4) {
            MAXSEEDLINGGENOTYPES <- 3
          }
          allMothers <- with(inData,unique(strip.NAs(mother)))
          allSeedlings <- with(inData,unique(ID[!is.na(mother)]))
          popnsWithMothers <- unique(with(inData,pop[ID %in% allMothers]))
          cat("\n\n",length(popnsWithMothers),"population(s) with a total of",
              length(allMothers),"mother(s) and",
              length(allSeedlings),"progeny...\n")
          flush.console()
          allPopns <- unique(inData$pop)
          numPopns <- length(allPopns)
          fatherInPopnProbs <- rep.int(0,numPopns)  ## Needed later
          names(fatherInPopnProbs) <- allPopns

          ##Colnames of seedlingScores MUST match the names of
          ##fatherInPopnProbs (& in same order).  Otherwise the code will mix
          ##up the results for different populations...
          seedlingScores <- matrix(0,nrow=MAXSEEDLINGGENOTYPES,ncol=numPopns,
                                   dimnames = list(1:MAXSEEDLINGGENOTYPES,allPopns))
          ## The L scores will be stored in a list, built up as the loops progress...
          # LScores <- list()
          # head(LScoresMatrix)
          # Creating normal R matrix
          LScoresMatrix <- matrix(0,length(allSeedlings),((ncol(seedlingScores))*numLoci))
          lociInfo <- paste("L.",sort(rep(1:numLoci,(ncol(seedlingScores)))),sep="")
          numComboandPops <- length(fatherInPopnProbs)
          popCombosandPops <- c(allPopns)
          columnNames <- paste(rep(popCombosandPops,numLoci),lociInfo)
          colnames(LScoresMatrix) <- columnNames
          rownames(LScoresMatrix) <- allSeedlings

          ## seedlingStatus records information about each seedling
          seedlingStatus <- matrix("",nrow=length(allSeedlings),ncol=numLoci,
                                   dimnames=list(allSeedlings,1:numLoci))
          ## Mother alleles all missing  (M)
          ## Seedling alleles missing    (S)
          ## Mother and seedling alleles present, but incompatible (MS)
          foundGameteGenotypeMatch <- FALSE  ##Initialise flag

          ## Begin loop over loci
          cat("\n Processing locus")
          for (thisLocus in 1:numLoci) {
            #testing zone thisLocus<-1
            cat(".",thisLocus,".")
            flush.console()
            ##Define the inData column range containing the alleles for the
            locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
            # nominate what columns the current seedlings data goes to
            colRange <- ((thisLocus-1)*numComboandPops) + (1:numComboandPops)

            # Pull out functions for particular DRR at this locus
            if (DRRtype == "fixed") {
              DRR <- as.vector(DRRtable[thisLocus,2])

              if (ploidy==6) {
                if (marker == "genotype") {
                  if (DRR == "min") {
                    getMotherGameteInfo <- getMotherGameteInfoHexGenoMin # segregation ratios: gametes from individual
                  } else if (DRR == "max") {
                    getMotherGameteInfo <- getMotherGameteInfoHexGenoMax # segregation ratios: gametes from individual
                  }
                }
                if (marker == "phenotype") {
                  if (DRR == "min") {
                    getMotherGameteInfo <- getMotherGameteInfoHexPhenoMin # segregation ratios: gametes from individual
                  } else if (DRR == "max") {
                    getMotherGameteInfo <- getMotherGameteInfoHexPhenoMax # segregation ratios: gametes from individual
                  }
                }
              }

              if (ploidy==4) {
                if (marker == "genotype") {
                  if (DRR == "min") {
                    getMotherGameteInfo <- getMotherGameteInfoTetrGenoMin # segregation ratios: gametes from individual
                  } else if (DRR == "max") {
                    getMotherGameteInfo <- getMotherGameteInfoTetrGenoMax # segregation ratios: gametes from individual
                  }
                }
                if (marker == "phenotype") {
                  if (DRR == "min") {
                    getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMin # segregation ratios: gametes from individual
                  } else if (DRR == "max") {
                    getMotherGameteInfo <- getMotherGameteInfoTetrPhenoMax # segregation ratios: gametes from individual
                  }
                }
              }

            }
            # Pull out functions for particular DRR at this locus - general formulas
            if (DRRtype == "general") {
              DRR <- as.vector(DRRtable[thisLocus,1])
              if (ploidy==6) {
                getMotherGameteInfoGeno <- getMotherGameteInfoHexGenoGeneral # segregation ratios: gametes from individual
                getMotherGameteInfoPheno <- getMotherGameteInfoHexPhenoGeneral # segregation ratios: gametes from individual
              }
              if (ploidy==4) {
                getMotherGameteInfoGeno <- getMotherGameteInfoTetrGenoGeneral # segregation ratios: gametes from individual
                getMotherGameteInfoPheno <- getMotherGameteInfoTetrPhenoGeneral # segregation ratios: gametes from individual
              }
            }

            ## Begin loop over populations that have seedlings ##
            for (thisPopn in popnsWithMothers) {
              # thisPopn <- "A"
              cat(".")
              flush.console()
              otherPopns <- allPopns[thisPopn!=allPopns]
              ##Get mothers in this population:
              thisPopnsMothers <- with(inData, ID[pop==thisPopn & ID %in% mother])

              #####################################################
              ## Begin loop over mothers in this population      ##
              #####################################################
              for (thisMother in thisPopnsMothers) {
                # thisMother <-"A_799"
                motherPhenotype <- strip.NAs(as.vector(unlist(inData[inData$ID==thisMother,locusRange])))
                thisMothersSeedlings <- strip.NAs(with(inData, ID[mother==thisMother]))
                if (length(motherPhenotype) < 1) {
                  seedlingStatus[thisMothersSeedlings,thisLocus] <- "M"
                  next ## Skip to next mother
                } else {
                  motherGametes <- getMotherGameteInfoPheno(motherPhenotype,segregationRatios[[thisLocus]])

                  #####################################################
                  ## Begin loop over seedlings from current mother   ##
                  #####################################################
                  for (thisSeedling in thisMothersSeedlings) {
                    # thisSeedling <- "51_s"
                    seedlingPhenotype <- strip.NAs(inData[inData$ID==thisSeedling,locusRange])
                    if (length(seedlingPhenotype) < 1) {
                      seedlingStatus[thisSeedling,thisLocus] <- "S"
                      next  ## Skip to next seedling
                    } else {
                      seedlingGenotypes <- getSeedlingGenotypes(seedlingPhenotype)
                      seedlingGenotypeCount <- 0

                      ###############################################
                      ## loop over possible seedling genotypes     ##
                      ###############################################
                      for (seedlingGenotype in seedlingGenotypes) {
                        #test seedlingGenotype <- seedlingGenotypes[[1]]
                        for (motherGamete in motherGametes$gametes) {
                          # test motherGamete <- motherGametes$gametes[[4]]
                          motherAlleleMatch <- match(make.unique(motherGamete), make.unique(seedlingGenotype))
                          if (any(is.na(motherAlleleMatch))) {  ## If mother gamete was incompatible with seedling phenotype...
                            next  ## Skip to next mother gamete
                          } else {
                            foundGameteGenotypeMatch <- TRUE  ##Set flag
                            motherGameteProb <- motherGametes$prob[paste(motherGamete,collapse=" ")]
                            fatherGamete <- seedlingGenotype[-motherAlleleMatch]
                            fatherInPopnProbs[thisPopn] <- gameteFreqGivenPopn(fatherGamete,alleleFrequencies[[thisPopn]][[thisLocus]],DRR,epsilon3)
                            for (thatPopn in otherPopns) {
                              #test thatPopn<-"GN"
                              fatherInPopnProbs[thatPopn] <- gameteFreqGivenPopn(fatherGamete,alleleFrequencies[[thatPopn]][[thisLocus]],DRR,epsilon3)
                            }
                            # Main assignment equation (sum over mother gamete and father gamete combinations)
                            seedlingScores[seedlingGenotypeCount+1,] <- seedlingScores[seedlingGenotypeCount+1,] + motherGameteProb*fatherInPopnProbs
                            fatherInPopnProbs[allPopns] <- 0     # reset when finished
                          } ## End "Is mother incompatible?" if
                        } ##End motherGametes loop
                        if (foundGameteGenotypeMatch) {
                          seedlingGenotypeCount <- seedlingGenotypeCount + 1
                          foundGameteGenotypeMatch <- FALSE ## Reset flag
                        }
                      } ##End seedlingGenotypes loop
                      #    head(LScoresMatrix)
                      if (seedlingGenotypeCount > 0) {
                        LScoresMatrix[thisSeedling,colRange] <- as.vector(apply(seedlingScores[1:seedlingGenotypeCount,,drop=FALSE],2,mean))
                        seedlingScores[,] <- 0  ##Clear this out before the next loop...
                        seedlingStatus[thisSeedling,thisLocus] <- "OK"
                      } else {
                        seedlingStatus[thisSeedling,thisLocus] <- "MS"
                      } ##End seedlingGenotypeCount > 0 check
                    } ##End empty seedling phenotype check
                  } ##End seedlings loop
                } ##End empty mother phenotype check
              } ##End thisPopnsMothers loop
            } ##End popnsWithMothers loop
            fatherInPopnProbs[allPopns] <- 0     # reset when locus finished
          } ##End numLoci loop
          cat("\n ** Assignment testing...... COMPLETE **\n\n")
          return(list(LScoresMatrix=LScoresMatrix,seedlingStatus=seedlingStatus))
        }
        }
    if (motherknown==FALSE) {
        assign.popMain <- function (inData,alleleFrequencies,gameteFrequencies,
                                    numLoci,ploidy,motherknown,DRRtable,DRRtype,segregationRatios) {
          # inData <- simData
          marker<-"phenotype"
          epsilon3<-0.0
          cat("\n       Mother = UNKNOWN ")
          flush.console()
          # a) Directing required hexaploid functions #
          if (ploidy==6) {
            getProbGenotypeGivenPopn <- genotypeFreqPopHex           # freq of a genotype, given gamete freqs of population
            mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopHex   # freq of a mixed F1 genotype, given gamete freqs of 2 populations
            getSeedlingGenotypes <- getSeedlingGenotypesHex          # list of possible genotypes for a phenotype
            gameteFreqGivenPopn <- gameteFrequencyPopHex             # frequency of a given gamete
          }
          # b) Directing required tetraploid functions   #
          if (ploidy==4) {
            getProbGenotypeGivenPopn <- genotypeFreqPopTetr              # freq of a genotype, given gamete freqs of population
            mixedGenotypeFreqGivenPopns <- mixedGenotypeFreqPopTetr      # freq of a mixed F1 genotype, given gamete freqs of 2 populations
            getSeedlingGenotypes <- getSeedlingGenotypesTetr             # list of possible genotypes for a phenotype
            gameteFreqGivenPopn <- gameteFrequencyPopTetr                # frequency of a given gamete
          }
          # Initial setup
          # -population information
          # -data output structures
          strip.NAs <- function(vv) {
            return(vv[!is.na(vv)])
          }
          if (ploidy == 6) {
            MAXSEEDLINGGENOTYPES <- 10
          } else if (ploidy == 4) {
            MAXSEEDLINGGENOTYPES <- 3
          }
          # Obtaining IDs of seedlings
          seedlingID <- with(inData,ID[!is.na(mother=="u")])
          whichAreSeedlings <- with(inData,!is.na(mother))
          seedlings <- inData[whichAreSeedlings,]
          popnsWithSeedlings <- unique(seedlings$pop)
          cat("\n\n",length(popnsWithSeedlings),"population(s) with a total of",
              #length(allMothers),"mother(s) and",
              nrow(seedlings),"progeny...\n")
          flush.console()

          #  Setup objects to receive data #
          # possible F1 combinations
          # Required later in assignment test for part c) #
          allPopns <- unique(inData$pop)
          numPopns <- length(allPopns)
          noPopCombinations<-(numPopns*(numPopns-1))/2
          popCombos<-combinations(numPopns,2,allPopns,repeats=FALSE)
          popComboMatrix<-matrix(0,1,noPopCombinations)
          for (thisCombo in 1:nrow(popCombos)) {
            Combo<- popCombos[thisCombo,]
            popComboMatrix[1,thisCombo]<-paste(Combo,collapse=" ")
          }
          #  Setup objects to receive data #
          # a) Seedling scores
          # Main data output for assignment probabilities to each population for a locus
          seedlingScores <- matrix(0,nrow=MAXSEEDLINGGENOTYPES,ncol=numPopns+ncol(popComboMatrix))
          rownames(seedlingScores) <- (1:MAXSEEDLINGGENOTYPES)
          colnames(seedlingScores) <- c(allPopns,popComboMatrix[1,])

          ## b) The L scores will be stored in a list
          ## Main data storage for assignment probabilities across loci
          LScoresMatrix <- matrix(0,nrow(seedlings),((ncol(seedlingScores))*numLoci))
          lociInfo <- paste("L.",sort(rep(1:numLoci,((ncol(seedlingScores))))),sep="")
          popCombosandPops <-c(allPopns,popComboMatrix[1,])
          numComboandPops <- length(popCombosandPops)
          columnNames <- paste(rep(popCombosandPops,numLoci),lociInfo)
          colnames(LScoresMatrix) <- columnNames
          colnames(LScoresMatrix) <- columnNames
          rownames(LScoresMatrix) <- seedlingID

          ## c) seedlingStatus records status information about each seedling at
          ##    each locus:
          ## - seedling alleles present in population = OK
          ## - seedling alleles missing in population = S
          ## - No data at locus = NoData
          seedlingStatus <- matrix("",nrow(seedlings),numLoci,
                                   dimnames=list(seedlingID,1:numLoci))

          ##########################
          ## Begin loop over loci ##
          ##########################
          cat("\n Processing locus")
          for (thisLocus in 1:numLoci) {
            # thisLocus<-1
            cat(".",thisLocus,".")
            flush.console()
            ##Define the inData column range containing the alleles for the
            locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
            # nominate what columns the current seedlings data goes to in LScoresMatrix
            colRange <- ((thisLocus-1)*numComboandPops) + (1:numComboandPops)
            # Pull out functions for particular DRR at this locus
            if (DRRtype == "fixed") {
              DRR <- as.vector(DRRtable[thisLocus,2])
              if (ploidy==6) {
                if (marker == "genotype") {
                  if (DRR == "min") {
                    getMotherGameteInfo <- getMotherGameteInfoHexGenoMin # segregation ratios: gametes from individual
                  } else if (DRR == "max") {
                    getMotherGameteInfo <- getMotherGameteInfoHexGenoMax # segregation ratios: gametes from individual
                  }
                }
                if (marker == "phenotype") {
                  if (DRR == "min") {
                    getMotherGameteInfo <- getMotherGameteInfoHexPhenoMin # segregation ratios: gametes from individual
                  } else if (DRR == "max") {
                    getMotherGameteInfo <- getMotherGameteInfoHexPhenoMax # segregation ratios: gametes from individual
                  }
                }
              }

              if (ploidy==4) {
                if (marker == "genotype") {
                  if (DRR == "min") {
                    getMotherGameteInfoGeno <- getMotherGameteInfoTetrGenoMin # segregation ratios: gametes from individual
                  } else if (DRR == "max") {
                    getMotherGameteInfoGeno <- getMotherGameteInfoTetrGenoMax # segregation ratios: gametes from individual
                  }
                }
                if (marker == "phenotype") {
                  if (DRR == "min") {
                    getMotherGameteInfoGeno <- getMotherGameteInfoTetrGenoMin # segregation ratios: gametes from individual
                    getMotherGameteInfoPheno <- getMotherGameteInfoTetrPhenoMin # segregation ratios: gametes from individual
                  } else if (DRR == "max") {
                    getMotherGameteInfoPheno <- getMotherGameteInfoTetrPhenoMax # segregation ratios: gametes from individual
                    getMotherGameteInfoGeno <- getMotherGameteInfoTetrGenoMax # segregation ratios: gametes from individual
                  }
                }
              }
            }
            # Pull out functions for particular DRR at this locus - general formulas
            if (DRRtype == "general") {
              DRR <- as.vector(DRRtable[thisLocus,1])
              if (ploidy==6) {
                getMotherGameteInfoGeno <- getMotherGameteInfoHexGenoGeneral # segregation ratios: gametes from individual
                getMotherGameteInfoPheno <- getMotherGameteInfoHexPhenoGeneral # segregation ratios: gametes from individual
              }
              if (ploidy==4) {
                getMotherGameteInfoGeno <- getMotherGameteInfoTetrGenoGeneral # segregation ratios: gametes from individual
                getMotherGameteInfoPheno <- getMotherGameteInfoTetrPhenoGeneral # segregation ratios: gametes from individual
                }
            }

            #####################################################
            ## Begin loop over populations that have seedlings ##
            #####################################################
            for (thisPopn in popnsWithSeedlings) {
              # thisPopn <- "GA"
              #cat("   Processing progeny in population",thisPopn,"\n")
              cat(".")
              flush.console()
              otherPopns <- allPopns[thisPopn!=allPopns]
              thisPopnsSeedlings <- seedlings[seedlings$pop==thisPopn,]
              thisPopnsSeedlingIDs <- seedlings[seedlings$pop==thisPopn,"ID"]

              #####################################################################
              # Begin loop over seedlings in current population (with seedlings) ##
              #####################################################################
              for (thisSeedling in thisPopnsSeedlingIDs) {
                # thisSeedling<-"1s"
                seedlingPhenotype <- strip.NAs(inData[inData$ID==thisSeedling,locusRange])
                # If no data at this locus, skips the current seedling
                if (length(seedlingPhenotype) < 1) {
                  seedlingStatus[thisSeedling,thisLocus] <- "NoData"
                  next  ## Skip to next seedling
                } else {
                  seedlingStatus[thisSeedling,thisLocus] <- "OK"
                  # Get all the alternative genotypes for a give phenotype
                  possibleSeedlingGenos <- getSeedlingGenotypes(seedlingPhenotype)
                  #length(seedlingGenotypes)
                  seedlingGenotypeCount <- 0
                }

                ############################################################
                # Begin loop over seedling genotypes for a given phenotype #
                ############################################################
                for (thisGenoNum in 1:length(possibleSeedlingGenos)) {
                  # thisGenoNum <-1
                  # thisSeedlingGeno <- possibleSeedlingGenos[thisGeno]
                  thisGeno <- as.vector(unlist(possibleSeedlingGenos[thisGenoNum]))
                  ###############################################################################
                  # a) calculate frequeny of a given genotype at equilibrium in home population #
                  ###############################################################################
                  # problem here
                  # "GN" missing all the possible gametes in table
                  # e.g. thisGeno = "212" "212" "214" "218" "220" "222"
                  # allele 222 in alleleFrequencies
                  # allele 222 NOT present in gameteFrequencies
                  seedlingScores[thisGenoNum,thisPopn] <- getProbGenotypeGivenPopn(thisGeno,
                                                            gameteFrequencies[[thisPopn]][[thisLocus]],
                                                            alleleFrequencies[[thisPopn]][[thisLocus]],
                                                            epsilon3)
                  ######################################################################################
                  # b) calculate frequency of a given genotype at equilibrium in all other populations  #
                  ######################################################################################
                  for (thatPopn in otherPopns) {
                    # thatPopn<-"GI"
                    seedlingScores[thisGenoNum,thatPopn] <- getProbGenotypeGivenPopn(thisGeno,
                                                               gameteFrequencies[[thatPopn]][[thisLocus]],
                                                               alleleFrequencies[[thatPopn]][[thisLocus]],
                                                               epsilon3)
                  }
                  ######################################################################################
                  # c) calculate frequency of a F1 mixed genotype between all population pairs          #
                  ######################################################################################
                  #seedlingAlleles<-unique(seedlingGenotypes[[thisSeedlingGeno]])
                  #thisCurrentSeedlingGeno<-seedlingGenotypes[[thisSeedlingGeno]]
                  # possible F1 combinations

                  for (thisCombo in 1:noPopCombinations) {
                    # test thisCombo<-2
                    #thisGenotype<- possibleSeedlingGenos[[thisGeno]]
                    thisPopninCombo<-popCombos[thisCombo,1]
                    thatPopninCombo<-popCombos[thisCombo,2]
                    twoPops<-paste(thisPopninCombo,thatPopninCombo, collapse=" ")
                    seedlingScores[thisGenoNum,twoPops]<- mixedGenotypeFreqGivenPopns(thisGeno,thisLocus,thisPopninCombo,
                                                                                      thatPopninCombo,gameteFrequencies,epsilon3)
                  } # End loop over pop combos
                } ## End loop over possible seedling genotypes
                LScoresMatrix[thisSeedling,colRange] <- as.vector(apply(seedlingScores[1:length(possibleSeedlingGenos),,drop=FALSE],2,sum))
                #LScores[[thisLocus]][[thisSeedling]] <- as.vector(apply(seedlingScores[1:length(possibleSeedlingGenos),,drop=FALSE],2,mean))
                seedlingScores[,] <- 0  ##Clear this out before the seedling...
              } ## End loop over seedlings
            } ##End loop over populations with seedlings
          } ##End loop over loci
          cat("\n ** Assignment testing...... COMPLETE **\n\n")
          #LScoresMatrix <- LScoresMatrix[,2:ncol(LScoresMatrix)]
          return(list(LScoresMatrix=LScoresMatrix,seedlingStatus=seedlingStatus))
        }
        }

        cat("\n ** Beginning Assignment test.... **\n")
        flush.console()

    outputAssign <- assign.popMain(inData,alleleFrequencies,gameteFrequencies,
                                   numLoci,ploidy,motherknown,DRRtable,DRRtype,segregationRatios)
    return(outputAssign)
    }
