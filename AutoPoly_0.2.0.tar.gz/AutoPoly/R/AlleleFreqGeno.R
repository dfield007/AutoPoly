#' calculates the allele frequencies in each population (genotypes)
#'
#' the procedure calculates the allele frequencies for genotype data.
#' Other fuctions must be run prior to this function to generate required data (see details)
#' @param inData character, name of data file to import (see Details)
#' @param numLoci numeric, number of loci in the data set
#' @param ploidy numeric, number of homologous chromosomes. Must be 4 or 6 (i.e. tetraploid or hexaploid).
#' @param replacement logical, whether to account for missing alleles in populations (TRUE) or use strictly the observed data (FALSE).
#' @details
#' \emph{Missing alleles and population assignment}
#' \itemize{
#'  \item {When an allele is absent from population i, this results in a zero probability of gametes and genotypes
#'  that carry that allele. This reduces the probability of the multilocus genotype/phenotype to zero,
#'  although the particular allele may be rare in the population or missing among the reference individuals (Cornuet et al., 1999).
#'  }
#'  \item {To account for this problem, we let the frequency of the absent allele be proportional to the inverse of the number of gene
#'  copies at the locus, adjusted by the number of observed alleles as, p_kji = (1/K_j)⁄(N_ij * Y), where K_j is the total number
#'  of alleles detected across all populations for the jth locus, N_ij are the total number of individuals sampled in the ith
#'  candidate population and Y is the ploidy level (e.g. Y = 6 for hexaploid).
#'  Given this allele frequency we re-calculate the probability of the null phenotype/genotype at the given locus.}
#' }
#' @return procudes a list containing allele frequencies for each locus for each population
#' @author David L. Field
#' @examples
#' # access data provided with AutoPoly
#' # Simulated genotypes, ploidy=4, numLoci=24,mother known
#' data(x4_Fst0_13_Sim)
#' write.csv(x4_Fst0_13_Sim,"x4_Fst0_13_Sim.csv",quote=F,row.names=F)
#'
#' # Step 1. Make table for Double Reduction Rates (DRR) at each locus.
#' DRRtable_1 <- DRRsetup(numLoci=24,ploidy=4,propDRR=1)
#'
#' # 2. import and process data
#' simGenos <- inputData("x4_Fst0_13_Sim.csv",numLoci=24,lociMin=5,ploidy=4,marker="genotype",cohorts=T,motherknown=T,DRRtable_1)
#'
#' # 3. allele frequencies
#' alleleFreq <- alleleFreqGeno(inData=simGenos,numLoci=24,ploidy=4,replacement=TRUE)
#'
#' @export
alleleFreqGeno <- function(inData,numLoci,ploidy,replacement) {
  cat("\n         Calculating Allele Frequencies....")
  flush.console()
  alleleFrequenciesMain<-function(inData,numLoci,ploidy) {
  strip.NAs <- function(vv) {
    return(vv[!is.na(vv)])
  }
  lociRanges <- matrix(4:ncol(inData),ncol=ploidy,byrow=TRUE)
  ##Strip out the seedlings, leaving adults and mothers:
  inData_subset <- subset(inData,subset=is.na(mother))

  # find the full set of available alleles
  alleleLists <- list()
  for (thisLocus in 1:nrow(lociRanges)) {
    # thisLocus <- 1
    alleles <- unique(unlist(inData_subset[,lociRanges[thisLocus,]]))
    alleles <- sort(alleles[!is.na(alleles)])
    alleleLists[[thisLocus]] <- alleles
  }

  ##Split up the populations:
  popnList <- split(inData_subset,inData_subset$pop)
  alleleFrequenciesTable <- lapply(popnList,
    function (thisPopn) {
       locusAlleleProbs <- list()
       for (thisLocus in 1:numLoci) {
        #test thisLocus<-1
        #test thisPopn<-popnList[[1]]
        thisPopnThisLocus<-thisPopn[,lociRanges[thisLocus,]]
        #remove adults with no data
        numAdults<-nrow(thisPopnThisLocus)
        goodAdults<-matrix(0,nrow=numAdults)
        for (thisAdult in 1:numAdults) {
          #test thisAdult<-1
          if (sum(is.na(thisPopnThisLocus[thisAdult,]))!=ploidy) {
            goodAdults[thisAdult,]<-rownames(thisPopnThisLocus[thisAdult,])
          }
        }
        goodAdults<-goodAdults[goodAdults!=0,]
        thisPopnThisLocus<-thisPopnThisLocus[goodAdults,]
        #get number of adults
        numAdults<-nrow(thisPopnThisLocus)
        ##Get unique alleles at current locus in current population
        popnAlleles <- sort(strip.NAs(unique(unlist(thisPopnThisLocus))))
        allAlleles <- alleleLists[[thisLocus]]
        ##The matrix of allele frequencies for each adult
        if (replacement==FALSE) {
          alleleMatrix <- matrix(0,nrow=numAdults,ncol=length(popnAlleles))
          colnames(alleleMatrix) <- popnAlleles
          # Get total number of alleles in population
          popnAllelesNum<-ploidy*numAdults
          # Number of each allele
          numEachAllele<-table(unlist(thisPopnThisLocus))
          # Frequency of each allele
          locusAlleleProbs[[thisLocus]]<-numEachAllele/popnAllelesNum
        }
        if (replacement==TRUE) {
          alleleMatrix <- matrix(0,nrow=numAdults,ncol=length(popnAlleles))
          colnames(alleleMatrix) <- popnAlleles
          # Get total number of alleles in population
          popnAllelesNum<-ploidy*numAdults
          # Number of each allele
          numEachAllele<-table(unlist(thisPopnThisLocus))
          # Frequency of each allele
          meanAlleleFreq <- numEachAllele/popnAllelesNum
          allelesToAdd <- allAlleles[is.na(match(allAlleles,popnAlleles))]
          replacementFactor <- (1/length(allAlleles))/(numAdults*ploidy)
          missingAlleles <- rep(replacementFactor,length(allelesToAdd))
          names(missingAlleles) <- allelesToAdd
          sumReplacementFactor <- sum(missingAlleles)
          reductionVal <- sumReplacementFactor/length(popnAlleles)
          meanAlleleFreq_adjust <- meanAlleleFreq-reductionVal
          locusAlleleProbs[[thisLocus]] <- sort(c(meanAlleleFreq_adjust,missingAlleles))
        }
      } ##End thisLocus loop
      return(locusAlleleProbs)
    } ##End thisPopn lapply function
  )
  cat("COMPLETE")
  return(alleleFrequenciesTable)
 }
 return(alleleFrequenciesMain(inData,numLoci,ploidy))
}
