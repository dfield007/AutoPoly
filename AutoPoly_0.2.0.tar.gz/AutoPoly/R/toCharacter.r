#' function to ensure character conversion
#' @author David L. Field
#' @export
to.character <-  function(data.fr, cols=NULL) {
    ##Takes a dataframe and a vector of columns that are to be converted
    ## to character vectors.  Returns the modified dataframe.
    ##The cols argument can be a character vector of column names, a
    ## vector of column indices, or NULL (the default). If cols is NULL,
    ## all columns are converted.
    if (!is.data.frame(data.fr)) stop("First argument must be a dataframe")
    if (is.null(cols)) {cols <- names(data.fr)}
    if (is.vector(cols) & (is.character(cols) | is.numeric(cols))) {
      for (colmn in cols) {
        data.fr[[colmn]] <- as.character(data.fr[[colmn]])
      }
      return(data.fr)
    } else {
      stop("\n Error: cols argument must be an integer or character vector, or NULL")
    }
    }
