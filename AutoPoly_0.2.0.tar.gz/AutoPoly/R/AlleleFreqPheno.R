#' calculates the allele frequencies in each population (phenotypes)
#'
#' the procedure calculates the allele frequencies for phenotype data by marginalising with respect to genotype.
#' Other fuctions must be run prior to this function to generate required data (see details)
#' @param inData character, name of data file to import (see Details)
#' @param numLoci numeric, number of loci in the data set
#' @param ploidy numeric, number of homologous chromosomes. Must be 4 or 6 (i.e. tetraploid or hexaploid).
#' @param replacement logical, whether to account for missing alleles in populations (TRUE) or use strictly the observed data (FALSE).
#' @details
#' \emph{Allelic dosage}
#' \itemize{
#'  \item {With phenotype data, for any given individual we usually dont know the number of copies of each allele}
#'  \item {This method uses a simple marginal estimate with respect to genotype (see Field et al., in review)}
#'  }
#' \emph{Missing alleles and population assignment}
#' \itemize{
#'  \item {When an allele is absent from a population, this results in a zero probability of gametes and genotypes
#'  that carry that allele. This reduces the probability of the multilocus genotype/phenotype to zero,
#'  although the particular allele may be rare in the population or missing among the reference individuals (Cornuet et al., 1999).
#'  }
#'  \item {To account for this problem, when replacement = TRUE, we let the frequency of the absent allele be proportional to the inverse of the number of gene
#'  copies at the locus, adjusted by the number of observed alleles as, $p_{kji} = (1/K_j)⁄(N_{ij} * Y)$, where $K_j$ is the total number
#'  of alleles detected across all populations for the jth locus, $N_{ij}$ are the total number of individuals sampled in the ith
#'  candidate population and $Y$ is the ploidy level (e.g. $Y$ = 6 for hexaploid).
#'  Given this allele frequency we re-calculate the probability of the null phenotype/genotype at the given locus.}
#' }
#' @return procudes a list containing allele frequencies for each locus for each population
#' @author David L. Field
#' @examples
#' # Empirical data example.
#' # Eremophila glabra data consists of: 6 SSR loci, phenotypes, mother known, DRR and segregation ratios unknown.
#' data(Eremophila)
#' write.csv(Eremophila,"Eremophila_mumKnown.csv",quote=F,row.names=F)
#'
#' # 1. Make table with the Double Reduction Rates (DRR) at each locus.
#' DRRtable_1 <- DRRsetup(numLoci=6,ploidy=6,propDRR=1)
#'
#' # 2. import and process data
#' EremophilaData <- inputData("Eremophila_mumKnown.csv",numLoci=6,lociMin=5,ploidy=6,marker="phenotype",cohorts=T,motherknown=T,DRRtable_1)
#'
#' # 3. allele frequencies
#' alleleFreq <- alleleFreqPheno(EremophilaData,numLoci=6,ploidy=6,replacement=T)
#' @export
alleleFreqPheno <- function(inData,numLoci,ploidy,replacement) {
  cat("\n         Calculating Allele Frequencies....")
  flush.console()
  alleleFrequenciesMain <- function(inData,numLoci,ploidy,replacement) {
              strip.NAs <- function(vv) {
                return(vv[!is.na(vv)])
              }
              lociRanges <- matrix(4:ncol(inData),ncol=ploidy,byrow=TRUE)
              ##Strip out the seedlings, leaving adults and mothers:
              inData_subset <- subset(inData,subset=is.na(mother))

              # find the full set of available alleles
              alleleLists <- list()
              for (thisLocus in 1:nrow(lociRanges)) {
                # thisLocus <- 1
                alleles <- unique(unlist(inData_subset[,lociRanges[thisLocus,]]))
                alleles <- sort(alleles[!is.na(alleles)])
                alleleLists[[thisLocus]] <- alleles
              }
              ##Split up the populations:
              popnList <- split(inData_subset,inData_subset$pop)
              alleleFrequenciesTable <- lapply(popnList,
                              function (thisPopn) {
                                locusAlleleProbs <- list()
                                for (thisLocus in 1:numLoci) {
                                  # thisLocus <- 1
                                  # thisPopn <- popnList[[1]]
                                  thisPopnThisLocus <- thisPopn[,lociRanges[thisLocus,]]
                                  #remove adults with no data
                                  numAdults <- nrow(thisPopnThisLocus)
                                  goodAdults <- matrix(0,nrow=numAdults)
                                  for (thisAdult in 1:numAdults) {
                                     # thisAdult <- 1
                                     if (sum(is.na(thisPopnThisLocus[thisAdult,])) != ploidy) {
                                        goodAdults[thisAdult,] <- rownames(thisPopnThisLocus[thisAdult,])
                                     }
                                  }
                                  goodAdults <- goodAdults[goodAdults!=0,]
                                  thisPopnThisLocus <- thisPopnThisLocus[goodAdults,]
                                  #get number of adults
                                  numAdults <- nrow(thisPopnThisLocus)
                                  ##Get unique alleles at current locus in current population
                                  popnAlleles <- sort(strip.NAs(unique(unlist(thisPopnThisLocus))))
                                  allAlleles <- alleleLists[[thisLocus]]
                                  ##The matrix of allele frequencies for each adult
                                  if (replacement==FALSE) {
                                    alleleMatrix <- matrix(0,nrow=numAdults,ncol=length(popnAlleles))
                                    colnames(alleleMatrix) <- popnAlleles
                                    for (thisAdult in 1:numAdults) {
                                      # thisAdult <- 1
                                      thisAdultsAlleles <- strip.NAs(thisPopnThisLocus[thisAdult,])
                                      if (mode(thisAdultsAlleles)=="numeric") {
                                        thisAdultsAlleles <- unlist(strsplit(as.character(thisAdultsAlleles)," "))
                                      }
                                      alleleMatrix[thisAdult,thisAdultsAlleles] <- 1/length(thisAdultsAlleles)
                                    }
                                    locusAlleleProbs[[thisLocus]] <- apply(alleleMatrix,2,mean)
                                  }
                                  if (replacement==TRUE) {
                                    alleleMatrix <- matrix(0,nrow=numAdults,ncol=length(popnAlleles))
                                    colnames(alleleMatrix) <- popnAlleles
                                    for (thisAdult in 1:numAdults) {
                                      # thisAdult <- 1
                                      thisAdultsAlleles <- strip.NAs(thisPopnThisLocus[thisAdult,])
                                      if (mode(thisAdultsAlleles)=="numeric") {
                                        thisAdultsAlleles <- unlist(strsplit(as.character(thisAdultsAlleles)," "))
                                      }
                                      alleleMatrix[thisAdult,thisAdultsAlleles] <- 1/length(thisAdultsAlleles)
                                    }
                                    meanAlleleFreq <- apply(alleleMatrix,2,mean)
                                    allelesToAdd <- allAlleles[is.na(match(allAlleles,popnAlleles))]
                                    replacementFactor <- (1/length(allAlleles))/(numAdults*ploidy)
                                    missingAlleles <- rep(replacementFactor,length(allelesToAdd))
                                    names(missingAlleles) <- allelesToAdd
                                    sumReplacementFactor <- sum(missingAlleles)
                                    reductionVal <- sumReplacementFactor/length(popnAlleles)
                                    meanAlleleFreq_adjust <- meanAlleleFreq-reductionVal
                                    # sum(meanAlleleFreq_adjust)+sum(missingAlleles)
                                    locusAlleleProbs[[thisLocus]] <- sort(c(meanAlleleFreq_adjust,missingAlleles))
                                  }
                                } ## End thisLocus loop
                              return(locusAlleleProbs)
                             } ##End thisPopn lapply function
                            )
                          cat("COMPLETE")
                          return(alleleFrequenciesTable)
                        }
                      return(alleleFrequenciesMain(inData,numLoci,ploidy,replacement))
}
