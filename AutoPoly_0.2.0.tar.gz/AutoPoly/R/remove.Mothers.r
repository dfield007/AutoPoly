#' function to reduce the number of loci in a data set
#' @author David L. Field
#' @export
# function to remove mothers
removeMothers <- function(inData) {
      whichHaveMothers <- with(inData,!is.na(mother))
      inData[whichHaveMothers,"mother"] <- "u"
      return(inData)
      }
