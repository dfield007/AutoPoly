#' Summary statistics for a batch run for final power testing
#'
#' @export
summaryPowerTest <- function(simPostHoc,batchResults,thisBatch,motherknown) {

    #########################
    # Accuracy & Efficiency #
    #########################
    cat("\n ** Calculating Summary Statistics.... **\n")
    flush.console()
    # Overall Accuracy and accuracy by cross type
    # Separate correct individuals
    correctAssign <- simPostHoc[,"1"]== simPostHoc[,"ActualCross"]
    Correct <- simPostHoc[correctAssign,]
    # Separate Incorrect individuals
    InCorrect <- simPostHoc[,"1"]!= simPostHoc[,"ActualCross"]
    incorrectAssign <- simPostHoc[,"1"]!= simPostHoc[,"ActualCross"]
    InCorrect <- simPostHoc[incorrectAssign,]
    # Overall accuracy
    grandTotal <- nrow(Correct) + nrow(InCorrect)
    OverallpercentCorrect <- nrow(Correct)/grandTotal
    batchResults[[1]][thisBatch,"Accuracy_Total"] <- round(as.vector(OverallpercentCorrect),3)
    #AssignmentCorrect <- matrix(correctAssign,nrow(simPostHoc),1)
    #colnames(AssignmentCorrect) <- "Correct"
    #simPostHoc <- cbind(simPostHoc,AssignmentCorrect)

    # Accuracy Within Population crosses
    thisRunWithinPop <- simPostHoc[simPostHoc[,"CrossType"] == "W_POP",]
    correctAssignWithin <- as.vector(thisRunWithinPop[,"1"]) == thisRunWithinPop[,"ActualCross"]
    incorrectAssignWithin <- thisRunWithinPop[,"1"]!= thisRunWithinPop[,"ActualCross"]
    CorrectWithin <- thisRunWithinPop[correctAssignWithin,]
    InCorrectWithin <- thisRunWithinPop[incorrectAssignWithin,]
    grandTotalWithin <- nrow(CorrectWithin) + nrow(InCorrectWithin)
    OverallpercentCorrectWithin <- nrow(CorrectWithin)/grandTotalWithin
    batchResults[[1]][thisBatch,"Accuracy_WIPOP"] <- round(as.vector(OverallpercentCorrectWithin),3)

    # Accuracy Between Population crosses
    thisRunBetweenPop <- simPostHoc[simPostHoc[,"CrossType"] == "B_POP",]
    correctAssignBetween <- as.vector(thisRunBetweenPop[,"1"]) == thisRunBetweenPop[,"ActualCross"]
    incorrectAssignBetween <- thisRunBetweenPop[,"1"]!= thisRunBetweenPop[,"ActualCross"]
    CorrectBetween <- thisRunWithinPop[correctAssignBetween,]
    InCorrectBetween <- thisRunWithinPop[incorrectAssignBetween,]
    grandTotalBetween <- nrow(CorrectBetween) + nrow(InCorrectBetween)
    OverallpercentCorrectBetween <- nrow(CorrectBetween)/grandTotalBetween
    batchResults[[1]][thisBatch,"Accuracy_BWPOP"] <- round(as.vector(OverallpercentCorrectBetween),3)

    # Efficiency Within Population Crosses
    numActual_W_POP <- sum(as.numeric(simPostHoc$CrossType == "W_POP"))
    numDetected_W_POP <- sum(as.numeric(as.vector(simPostHoc[,"1"]) == as.vector(simPostHoc[,"homePopn"])))
    theseDetected_W_POP <- as.vector(simPostHoc[,"1"]) == as.vector(simPostHoc[,"homePopn"])
    theseDetected_W_POP <- simPostHoc[theseDetected_W_POP==TRUE,]
    correctAssignWithin_Eff <- as.vector(theseDetected_W_POP[,"1"]) == theseDetected_W_POP[,"ActualCross"]
    incorrectAssignWithin_Eff <- theseDetected_W_POP[,"1"]!= theseDetected_W_POP[,"ActualCross"]
    CorrectWithin_Eff <- theseDetected_W_POP[correctAssignWithin_Eff,]
    InCorrectWithin_Eff <- theseDetected_W_POP[incorrectAssignWithin_Eff,]
    grandTotalWithin_Eff <- nrow(CorrectWithin_Eff) + nrow(InCorrectWithin_Eff)
    OverallpercentCorrectWithin_Eff <- nrow(CorrectWithin_Eff)/grandTotalWithin_Eff
    batchResults[[1]][thisBatch,"Efficiency_WIPOP"] <- round(as.vector(OverallpercentCorrectWithin_Eff),3)

    # Efficiency Between Population Crosses
    numActual_B_POP <- sum(as.numeric(simPostHoc$CrossType == "B_POP"))
    numDetected_B_POP <- sum(as.numeric(as.vector(simPostHoc[,"1"]) != as.vector(simPostHoc[,"homePopn"])))
    theseDetected_B_POP <- as.vector(simPostHoc[,"1"]) != as.vector(simPostHoc[,"homePopn"])
    theseDetected_B_POP <- simPostHoc[theseDetected_B_POP==TRUE,]
    correctAssignBetween_Eff <- as.vector(theseDetected_B_POP[,"1"]) == theseDetected_B_POP[,"ActualCross"]
    incorrectAssignBetween_Eff <- theseDetected_B_POP[,"1"]!= theseDetected_B_POP[,"ActualCross"]
    CorrectBetween_Eff <- theseDetected_B_POP[correctAssignBetween_Eff,]
    InCorrectBetween_Eff <- theseDetected_B_POP[incorrectAssignBetween_Eff,]
    grandTotalBetween_Eff <- nrow(CorrectBetween_Eff) + nrow(InCorrectBetween_Eff)
    OverallpercentCorrectBetween_Eff <- nrow(CorrectBetween_Eff)/grandTotalBetween_Eff
    batchResults[[1]][thisBatch,"Efficiency_BWPOP"] <- round(as.vector(OverallpercentCorrectBetween_Eff),3)

    # Overall % of B-Pop crosses detected (correct or incorrect)
    totalIndProg <- grandTotalBetween_Eff + grandTotalWithin_Eff
    B_POP_Detect <- numDetected_B_POP/totalIndProg
    batchResults[[1]][thisBatch,"B-POP Estimate"] <- B_POP_Detect

    ##################
    # Critical Delta #
    ##################

    # Object with all Delta1 scores
    allDelta1 <- simPostHoc[,"Delta1"]
    allDelta1Sorted <- sort(simPostHoc[,"Delta1"])
    critcal80<-"empty"
    critcal90<-"empty"
    critcal95<-"empty"
    critcal99<-"empty"
    Correcttest80<-NULL
    Correcttest90<-NULL
    Correcttest95<-NULL
    Correcttest99<-NULL
    Unresolved80<-NULL
    Unresolved90<-NULL
    Unresolved95<-NULL
    Unresolved99<-NULL
    percentAssignableat80<-NULL
    percentAssignableat90<-NULL
    percentAssignableat95<-NULL
    percentAssignableat99<-NULL

    ########################
    # Loop over all Delta1 #
    ########################
    for (thisDelta in allDelta1Sorted) {
        # thisDelta<- allDelta1Sorted[1]
        Correcttest <- sum(as.numeric(Correct$"Delta1">=thisDelta))
        InCorrecttest <- sum(as.numeric(InCorrect$"Delta1">=thisDelta))
        PercentCorrect <- Correcttest/(Correcttest + InCorrecttest)
        # finding the critical regions for 80, 90, 95, 99% confidence
        if (PercentCorrect >= 0.80 & critcal80=="empty") {
            critcal80 <- thisDelta
            batchResults[[1]][thisBatch,"Critical80"] <- round(critcal80,3)
            Correcttest80 <- sum(as.numeric(allDelta1>=critcal80))
            Unresolved80 <- sum(as.numeric(allDelta1<critcal80))
            percentAssignableat80 <- Correcttest80/(Correcttest80+Unresolved80)
            batchResults[[1]][thisBatch,"Assign80"] <- round(percentAssignableat80,3)
        }
        if (PercentCorrect >= 0.90 & critcal90=="empty") {
            critcal90 <- thisDelta
            batchResults[[1]][thisBatch,"Critical90"] <- round(critcal90,3)
            Correcttest90<- sum(as.numeric(allDelta1>=critcal90))
            Unresolved90<- sum(as.numeric(allDelta1<critcal90))
            percentAssignableat90<- Correcttest90/(Correcttest90+Unresolved90)
            batchResults[[1]][thisBatch,"Assign90"] <- round(percentAssignableat90,3)
        }
        if (PercentCorrect >= 0.95 & critcal95=="empty") {
            critcal95 <- thisDelta
            batchResults[[1]][thisBatch,"Critical95"] <- round(critcal95,3)
            Correcttest95<- sum(as.numeric(allDelta1>=critcal95))
            Unresolved95<- sum(as.numeric(allDelta1<critcal95))
            percentAssignableat95<- Correcttest95/(Correcttest95+Unresolved95)
            batchResults[[1]][thisBatch,"Assign95"] <- round(percentAssignableat95,3)
        }
        if (PercentCorrect >= 0.99 & critcal99=="empty") {
            critcal99 <- thisDelta
            batchResults[[1]][thisBatch,"Critical99"] <- round(critcal99,3)
            Correcttest99<- sum(as.numeric(allDelta1>=critcal99))
            Unresolved99<- sum(as.numeric(allDelta1<critcal99))
            percentAssignableat99<- Correcttest99/(Correcttest99+Unresolved99)
            batchResults[[1]][thisBatch,"Assign99"] <- round(percentAssignableat99,3)
        }
    }

    # Frequency Distribution figure of log likelihoods
    # Within Pop Crosses
     # Within pop crosses within Pop A
     logLikelihoods_AinA <- thisRunWithinPop[thisRunWithinPop[,"homePopn"]=="A","A"]
     logLikelihoods_BinA <- thisRunWithinPop[thisRunWithinPop[,"homePopn"]=="B","A"]
     logLikelihoods_BinB <- thisRunWithinPop[thisRunWithinPop[,"homePopn"]=="B","B"]
     logLikelihoods_AinB <- thisRunWithinPop[thisRunWithinPop[,"homePopn"]=="A","B"]

     if (motherknown==TRUE) {
     # Between pop crosses with Pop A & B
      # mother in A
     thisDataSetA <- thisRunBetweenPop[as.vector(thisRunBetweenPop[,"homePopn"]) == "A",]
     thisDataSetA <- thisDataSetA[as.vector(thisDataSetA[,"ActualCross"]) == "B",]
     thisDataSetA <- thisDataSetA[as.vector(thisDataSetA[,"Correct"]) ==TRUE,]
     logLikelihoods_Actual_F1_AxB_BScores_Correct <- thisDataSetA[,"B"]
     logLikelihoods_Actual_F1_AxB_AScores_Incorrect <- thisDataSetA[,"A"]
      # mother in B (reciprocal cross)
     thisDataSetB <- thisRunBetweenPop[as.vector(thisRunBetweenPop[,"homePopn"]) == "B",]
     thisDataSetB <- thisDataSetB[as.vector(thisDataSetB[,"ActualCross"]) == "A",]
     thisDataSetB <- thisDataSetB[as.vector(thisDataSetB[,"Correct"]) == TRUE,]
     logLikelihoods_Actual_F1_BxA_AScores_Correct <- thisDataSetB[,"A"]
     logLikelihoods_Actual_F1_BxA_BScores_Incorrect <- thisDataSetB[,"B"]

     # Likelihoods of F1 for actual cross between popA and popB
     logLikelihoods_Actual_F1_AxB_BothDirections <- c(logLikelihoods_Actual_F1_AxB_BScores_Correct,
                                                          logLikelihoods_Actual_F1_BxA_AScores_Correct)
     # Likelihoods of belonging solely to popA or popB when progeny actually a cross between A & B
     logLikelihoods_Actual_F1_AxB_IncorrectHomeA <- logLikelihoods_Actual_F1_AxB_AScores_Incorrect
     logLikelihoods_Actual_F1_AxB_IncorrectHomeB <- logLikelihoods_Actual_F1_BxA_BScores_Incorrect
     }
     if (motherknown==FALSE) {
     # Between pop crosses with Pop A & B
      # mother in A
     thisDataSetA <- thisRunBetweenPop[as.vector(thisRunBetweenPop[,"homePopn"]) == "A",]
     thisDataSetA <- thisDataSetA[as.vector(thisDataSetA[,"ActualCross"]) == "A B",]
     #thisDataSetA <- thisDataSetA[as.vector(thisDataSetA[,"Correct"]) == TRUE,]
     logLikelihoods_Actual_F1_AxB_BScores_Correct <- thisDataSetA[,"A B"]
     logLikelihoods_Actual_F1_AxB_AScores_Incorrect <- thisDataSetA[,"A"]
      # mother in B (reciprocal cross)
     thisDataSetB <- thisRunBetweenPop[as.vector(thisRunBetweenPop[,"homePopn"]) == "B",]
     thisDataSetB <- thisDataSetB[as.vector(thisDataSetB[,"ActualCross"]) == "A B",]
     #thisDataSetB <- thisDataSetB[as.vector(thisDataSetB[,"Correct"]) == TRUE,]
     logLikelihoods_Actual_F1_BxA_AScores_Correct <- thisDataSetB[,"A B"]
     logLikelihoods_Actual_F1_BxA_BScores_Incorrect <- thisDataSetB[,"B"]

     # Likelihoods of F1 for actual cross between popA and popB
     logLikelihoods_Actual_F1_AxB_BothDirections <- c(logLikelihoods_Actual_F1_AxB_BScores_Correct,
                                                          logLikelihoods_Actual_F1_BxA_AScores_Correct)
     # Likelihoods of belonging solely to popA or popB when progeny actually a cross between A & B
     logLikelihoods_Actual_F1_AxB_IncorrectHomeA <- logLikelihoods_Actual_F1_AxB_AScores_Incorrect
     logLikelihoods_Actual_F1_AxB_IncorrectHomeB <- logLikelihoods_Actual_F1_BxA_BScores_Incorrect
     }

     # Bin Arrays for log likelihoods
     numPops <- length(unique(simPostHoc[,"homePopn"]))
     minValue <- min(simPostHoc[,4:(3+numPops)])
     maxValue <- max(simPostHoc[,4:(3+numPops)])
     rangeLikelihoods <- minValue - maxValue
     binArrays <- seq(length=20,from=minValue,to=maxValue)
     breaks <- binArrays
     table_logLikelihoods_AinA <- as.matrix(table(cut(logLikelihoods_AinA, breaks)))
     table_logLikelihoods_BinA <- as.matrix(table(cut(logLikelihoods_BinA, breaks)))
     table_logLikelihoods_BinB <- as.matrix(table(cut(logLikelihoods_BinB, breaks)))
     table_logLikelihoods_AinB <- as.matrix(table(cut(logLikelihoods_AinB, breaks)))
     table_logLikelihoods_Actual_F1_AxB_BothDirections <- as.matrix(table(cut(logLikelihoods_Actual_F1_AxB_BothDirections, breaks)))
     table_logLikelihoods_Actual_F1_AxB_IncorrectHomeA <- as.matrix(table(cut(logLikelihoods_Actual_F1_AxB_IncorrectHomeA, breaks)))
     table_logLikelihoods_Actual_F1_AxB_IncorrectHomeB <- as.matrix(table(cut(logLikelihoods_Actual_F1_AxB_IncorrectHomeB, breaks)))
     colnames(table_logLikelihoods_AinA) <- "AinA"
     colnames(table_logLikelihoods_BinA) <- "BinA"
     colnames(table_logLikelihoods_BinB) <- "BinB"
     colnames(table_logLikelihoods_AinB) <- "AinB"
     colnames(table_logLikelihoods_Actual_F1_AxB_BothDirections) <- "F1_AxB"
     colnames(table_logLikelihoods_Actual_F1_AxB_IncorrectHomeA) <- "F1_ButIncorrectA"
     colnames(table_logLikelihoods_Actual_F1_AxB_IncorrectHomeB) <- "F1_ButIncorrectB"

     finalFrequencyTable <- cbind(table_logLikelihoods_AinA,
                                  table_logLikelihoods_BinA,
                                  table_logLikelihoods_BinB,
                                  table_logLikelihoods_AinB,
                                  table_logLikelihoods_Actual_F1_AxB_BothDirections,
                                  table_logLikelihoods_Actual_F1_AxB_IncorrectHomeA,
                                  table_logLikelihoods_Actual_F1_AxB_IncorrectHomeB)

     # Save sample log likelihoods
     likelihoodsWithin <- matrix(0,length(logLikelihoods_AinA),4)
     colnames(likelihoodsWithin) <- c("AinA","AinB","BinB","BinA")
     likelihoodsWithin[,1] <- logLikelihoods_AinA
     likelihoodsWithin[,2] <- logLikelihoods_AinB
     likelihoodsWithin[,3] <- logLikelihoods_BinB
     likelihoodsWithin[,4] <- logLikelihoods_BinA

     likelihoodsBetweenAxB <- matrix(0,length(logLikelihoods_Actual_F1_AxB_BScores_Correct),2)
     colnames(likelihoodsBetweenAxB) <- c("F1_AxB","A")
     likelihoodsBetweenAxB[,1] <- logLikelihoods_Actual_F1_AxB_BScores_Correct
     likelihoodsBetweenAxB[,2] <- logLikelihoods_Actual_F1_AxB_AScores_Incorrect

     likelihoodsBetweenBxA <- matrix(0,length(logLikelihoods_Actual_F1_BxA_AScores_Correct),2)
     colnames(likelihoodsBetweenBxA) <- c("F1_BxA","B")
     likelihoodsBetweenBxA[,1] <- logLikelihoods_Actual_F1_BxA_AScores_Correct
     likelihoodsBetweenBxA[,2] <- logLikelihoods_Actual_F1_BxA_BScores_Incorrect

     # Bin Arrays for Delta Scores
     # Sort by Delta1
     CorrectSorted <- sort(Correct[,"Delta1"])
     InCorrectSorted <- sort(InCorrect[,"Delta1"])
     minValueDelta1 <- min(c(CorrectSorted,InCorrectSorted))
     maxValueDelta1 <- max(c(CorrectSorted,InCorrectSorted))
     rangeLikelihoodsDelta1 <- maxValueDelta1 - minValueDelta1
     binArraysDelta1 <- seq(length=20,from=minValueDelta1,to=maxValueDelta1)
     breaks <- binArraysDelta1
     table_Correct_Delta1 <- as.matrix(table(cut(CorrectSorted, breaks)))
     table_InCorrect_Delta1 <- as.matrix(table(cut(InCorrectSorted, breaks)))
     Delta1_Table <- cbind(table_Correct_Delta1,table_InCorrect_Delta1)
     colnames(Delta1_Table) <- c("Correct","Incorrect")

     # Send data to batchResults
     batchParameters <- batchParameters
     batchResults[["batchResults"]][[thisBatch]][["Final Frequency Table"]] <- finalFrequencyTable
     batchResults[["batchResults"]][[thisBatch]][["Log likelilhoods Sample - Within"]] <- likelihoodsWithin
     batchResults[["batchResults"]][[thisBatch]][["Log likelilhoods Sample - Between (AxB)"]] <- likelihoodsBetweenAxB
     batchResults[["batchResults"]][[thisBatch]][["Log likelilhoods Sample - Between (BxA)"]] <- likelihoodsBetweenBxA
     batchResults[["batchResults"]][[thisBatch]][["Delta1 Table"]] <- Delta1_Table
     return(batchResults)
  }
