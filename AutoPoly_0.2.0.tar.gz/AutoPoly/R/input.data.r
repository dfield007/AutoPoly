#' import a genotype/phenotype data file
#'
#' imports an external data file (*.csv) and performs various processing tasks (see details)
#' required prior to population assignment \code{\link{pop.assign}}
#'
#' @param filename character, name of data file to import (see Details)
#' @param numLoci numeric, number of loci in data file
#' @param lociMin numeric, minimum number of loci (with data) required for importing an individual. Those individuals < minimum are removed from dataset
#' @param ploidy numeric, number of homologous chromosomes. Must be 4 or 6 (i.e. tetraploid or hexaploid).
#' @param marker character, must be either “phenotype” (allele copy number unknown) or “genotype” (allele copy number known).
#' @param cohorts logical, must be either TRUE (i.e. data set contains adults and progeny) or FALSE (i.e. data set contains only adults).
#' @param motherknown logical, must be either TRUE (i.e. progeny collected from known mothers but father unknown) or FALSE (i.e. progeny from unknown mother or father).
#' @param DRRtable data matrix, containing the double reduction rates at each locus. Obtained from function \code{\link{DRRsetup}}
#' @details
#' \emph{Data file format}
#' \itemize{
#'  \item {must be a tab-delimeted excel file (*.csv)}
#'  \item {first three headers must include (ID, pop, mother), case sensitive]
#'  See example data file \code{data(Eremophila)}}
#'  \item {following headers must provide information regarding locus identity,
#'  with two columns per locus (e.g. locus1a, locus1b, locus2a, locus2b)}
#'  }
#' \emph{Adults, known parents and progeny (offspring)}
#' \itemize{
#'  \item {Adults in the data set that are not mothers are identified by having no values
#' in the ‘mother’ column. Not all adults have to be mothers}
#'  \item {Progeny from known mothers are identified by having values in the ‘mother’
#'  column. These values refer to the ID of the known mother and must correspond
#'  to an ID present among the adults. Note: a progeny array can all have the
#'  same mother ID}
#'  \item {Progeny from unknown mothers are identified with ‘u’ qualifier in the
#'  ‘mother’ column. Note: function cannot handle a mix of known and unknown
#'  mothers}
#'  \item {Mothers in the data set are only identified by having their
#'  ID present in the ‘mother’ column for one of the seedlings. All remaining
#'  individuals are classified as adults}
#'  \item {Only adults (mothers and non mothers) are used in population
#'  genetic analyses (e.g. allele frequency, expected and observed
#'  heterozygosity, Fst)}
#' }
#' @return procudes a dataframe with same dimensions as excel file
#' @author David L. Field
#' @examples
#' # Empirical data example.
#' # Eremophila glabra data consists of: 6 SSR loci, phenotypes, mother known, DRR and segregation ratios unknown.
#' data(Eremophila)
#' write.csv(Eremophila,"Eremophila_mumKnown.csv",quote=F,row.names=F)
#'
#' # 1. Make table with the Double Reduction Rates (DRR) at each locus.
#' DRRtable_1 <- DRRsetup(numLoci=6,ploidy=6,propDRR=1)
#'
#' # 2. import and process data
#' EremophilaData <- inputData("Eremophila_mumKnown.csv",numLoci=6,lociMin=5,ploidy=6,marker="phenotype",cohorts=T,motherknown=T,DRRtable_1)
#'
#' @export
inputData <- function(filename,numLoci,lociMin,ploidy,marker,cohorts,motherknown,DRR) {

          inData <- read.csv(filename,header=TRUE,quote="",strip.white = TRUE,na.strings=c("*",""),fill=FALSE)

          return(processData(inData,filename,numLoci,lociMin,ploidy,marker,cohorts,motherknown,DRR))
}
#' @export
processData <- function(inData,filename,numLoci,lociMin,ploidy,marker,cohorts,motherknown,DRRtable) {

  strip.NAs <- function(vv) {
    return(vv[!is.na(vv)])
  }

  # Function to return individuals that meet the minimum loci criteria
  NonDudIndividuals<-function(inDataSimData,numLoci,ploidy,lociMin) {
    alleleCounts <- matrix(0, nrow=dim(inDataSimData)[1],ncol=numLoci,
                           dimnames=list(inDataSimData$ID,paste("Locus",1:numLoci)))
    ## number of alleles present in each set - store in alleleCounts
    for (thisLocus in 1:numLoci) {
      #testing thisLocus<-1
      # thisAdult<-3
      locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
      ##Note: apply() returns the _transpose_ of the desired matrix
      ## below - hence the use of t()...
      inData[,locusRange] <- t(apply(inData[,locusRange],1,sort,
                                     na.last = TRUE))
      ## Store the numbers of alleles detected at each locus
      alleleCounts[,thisLocus] <- apply(inDataSimData[,locusRange],1,
                                        function (thisAlleleVector) {
                                          sum(!is.na(thisAlleleVector))
                                        })
    }
    numLociData <- apply(alleleCounts,1,
                         function (theseAlleleCounts) {
                           sum(theseAlleleCounts > 0)
                         })
    GoodPlants <- numLociData >= lociMin
    return(inDataSimData[as.vector(GoodPlants),])
  }


  ##################################
  #  Data set checks & formatting  #
  ##################################
  cat("\n ********************************************** \n")
  cat(" *          Autopoly v.0.1 (1/3/2017)         * \n")
  cat(" *   Author(s): David Field                   * \n")
  cat(" ********************************************** \n")

  ParametersInData <- matrix(0,8,1)
  colnames(ParametersInData) <- c("Value")
  rownames(ParametersInData) <- c("ploidy:","marker:","loci:","minimum loci for analysis:","cohorts:","mother known:",
                                  "DRR:","data check complete?")

  ParametersInData <- as.data.frame(ParametersInData)
  if (all(DRRtable[,1]==0)) {
    DRRvals <- "min"
  }
  if (any(DRRtable[,1]!=0)) {
    DRRvals <- "variable"
  }

  cat("\n **** Importing Data ****\n")
  ParametersInData["ploidy:","Value"] <- ploidy
  ParametersInData["marker:","Value"] <- marker
  ParametersInData["loci:","Value"] <- numLoci
  ParametersInData["minimum loci for analysis:","Value"] <- lociMin
  ParametersInData["cohorts:","Value"] <- cohorts
  ParametersInData["mother known:","Value"] <- motherknown
  ParametersInData["DRR:","Value"] <- DRRvals
  ParametersInData["data check complete?","Value"] <- FALSE
  projectData <- list()
  projectData[["Data File"]] <- list()
  projectData[["Parameters"]] <- list()
  projectData[["Data Summary"]] <- list()
  projectData[["InputData"]] <- list()
  projectData[["Data File"]] <- filename
  projectData[["Parameters"]] <- ParametersInData

  #  cat("\n ** Importing Data **\n")
  #  cat("\n Setup Information:\n")
  #  cat("     filename    = ",filename,"\n")
  #  cat("     ploidy      = ",ploidy,"\n")
  #  cat("     no. Loci    = ",numLoci,"\n")
  #  cat("     marker      = ",marker,"\n")
  #  cat("     lociMin     = ",lociMin,"\n")
  #  cat("     DRR         = ",DRR,"\n")
  #  cat("     cohorts     = ",cohorts,"\n")
  #  cat("     motherknown = ",motherknown,"\n")
  #######################################################
  #  Check 1 - Convert marker data to Character strings #
  #######################################################
  cat("\n Beginning Checks:")
  flush.console()
  ##############################
  ## function "to.character"   #
  ##############################

  to.character <-  function(data.fr, cols=NULL) {
    ##Takes a dataframe and a vector of columns that are to be converted
    ## to character vectors.  Returns the modified dataframe.
    ##The cols argument can be a character vector of column names, a
    ## vector of column indices, or NULL (the default). If cols is NULL,
    ## all columns are converted.
    if (!is.data.frame(data.fr)) stop("First argument must be a dataframe")
    if (is.null(cols)) {cols <- names(data.fr)}
    if (is.vector(cols) & (is.character(cols) | is.numeric(cols))) {
      for (colmn in cols) {
        data.fr[[colmn]] <- as.character(data.fr[[colmn]])
      }
      return(data.fr)
    } else {
      stop("\n Error: cols argument must be an integer or character vector, or NULL")
    }
  }
  flush.console()
  ##Run function to convert to character strings
  inData <- to.character(inData)

  #######################################################
  #  Check 2 - First 3 column names correct             #
  #######################################################
  ##Names of the important columns
  if (any(colnames(inData)[1:3]!= c("ID","pop","mother"))) {
    cat("\n     Initial data format.......................FAILED\n")
    stop("\n The first three columns of your data spreadsheet should
         be called 'ID','pop', and 'mother', in that order.
         Note the capitalisation used...")
  }
  cat("\n     Initial data format.......................OK")
  flush.console()
  ##############################################################
  #  Check 3 - Does the number of columns match the specified  #
  #     number of loci and ploidy?                             #
  ##############################################################

  if (ncol(inData)-3 != numLoci*ploidy) {
    cat("\n     Columns match no. loci & ploidy?..........FAILED\n")
    stop("\n Number of columns in the dataset is inconsistent with the
         specified number of loci, and ploidy.  The number of
         columns should be 3 + (number of loci) * ploidy")
  }
  cat("\n     Columns match no. loci & ploidy?..........OK")
  flush.console()
  ##############################################################
  #  Check 4 - Data set contain at least 2 populations?        #
  #                                                            #
  ##############################################################
  # Removed for now, think about this one if really neccessary
  #
  #  if (length(unique(inData$pop)) < 2) {
  #    cat("\n     At least 2 populations....................FAILED")
  #    stop("The dataset must contain at least two populations...")
  #  }
  #  cat("\n     At least 2 populations....................OK")
  ##############################################################
  #  Check 5 - At least 2 adults per population?               #
  #                                                            #
  ##############################################################

  PopASTable <- with(inData, table(pop,is.na(mother)))
  if (any(PopASTable[,"TRUE"] < 2)) {
    cat("\n     At least 2 adults per population..........FAILED\n")
    stop("\n The dataset must contain at least two adults in each population...")
  }
  cat("\n     At least 2 adults per population..........OK")
  flush.console()
  ##############################################################
  #  Check 6 - every ID must be unique                         #
  #             prints which IDs were not unique               #
  ##############################################################

  if (any(duplicated(inData$ID))) {
    PopIDTable <- with(inData, table(ID))
    duplicateIDs<-names(PopIDTable[PopIDTable!=1])
    cat("\n     Individual ID are unique..................FAILED\n")
    cat("\n Warning - The following duplicate IDs found:\n")
    cat("  ",duplicateIDs,"\n\n")
    stop("\n The ID column in the dataset should uniquely identify each row of the dataset.")
  }
  ##If all ID's are unique, used as rownames
  rownames(inData) <- inData$ID
  cat("\n     Individual ID are unique..................OK")
  flush.console()
  ##############################################################
  #  Check 7 - All seedlings must have a mother                #
  #          -only relvant if cohorts=TRUE, motherknown=TRUE   #
  ##############################################################
  # Four alternative input options for cohorts & motherknown
  # No.1
  if (cohorts==TRUE & motherknown==TRUE) {
    seedlingMothers <- with(inData,unique(strip.NAs(mother)))
    if (any(!(seedlingMothers %in% inData$ID))) {
      cat("\n     Adults and Progeny qualified..............FAILED\n")
      stop("\n When motherknown=TRUE, ALL progeny must have a mother assigned")
    }
    if (all(is.na(inData$mother))) {
      cat("\n     Adults and Progeny qualified..............FAILED\n")
      stop("\n No Progeny detected (no values in mother column), however cohorts=TRUE")
    }
    cat("\n     Adults and Progeny qualified..............OK")
  }
  # No.2  Should be 'u' for some individuals in the mother column

  if (cohorts==TRUE & motherknown==FALSE)  {
    motherColumn<- inData$mother
    motherColumn2<-!is.na(motherColumn)
    if (all(motherColumn2==FALSE)) {
      cat("\n     Adults and Progeny qualified..............FAILED\n")
      stop("\n cohorts=TRUE, motherknown=FALSE, however NO progeny have been qualified with character 'u'")
    }
    if (any(motherColumn2==TRUE)) {
      motherColumn<-strip.NAs(motherColumn)
      if (all(motherColumn!="u")) {
        cat("\n     Adults and Progeny qualified..............FAILED\n")
        stop("\n cohorts=TRUE, motherknown=FALSE, progeny from unknown mothers MUST be qualified with character 'u' but none detected")
      }
      if (all(motherColumn=="u")) {
        cat("\n     Adults and Progeny qualified..............OK")
      }
    }
  }
  # No.3
  if (cohorts==FALSE & motherknown==TRUE){
    cat("\n     Adults and Progeny qualified..............FAILED\n")
    stop("\n Not logical, cohorts=FALSE, however motherknown=TRUE indicates cohorts are present")
  }
  # No.4
  if (cohorts==FALSE & motherknown==FALSE){
    seedlingID<-with(inData,ID[!is.na(mother)] )
    if (length(seedlingID>=1)) {
      cat("\n     Adults and Progeny qualified..............FAILED\n")
      stop("\n Progeny detected (values in mother column) when cohorts=FALSE and motherknown=FALSE")
    }
    if (length(seedlingID<1)) {
      cat("\n     Adults and Progeny qualified..............OK")
    }
  }
  flush.console()
  ##############################################################
  #  Check 8 - Seedlings CANT also be a mother                 #
  #                                                            #
  ##############################################################
  if (cohorts==TRUE & motherknown==TRUE) {
    seedlingIDs <- with(inData,ID[!is.na(mother)])
    if (any((seedlingMothers %in% seedlingIDs))) {
      cat("\n     No seedling also a mother.................FAILED\n")
      stop("\n At least one progeny also has a progeny as its mother")
    }
    cat("\n     No progeny also a mother..................OK")
  }
  flush.console()
  ##############################################################
  #  Check 9 - Does the number of alleles match with specified #
  #     marker type?                                           #
  ##############################################################

  ##Matrix to store the number of alleles detected at each locus
  alleleCounts <- matrix(0, nrow=dim(inData)[1],ncol=numLoci,
                         dimnames=list(inData$ID,paste("Locus",1:numLoci)))
  uniqueAlleleCounts<- matrix(0, nrow=dim(inData)[1],ncol=numLoci,
                              dimnames=list(inData$ID,paste("Locus",1:numLoci)))

  ## First, sort each allele set into (alphanumeric) order, and count the
  ## number of alleles present in each set - store in alleleCounts
  for (thisLocus in 1:numLoci) {
    #testing thisLocus<-1
    # thisAdult<-3
    locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
    ## below - hence the use of t()...
    inData[,locusRange] <- t(apply(inData[,locusRange],1,sort,
                                   na.last = TRUE))
    ## Store the numbers of alleles detected at each locus
    alleleCounts[,thisLocus] <- apply(inData[,locusRange],1,
                                      function (thisAlleleVector) {
                                        sum(!is.na(thisAlleleVector))
                                      })
    if (marker=="phenotype") {
      for (thisIndividual in 1:nrow(inData)) {
        #test thisIndividual<-15
        thisIndividualData<-unlist(inData[thisIndividual,locusRange,drop=TRUE])
        names(thisIndividualData)<-NULL
        if (any(duplicated(strip.NAs(thisIndividualData)))) {
          dudPhenotype<-rownames(inData[thisIndividual,locusRange])
          cat("\n     Expected no. of alleles for marker type...FAILED\n")
          cat("\n Warning - The following individual had duplicated alleles:\n")
          cat("  ",dudPhenotype," at locus",
              thisLocus,"\n")
          # run convert phenotypes function
          inData <- convert.phenotypes(inData, numLoci, ploidy)
          cat("\n      Converted to phenotypes....  Problem FIXED\n")
          #stop("\n For phenotype markers, NO duplicate alleles allowed.")
        }
      }
    }
  }
  alleleCountTable<-table(alleleCounts)
  maxAlleles<-as.numeric(names(alleleCountTable))
  if (marker=="genotype") {
    if (any(0<maxAlleles & maxAlleles<ploidy)) {
      oddOneTally<-apply(0<alleleCounts & alleleCounts<ploidy,1,sum)
      oddOnes<-names(oddOneTally[oddOneTally==1])
      cat("\n     Expected no. of alleles for marker type...FAILED\n")
      cat("\n Warning - The following individuals have too few alleles for genotype markers:\n")
      cat("  ",oddOnes,"\n\n")
      stop("\n For genotype markers, no. alleles must = ploidy.")
    }
  }
  cat("\n     Expected no. of alleles for marker type...OK\n")
  flush.console()

  ##################################################
  #  Check 10 - Is there only 1 allele per column? #
  ##################################################

  BadAlleleInput <- matrix(0, nrow=numLoci,1,
                           dimnames=list(paste("Locus",1:numLoci),"Bad Input"))

  for (thisLocus in 1:numLoci) {
    # testing thisLocus<-6
    # thisAdult<-3
    locusData<-NULL
    locusRange <- 3 + (thisLocus-1)*ploidy + 1:ploidy
    thisLotofData<-inData[,locusRange]
    for (thisRow in 1:(nrow(thisLotofData))) {
      # thisRow<-1
      # thisRow<-"HP7_208A"
      thisIndName<-rownames(thisLotofData[thisRow,])
      thisIndData<-strip.NAs(thisLotofData[thisRow,])
      numColsUsed<-length(thisIndData)
      numAllelesInCols<-length(unlist(strsplit(thisIndData," ")))
      if (numColsUsed != numAllelesInCols) {
        locusData<-c(locusData,thisIndName)
      }
    } # End loop over individuals
    # Sending data to BadAlleleInput
    BadAlleleInput<-as.data.frame(BadAlleleInput)
    if (length(locusData) == 0) {
      BadAlleleInput[thisLocus,1] <- "OK"
    }
    if (length(locusData) != 0) {
      BadAlleleInput[thisLocus,1] <- paste(locusData, collapse=", ")
    }
  } # End locus loop

  if (any(BadAlleleInput != "OK")) {

    cat("\n Warning - The following loci has individuals with more than one allele per column:\n")
    cat("\n       ")
    print(BadAlleleInput)
    cat("\n  Fix input file: Only one allele allowed per cell     \n")
    stop("\n     Expected no. of alleles per column.......FAILED\n")
  }
  cat("     Expected no. of alleles per column........OK\n")

  ##############################################################
  #  Check 11 - Removal of dud plants, <lociMin                #
  #                                                            #
  ##############################################################

  if (cohorts==TRUE & motherknown==FALSE) {
    inData<-NonDudIndividuals(inData,numLoci,ploidy,lociMin)
  }
  if (cohorts==TRUE & motherknown==TRUE) {
    numNonmissingLoci <- apply(alleleCounts,1,
                               function (theseAlleleCounts) {
                                 sum(theseAlleleCounts > 0)
                               })
    dudPlants <- numNonmissingLoci < lociMin  ##Be careful here - what about individuals with all missing Loci?
    dudMothers <- (inData$ID %in% seedlingMothers) & (dudPlants)
    ##Flag all seedlings of dud mothers as dud plants
    ##print(inData$ID[which(dudMothers)])
    if (any(dudMothers)) {
      for (dudMother in inData$ID[which(dudMothers)]) {
        dudPlants[inData$mother==dudMother] <- TRUE
      }
    }

    ##Print message, and remove dud plants from the dataset.
    if (any(dudPlants)) {
      cat("\n Plants identified as 'duds' (insufficient loci) have been removed from this dataset, along with any progeny of
          'dud' mothers.\n")
      cat("\n Plants removed correspond to ID's :\n")
      cat("  ",inData$ID[dudPlants],"\n")
    }
    inData <- subset(inData,subset=!dudPlants)
    ##
  }
  projectData[["Parameters"]][["data check complete?",1]] <- TRUE

  flush.console()
  ###################################
  #  Collecting Summary information #
  ###################################
  if (cohorts==TRUE) {
    seedlingID <- with(inData,ID[!is.na(mother)])
    seedlings <- inData[seedlingID,]
    motherID <- as.vector(unique(seedlings[,"mother"]))
    #mothers <- inData[motherID,]
    #cat("\nSample size:\n\n")
    #cat(" Adults")
    #print(table(mothers$pop))
    #cat(" Progeny")
    #print(table(seedlings$pop))
    projectData[["Data Summary"]][["Total sample size"]] <- list()
    projectData[["Data Summary"]][["Mothers"]] <- list()
    projectData[["Data Summary"]][["Progeny"]] <- list()
    projectData[["Data Summary"]][["Total sample size"]] <- table(inData$pop)
    projectData[["Data Summary"]][["Mothers"]]<- table(seedlings$mother)
    projectData[["Data Summary"]][["Progeny"]]<- table(seedlings$pop)
  }
  if (cohorts==FALSE) {
    # cat("\nSample size:\n\n")
    # cat(" Adults")
    projectData[["Data Summary"]][["Total sample size"]] <- table(inData$pop)
    #print(table(inData$pop))
  }

  cat("\n Importing Data...COMPLETE \n")

  projectData[["InputData"]] <- inData
  cat("\n **** Setup Information: ****\n")
  cat("\nfilename    = ",projectData[["Data File"]],"\n\n")
  print(projectData[["Parameters"]])
  cat("\n **** Sample sizes: ****\n\n")
  if (cohorts==TRUE) {
    cat("Total sample size")
    print(projectData[["Data Summary"]][["Total sample size"]])
    cat("Mothers")
    print(projectData[["Data Summary"]][["Mothers"]])
    cat("Progeny")
    print(projectData[["Data Summary"]][["Progeny"]])
  }
  if (cohorts==FALSE) {
    cat("Total sample size")
    print(projectData[["Data Summary"]][["Total sample size"]])
  }
  cat("\n*************END****************** \n")
  return(inData)
  }
